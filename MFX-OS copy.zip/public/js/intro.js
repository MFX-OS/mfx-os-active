// ═══════════════════════════════════════════════════════════════
// MFX OS — FLEX AI BOOT SEQUENCE
// Inspired by the intimate, warm OS aesthetic of "Her"
// Soft light → gentle ink → warm dark → personal AI greeting
// True cyan (#00FFFF) palette
// ═══════════════════════════════════════════════════════════════

(function(){
'use strict';

var intro=document.getElementById('introScreen');
var canvas=document.getElementById('introCanvas');
if(!intro||!canvas)return;

var ctx=canvas.getContext('2d');
var W,H,cx,cy;
var startTime=Date.now();
var elapsed=0;
var lastFrame=Date.now();

// State
var phase=0;
var bgWhite=1;
var inkDrops=[];
var hazeParticles=[];
var dustMotes=[];
var neonGlow=0;
var textOpacity=0;
var subTextOpacity=0;
var dateOpacity=0;
var fadeOut=0;
var voicePhase=0;
var audioCtx=null;
var masterGain=null;
var reverbNode=null;
var voiceStarted=false;
var voiceComplete=false;
var currentDay='';

// True cyan palette
var CYAN={r:0,g:255,b:255};       // #00FFFF — primary
var CYAN_MID={r:0,g:210,b:220};   // slightly muted for pools
var CYAN_GLOW='rgba(0,255,255,';   // for glow effects
var CYAN_HSL='185,100%';           // hsl base for haze

function resize(){
W=canvas.width=window.innerWidth;
H=canvas.height=window.innerHeight;
cx=W/2;cy=H/2;
}
resize();
window.addEventListener('resize',resize);

// ═══════════════════════════════════════════════
// AUDIO — Warm, intimate, "Her"-style sound design
// Soft tones, gentle chimes, breath-like textures
// ═══════════════════════════════════════════════

function getAudio(){
if(!audioCtx){
try{
audioCtx=new(window.AudioContext||window.webkitAudioContext)();
masterGain=audioCtx.createGain();
masterGain.gain.value=0.6;
masterGain.connect(audioCtx.destination);
createReverb();
}catch(e){}
}
return audioCtx;
}

function createReverb(){
var a=audioCtx;if(!a)return;
reverbNode=a.createConvolver();
var rate=a.sampleRate;
var len=rate*4; // 4-second warm reverb
var buf=a.createBuffer(2,len,rate);
for(var ch=0;ch<2;ch++){
var data=buf.getChannelData(ch);
for(var i=0;i<len;i++){
var t=i/rate;
// Warm, diffuse room — like a quiet apartment
var decay=Math.exp(-t*1.6);
var early=t<0.08?Math.exp(-t*25)*0.2:0;
data[i]=(Math.random()*2-1)*(decay+early)*0.4;
}
}
reverbNode.buffer=buf;
reverbNode.connect(masterGain);
}

function reverbSend(src,dry,wet){
var dG=audioCtx.createGain();dG.gain.value=dry;
dG.connect(masterGain);
var wG=audioCtx.createGain();wG.gain.value=wet;
if(reverbNode)wG.connect(reverbNode);else wG.connect(masterGain);
src.connect(dG);src.connect(wG);
}

// ── WARM PAD — Soft, breathy, like morning light ──
function playWarmPad(){
var a=getAudio();if(!a)return;
var t=a.currentTime;

// Soft sine bed — like a held breath
var bed=a.createOscillator();
var bedG=a.createGain();
bed.type='sine';bed.frequency.value=65; // low C
bedG.gain.setValueAtTime(0,t);
bedG.gain.linearRampToValueAtTime(0.04,t+4);
bedG.gain.setValueAtTime(0.04,t+14);
bedG.gain.linearRampToValueAtTime(0,t+18);
bed.connect(bedG);reverbSend(bedG,0.3,0.7);
bed.start(t);bed.stop(t+18);

// Warm fifth — gentle harmony
var fifth=a.createOscillator();
var fifthG=a.createGain();
var fifthF=a.createBiquadFilter();
fifth.type='sine';fifth.frequency.value=97.5; // G below middle C
fifthF.type='lowpass';fifthF.frequency.value=200;fifthF.Q.value=1;
fifthG.gain.setValueAtTime(0,t+1);
fifthG.gain.linearRampToValueAtTime(0.025,t+5);
fifthG.gain.setValueAtTime(0.025,t+13);
fifthG.gain.linearRampToValueAtTime(0,t+17);
fifth.connect(fifthF);fifthF.connect(fifthG);reverbSend(fifthG,0.3,0.7);
fifth.start(t);fifth.stop(t+17);

// Breathy texture — filtered noise, like wind through a window
var noiseBuf=a.createBuffer(1,a.sampleRate*18,a.sampleRate);
var nd=noiseBuf.getChannelData(0);
for(var i=0;i<nd.length;i++){nd[i]=(Math.random()*2-1)}
var noise=a.createBufferSource();noise.buffer=noiseBuf;
var nF=a.createBiquadFilter();var nF2=a.createBiquadFilter();
var nG=a.createGain();
nF.type='bandpass';nF.frequency.value=400;nF.Q.value=3;
nF2.type='lowpass';nF2.frequency.value=600;
nG.gain.setValueAtTime(0,t+2);
nG.gain.linearRampToValueAtTime(0.008,t+6);
nG.gain.setValueAtTime(0.008,t+12);
nG.gain.linearRampToValueAtTime(0,t+16);
noise.connect(nF);nF.connect(nF2);nF2.connect(nG);reverbSend(nG,0.2,0.8);
noise.start(t);noise.stop(t+18);

// High shimmer — like distant wind chimes
var shim=a.createOscillator();
var shimG=a.createGain();
var shimF=a.createBiquadFilter();
var lfo=a.createOscillator();var lfoG=a.createGain();
shim.type='sine';shim.frequency.value=1320; // E6
shimF.type='bandpass';shimF.frequency.value=1320;shimF.Q.value=15;
lfo.type='sine';lfo.frequency.value=0.08; // very slow
lfoG.gain.value=0.005;
lfo.connect(lfoG);lfoG.connect(shimG.gain);
shimG.gain.setValueAtTime(0,t+4);
shimG.gain.linearRampToValueAtTime(0.006,t+8);
shimG.gain.setValueAtTime(0.006,t+12);
shimG.gain.linearRampToValueAtTime(0,t+16);
shim.connect(shimF);shimF.connect(shimG);reverbSend(shimG,0.1,0.9);
shim.start(t);lfo.start(t);
shim.stop(t+16);lfo.stop(t+16);
}

// ── GENTLE DRIP — Soft water drop, not harsh ──
function playDripSound(size){
var a=getAudio();if(!a)return;
var t=a.currentTime;
var sz=size||1;

// Soft tonal drop — like a single raindrop on glass
var osc=a.createOscillator();
var g=a.createGain();
var f=a.createBiquadFilter();
osc.type='sine';
osc.frequency.setValueAtTime(600+Math.random()*200,t);
osc.frequency.exponentialRampToValueAtTime(100,t+0.3);
f.type='lowpass';f.frequency.value=800;f.Q.value=2;
g.gain.setValueAtTime(0.03*sz,t);
g.gain.exponentialRampToValueAtTime(0.001,t+0.35);
osc.connect(f);f.connect(g);reverbSend(g,0.2,0.8);
osc.start(t);osc.stop(t+0.5);

// Tiny resonant ping
var ping=a.createOscillator();
var pG=a.createGain();
ping.type='sine';ping.frequency.value=1800+Math.random()*400;
pG.gain.setValueAtTime(0.008*sz,t+0.02);
pG.gain.exponentialRampToValueAtTime(0.0001,t+0.4);
ping.connect(pG);reverbSend(pG,0.1,0.9);
ping.start(t);ping.stop(t+0.5);
}

// ── SOFT SPLASH — Gentle surface contact ──
function playSplashSound(){
var a=getAudio();if(!a)return;
var t=a.currentTime;
var nBuf=a.createBuffer(1,a.sampleRate*0.12,a.sampleRate);
var nd=nBuf.getChannelData(0);
for(var i=0;i<nd.length;i++){nd[i]=(Math.random()*2-1)*Math.exp(-i/(a.sampleRate*0.03))}
var noise=a.createBufferSource();noise.buffer=nBuf;
var f=a.createBiquadFilter();f.type='bandpass';f.frequency.value=800;f.Q.value=1;
var g=a.createGain();g.gain.setValueAtTime(0.015,t);g.gain.exponentialRampToValueAtTime(0.001,t+0.12);
noise.connect(f);f.connect(g);reverbSend(g,0.2,0.8);
noise.start(t);
}

// ── BOOT CHIME — Warm ascending tones, like OS waking up ──
function playBootChime(){
var a=getAudio();if(!a)return;
var t=a.currentTime;

// Three gentle ascending notes — like "Her" OS boot
var notes=[261.6,329.6,392]; // C4, E4, G4 — warm major chord
for(var i=0;i<notes.length;i++){
(function(freq,delay){
var osc=a.createOscillator();
var g=a.createGain();
osc.type='sine';osc.frequency.value=freq;
g.gain.setValueAtTime(0,t+delay);
g.gain.linearRampToValueAtTime(0.035,t+delay+0.08);
g.gain.setValueAtTime(0.035,t+delay+0.3);
g.gain.exponentialRampToValueAtTime(0.001,t+delay+2);
osc.connect(g);reverbSend(g,0.15,0.85);
osc.start(t+delay);osc.stop(t+delay+2.5);
})(notes[i],i*0.25);
}

// Soft high octave — airy sweetness
var hi=a.createOscillator();
var hG=a.createGain();
var hF=a.createBiquadFilter();
hi.type='sine';hi.frequency.value=784; // G5
hF.type='lowpass';hF.frequency.value=1000;
hG.gain.setValueAtTime(0,t+0.8);
hG.gain.linearRampToValueAtTime(0.015,t+1.1);
hG.gain.exponentialRampToValueAtTime(0.001,t+3);
hi.connect(hF);hF.connect(hG);reverbSend(hG,0.1,0.9);
hi.start(t+0.8);hi.stop(t+3.5);
}

// ── TRANSITION WARMTH — Soft low swell, not a rumble ──
function playTransitionSwell(){
var a=getAudio();if(!a)return;
var t=a.currentTime;

var osc=a.createOscillator();
var g=a.createGain();
osc.type='sine';osc.frequency.value=40;
g.gain.setValueAtTime(0,t);
g.gain.linearRampToValueAtTime(0.05,t+1.5);
g.gain.linearRampToValueAtTime(0.03,t+3);
g.gain.linearRampToValueAtTime(0,t+5);
osc.connect(g);reverbSend(g,0.4,0.6);
osc.start(t);osc.stop(t+5);

// Warm mid sweep
var sw=a.createOscillator();
var sG=a.createGain();
var sF=a.createBiquadFilter();
sw.type='triangle';
sw.frequency.setValueAtTime(80,t);
sw.frequency.linearRampToValueAtTime(200,t+2);
sw.frequency.linearRampToValueAtTime(120,t+4);
sF.type='lowpass';sF.frequency.value=300;sF.Q.value=1;
sG.gain.setValueAtTime(0,t+0.5);
sG.gain.linearRampToValueAtTime(0.02,t+2);
sG.gain.linearRampToValueAtTime(0,t+5);
sw.connect(sF);sF.connect(sG);reverbSend(sG,0.3,0.7);
sw.start(t);sw.stop(t+5);
}

// ── VOICE READY — Gentle notification ──
function playVoiceReady(){
var a=getAudio();if(!a)return;
var t=a.currentTime;
// Single warm tone — "I'm here"
var osc=a.createOscillator();
var g=a.createGain();
osc.type='sine';osc.frequency.value=523.25; // C5
g.gain.setValueAtTime(0,t);
g.gain.linearRampToValueAtTime(0.03,t+0.06);
g.gain.setValueAtTime(0.03,t+0.15);
g.gain.exponentialRampToValueAtTime(0.001,t+1.5);
osc.connect(g);reverbSend(g,0.15,0.85);
osc.start(t);osc.stop(t+2);
}

// ── SOFT OUTRO — Gentle fade tone ──
function playOutro(){
var a=getAudio();if(!a)return;
var t=a.currentTime;
var notes=[392,329.6,261.6]; // G4, E4, C4 — gentle descending
for(var i=0;i<notes.length;i++){
(function(freq,delay){
var osc=a.createOscillator();
var g=a.createGain();
osc.type='sine';osc.frequency.value=freq;
g.gain.setValueAtTime(0,t+delay);
g.gain.linearRampToValueAtTime(0.02,t+delay+0.06);
g.gain.exponentialRampToValueAtTime(0.001,t+delay+1.8);
osc.connect(g);reverbSend(g,0.1,0.9);
osc.start(t+delay);osc.stop(t+delay+2);
})(notes[i],i*0.3);
}
}

// ═══════════════════════════════════════════════
// VOICE — Warm, personal, conversational
// ═══════════════════════════════════════════════

function speak(text,rate,pitch,onEnd){
if(!window.speechSynthesis){if(onEnd)setTimeout(onEnd,2500);return}
speechSynthesis.cancel();
var utter=new SpeechSynthesisUtterance(text);
utter.rate=rate||0.88;
utter.pitch=pitch||0.9;
utter.volume=1;
var voices=speechSynthesis.getVoices();
// Prefer warm, natural-sounding voices — like Samantha in "Her"
var pref=voices.find(function(v){return /Samantha/i.test(v.name)});
if(!pref)pref=voices.find(function(v){return /Karen|Moira|Tessa|Victoria|Zoe|Allison/i.test(v.name)});
if(!pref)pref=voices.find(function(v){return /Daniel|Google UK English Male|Microsoft David|Aaron|Alex/i.test(v.name)});
if(!pref)pref=voices.find(function(v){return /en[-_]/i.test(v.lang)});
if(pref)utter.voice=pref;

var fired=false;
var done=function(){if(!fired){fired=true;if(onEnd)onEnd()}};
utter.onend=done;
speechSynthesis.speak(utter);
setTimeout(done,Math.max(text.length*95+2500,3500));
}

if(window.speechSynthesis){
speechSynthesis.getVoices();
speechSynthesis.onvoiceschanged=function(){speechSynthesis.getVoices()};
}

// ═══════════════════════════════════════════════
// INK PHYSICS
// ═══════════════════════════════════════════════

function InkDrop(x,y,size){
this.x=x;this.y=y;this.originY=y;
this.size=size||3;
this.vy=0;this.vx=0;
this.gravity=0.12;
this.stretching=true;
this.stretchLen=0;
this.maxStretch=35+Math.random()*50;
this.detached=false;
this.landed=false;
this.landY=0;
this.splashRadius=0;
this.splashMax=0;
this.tailDrops=[];
this.opacity=1;
this.wobble=Math.random()*Math.PI*2;
this.wobbleSpeed=2+Math.random()*3;
this.viscosity=0.97;
this.hasPlayedSplash=false;
}

InkDrop.prototype.update=function(dt){
if(this.landed){
if(this.splashRadius<this.splashMax){
this.splashRadius+=0.5*dt*(1-this.splashRadius/this.splashMax);
}
return;
}
if(this.stretching){
var progress=this.stretchLen/this.maxStretch;
this.stretchLen+=(0.2+progress*0.35)*dt;
this.wobble+=this.wobbleSpeed*0.01*dt;
if(this.stretchLen>=this.maxStretch){
this.stretching=false;
this.detached=true;
this.vy=1.2+Math.random()*0.5;
this.vx=(Math.random()-0.5)*0.1;
playDripSound(this.size);
}
return;
}
this.vy+=this.gravity*dt;
this.vy*=this.viscosity;
this.y+=this.vy*dt;
this.x+=this.vx*dt;
this.vx*=0.99;
this.wobble+=this.wobbleSpeed*0.02*dt;
this.x+=Math.sin(this.wobble)*0.06;

if(Math.random()<0.08*dt){
this.tailDrops.push({x:this.x+(Math.random()-0.5)*2,y:this.y-this.size,vy:this.vy*0.2,vx:(Math.random()-0.5)*0.2,size:0.2+Math.random()*0.7,life:1});
}
this.tailDrops.forEach(function(t){t.y+=t.vy*dt;t.x+=t.vx*dt;t.vy+=0.04*dt;t.life-=0.012*dt});
this.tailDrops=this.tailDrops.filter(function(t){return t.life>0});

var floorY=cy+H*0.12;
if(this.y>=floorY){
this.landed=true;this.landY=floorY;
this.splashMax=this.size*9+Math.random()*20;
if(!this.hasPlayedSplash){this.hasPlayedSplash=true;playSplashSound()}
for(var i=0;i<3+Math.floor(Math.random()*3);i++){
this.tailDrops.push({x:this.x+(Math.random()-0.5)*this.size*3,y:floorY-Math.random()*2,vy:-0.8-Math.random()*1.5,vx:(Math.random()-0.5)*1.5,size:0.2+Math.random()*0.4,life:0.5+Math.random()*0.3});
}
}
};

InkDrop.prototype.draw=function(darkP){
var alpha=this.opacity;
var r=CYAN.r,g=CYAN.g,b=CYAN.b;
var neonP=Math.max(0,(darkP-0.35)/0.65);

if(neonP>0){
ctx.shadowColor=CYAN_GLOW+neonP*0.6+')';
ctx.shadowBlur=12+neonP*35;
}

if(this.landed){
// Use slightly muted cyan for pools
ctx.fillStyle='rgba('+CYAN_MID.r+','+CYAN_MID.g+','+CYAN_MID.b+','+alpha*0.8+')';
var sr=this.splashRadius;
if(sr>1){
ctx.beginPath();
var pts=14;
for(var i=0;i<=pts;i++){
var angle=i/pts*Math.PI*2;
var rad=sr*(0.65+0.2*Math.sin(angle*3.5+this.x*0.08)+0.15*Math.cos(angle*5+this.y*0.06));
var px=this.x+Math.cos(angle)*rad;
var py=this.landY+Math.sin(angle)*rad*0.25;
if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);
}
ctx.closePath();ctx.fill();
// Wet highlight
if(neonP>0){
var hl=ctx.createRadialGradient(this.x-sr*0.15,this.landY-sr*0.04,0,this.x,this.landY,sr*0.5);
hl.addColorStop(0,'rgba(180,255,255,'+neonP*0.12+')');
hl.addColorStop(1,'rgba(0,255,255,0)');
ctx.fillStyle=hl;ctx.fill();
}
}
this.tailDrops.forEach(function(t){
if(t.life>0){ctx.fillStyle='rgba('+r+','+g+','+b+','+t.life*0.6+')';ctx.beginPath();ctx.arc(t.x,t.y,t.size,0,Math.PI*2);ctx.fill()}
});
ctx.shadowBlur=0;return;
}

ctx.fillStyle='rgba('+r+','+g+','+b+','+alpha+')';

if(this.stretching){
var topY=this.originY;
var botY=this.originY+this.stretchLen;
var stretchRatio=this.stretchLen/this.maxStretch;
var neckW=Math.max(0.3,this.size*(1-stretchRatio*0.8));
var bulbSz=this.size*(0.8+stretchRatio*0.4);
var wob=Math.sin(this.wobble)*stretchRatio*1.2;

ctx.beginPath();
ctx.moveTo(this.x-this.size*1.1,topY);
ctx.quadraticCurveTo(this.x-this.size*0.7,topY+this.stretchLen*0.15,this.x+wob-neckW,botY-bulbSz);
ctx.quadraticCurveTo(this.x+wob-neckW*0.5,botY-bulbSz*0.3,this.x+wob-bulbSz*0.7,botY);
ctx.arc(this.x+wob,botY,bulbSz,Math.PI,0,false);
ctx.quadraticCurveTo(this.x+wob+neckW*0.5,botY-bulbSz*0.3,this.x+wob+neckW,botY-bulbSz);
ctx.quadraticCurveTo(this.x+this.size*0.7,topY+this.stretchLen*0.15,this.x+this.size*1.1,topY);
ctx.closePath();ctx.fill();
ctx.beginPath();ctx.arc(this.x,topY,this.size*1.2,0,Math.PI*2);ctx.fill();
// Specular
ctx.fillStyle='rgba(255,255,255,'+alpha*0.2+')';
ctx.beginPath();ctx.arc(this.x+wob-bulbSz*0.2,botY-bulbSz*0.15,bulbSz*0.2,0,Math.PI*2);ctx.fill();
}else{
var wx=Math.sin(this.wobble)*0.4;
ctx.beginPath();
ctx.moveTo(this.x+wx,this.y-this.size*3);
ctx.bezierCurveTo(this.x+wx+this.size*0.3,this.y-this.size*2,this.x+wx+this.size*1.6,this.y-this.size*0.5,this.x+wx,this.y+this.size*1.1);
ctx.bezierCurveTo(this.x+wx-this.size*1.6,this.y-this.size*0.5,this.x+wx-this.size*0.3,this.y-this.size*2,this.x+wx,this.y-this.size*3);
ctx.fill();
ctx.fillStyle='rgba(255,255,255,'+alpha*0.25+')';
ctx.beginPath();ctx.arc(this.x+wx-this.size*0.3,this.y-this.size*0.7,this.size*0.3,0,Math.PI*2);ctx.fill();
}

ctx.fillStyle='rgba('+r+','+g+','+b+',0.45)';
this.tailDrops.forEach(function(t){if(t.life>0){ctx.beginPath();ctx.arc(t.x,t.y,t.size,0,Math.PI*2);ctx.fill()}});
ctx.shadowBlur=0;
};

// ═══════════════════════════════════════════════
// ATMOSPHERE
// ═══════════════════════════════════════════════

function Haze(x,y){
this.x=x;this.y=y;
this.vx=(Math.random()-0.5)*0.15;
this.vy=-0.12-Math.random()*0.35;
this.size=35+Math.random()*90;
this.life=1;
this.hue=180+Math.random()*15; // true cyan range
this.lit=55+Math.random()*15;
}
Haze.prototype.update=function(dt){
this.x+=this.vx*dt;this.y+=this.vy*dt;
this.size+=0.35*dt;this.life-=0.002*dt;
this.vx+=Math.sin(elapsed*0.25+this.x*0.004)*0.01;
};
Haze.prototype.draw=function(){
if(this.life<=0)return;
var a=this.life*0.08;
var grad=ctx.createRadialGradient(this.x,this.y,0,this.x,this.y,this.size);
grad.addColorStop(0,'hsla('+this.hue+',100%,'+this.lit+'%,'+a+')');
grad.addColorStop(0.4,'hsla('+this.hue+',100%,'+Math.max(30,this.lit-15)+'%,'+a*0.3+')');
grad.addColorStop(1,'hsla('+this.hue+',100%,25%,0)');
ctx.fillStyle=grad;ctx.beginPath();ctx.arc(this.x,this.y,this.size,0,Math.PI*2);ctx.fill();
};

function DustMote(){
this.x=Math.random()*W;this.y=Math.random()*H;
this.vx=(Math.random()-0.5)*0.06;this.vy=(Math.random()-0.5)*0.04;
this.size=0.3+Math.random()*1;
this.brightness=0.2+Math.random()*0.4;
this.phase=Math.random()*Math.PI*2;
}
DustMote.prototype.update=function(dt){
this.x+=this.vx*dt+Math.sin(elapsed*0.4+this.phase)*0.03;
this.y+=this.vy*dt+Math.cos(elapsed*0.25+this.phase)*0.02;
if(this.x<0)this.x=W;if(this.x>W)this.x=0;
if(this.y<0)this.y=H;if(this.y>H)this.y=0;
};
DustMote.prototype.draw=function(darkP){
if(darkP<0.3)return;
var a=this.brightness*(darkP-0.3)/0.7*0.35;
ctx.fillStyle='rgba(0,255,255,'+a+')';
ctx.beginPath();ctx.arc(this.x,this.y,this.size,0,Math.PI*2);ctx.fill();
};

for(var dm=0;dm<25;dm++)dustMotes.push(new DustMote());

// ═══════════════════════════════════════════════
// VOICE SEQUENCE — Personal, warm, like "Her"
// ═══════════════════════════════════════════════

function startVoiceSequence(){
if(voiceStarted)return;
voiceStarted=true;

var now=new Date();
var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
var months=['January','February','March','April','May','June','July','August','September','October','November','December'];
var day=days[now.getDay()];
var month=months[now.getMonth()];
var date=now.getDate();
var hour=now.getHours();
var min=now.getMinutes();
var ampm=hour>=12?'PM':'AM';
var h12=hour%12||12;
var minStr=min<10?'oh '+min:min.toString();
currentDay=day+', '+month+' '+date+' at '+h12+':'+((min<10?'0':'')+min)+' '+ampm;

playVoiceReady();

setTimeout(function(){
// "Hi. I'm Flex AI."
voicePhase=1;
speak('Hi. I\'m Flex A I.',0.88,0.9,function(){
setTimeout(function(){
// "Welcome to MFX OS."
voicePhase=2;
speak('Welcome to M F X, O S.',0.9,0.85,function(){
setTimeout(function(){
// "The Microflex Operating System."
voicePhase=3;
speak('The Microflex Operating System.',0.85,0.85,function(){
setTimeout(function(){
// "It's [day and time]."
voicePhase=4;
speak('It\'s '+day+', '+month+' '+date+'. '+h12+' '+minStr+' '+ampm+'.',0.9,0.9,function(){
setTimeout(function(){
// "Let's get started."
voicePhase=5;
speak('Let\'s get started.',0.85,0.95,function(){
voicePhase=6;
voiceComplete=true;
playOutro();
});
},600);
});
},800);
});
},500);
});
},500);
});
},700);
}

// ═══════════════════════════════════════════════
// DROP SCHEDULE
// ═══════════════════════════════════════════════

var dropSchedule=[
{t:1.5,x:0,size:3.8},
{t:3.2,x:-45,size:2.8},
{t:3.9,x:65,size:3},
{t:4.5,x:-18,size:2.2},
{t:5.1,x:35,size:3.5},
{t:5.7,x:-70,size:2.5},
{t:6.2,x:12,size:2.8},
{t:6.6,x:-35,size:2}
];
var spawnedDrops={};
var padStarted=false;
var swellStarted=false;
var chimeStarted=false;

// ═══════════════════════════════════════════════
// MAIN LOOP
// ═══════════════════════════════════════════════

function animate(){
var now=Date.now();
var dt=(now-lastFrame)/16.67;
if(dt>3)dt=3;
lastFrame=now;
elapsed=(now-startTime)/1000;

// Phase timing — gentle, unhurried
if(elapsed<1){phase=0}         // Quiet white void
else if(elapsed<2){phase=1}    // First drip
else if(elapsed<7.5){phase=2}  // Drips cascade
else if(elapsed<10){phase=3}   // Darken — glow emerges
else if(elapsed<12){phase=4}   // Text
else if(!voiceStarted){phase=5;startVoiceSequence()}

// Audio triggers
if(phase>=1&&!padStarted){padStarted=true;playWarmPad()}
if(phase>=3&&!swellStarted){swellStarted=true;playTransitionSwell()}
if(phase>=4&&!chimeStarted){chimeStarted=true;playBootChime()}

// ── BACKGROUND ──
// Warm white → deep warm dark (not pure black — slightly warm)
if(elapsed>7){bgWhite=Math.max(0,bgWhite-0.005*dt)}
var bv=Math.round(bgWhite*255);
// Slightly warm tint on white, cool tint on dark
var bgR=Math.round(bv*(bgWhite>0.5?1:0.04));
var bgG=Math.round(bv*(bgWhite>0.5?1:0.05));
var bgB=Math.round(bv*(bgWhite>0.5?1:0.07));
if(bgWhite<=0.5){
// Transition to near-black with slight blue
bgR=Math.round(3+bgWhite*6);
bgG=Math.round(6+bgWhite*10);
bgB=Math.round(12+bgWhite*18);
}
ctx.fillStyle='rgb('+bgR+','+bgG+','+bgB+')';
ctx.fillRect(0,0,W,H);

// Infinite room depth cues
if(bgWhite>0.15){
var floorY=cy+H*0.12;
ctx.strokeStyle='rgba(180,185,195,'+(0.05*bgWhite)+')';
ctx.lineWidth=0.5;
ctx.beginPath();ctx.moveTo(0,floorY);ctx.lineTo(W,floorY);ctx.stroke();
for(var i=-4;i<=4;i++){
ctx.strokeStyle='rgba(190,195,205,'+(0.02*bgWhite*(1-Math.abs(i)/5))+')';
ctx.lineWidth=0.3;
ctx.beginPath();ctx.moveTo(cx+i*75,floorY);ctx.lineTo(cx+i*450,H);ctx.stroke();
}
if(bgWhite>0.4){
var refl=ctx.createLinearGradient(0,floorY,0,floorY+H*0.12);
refl.addColorStop(0,'rgba(240,242,248,'+bgWhite*0.06+')');
refl.addColorStop(1,'rgba(240,242,248,0)');
ctx.fillStyle=refl;ctx.fillRect(0,floorY,W,H*0.12);
}
}

// ── SPAWN DROPS ──
dropSchedule.forEach(function(d){
if(elapsed>=d.t&&!spawnedDrops[d.t]){
spawnedDrops[d.t]=true;
inkDrops.push(new InkDrop(cx+d.x,cy-H*0.38,d.size));
}
});

// ── INK ──
var darkP=1-bgWhite;
inkDrops.forEach(function(d){d.update(dt);d.draw(darkP)});

// ── ATMOSPHERE ──
if(darkP>0.2){
neonGlow=Math.min(1,(darkP-0.2)/0.8);

if(Math.random()<0.14*dt*neonGlow){
var pools=inkDrops.filter(function(d){return d.landed});
var pool=pools[Math.floor(Math.random()*pools.length)];
var hx=pool?pool.x:cx+(Math.random()-0.5)*100;
var hy=pool?pool.landY:cy+H*0.12;
hazeParticles.push(new Haze(hx+(Math.random()-0.5)*45,hy));
}
hazeParticles.forEach(function(h){h.update(dt);h.draw()});
hazeParticles=hazeParticles.filter(function(h){return h.life>0});

dustMotes.forEach(function(m){m.update(dt);m.draw(darkP)});

// Soft ambient glow
var glow=ctx.createRadialGradient(cx,cy+H*0.14,0,cx,cy+H*0.14,H*0.55);
glow.addColorStop(0,CYAN_GLOW+neonGlow*0.04+')');
glow.addColorStop(0.3,CYAN_GLOW+neonGlow*0.018+')');
glow.addColorStop(0.6,CYAN_GLOW+neonGlow*0.006+')');
glow.addColorStop(1,CYAN_GLOW+'0)');
ctx.fillStyle=glow;ctx.fillRect(0,0,W,H);

// Gentle vignette
if(darkP>0.5){
var vig=ctx.createRadialGradient(cx,cy,Math.min(W,H)*0.35,cx,cy,Math.max(W,H)*0.75);
vig.addColorStop(0,'rgba(0,0,0,0)');
vig.addColorStop(1,'rgba(0,0,0,'+darkP*0.25+')');
ctx.fillStyle=vig;ctx.fillRect(0,0,W,H);
}
}

// ── TEXT — Clean, minimal, warm ──
if(phase>=4||elapsed>10){
ctx.save();
ctx.textAlign='center';ctx.textBaseline='middle';

textOpacity=Math.min(1,textOpacity+0.01*dt);
var txtY=cy-30;
var fontSize=W<500?32:52;

if(textOpacity>0){
if(neonGlow>0){
// Soft outer glow — not harsh
ctx.shadowColor=CYAN_GLOW+neonGlow*textOpacity*0.25+')';
ctx.shadowBlur=60;
ctx.font='300 '+fontSize+'px Inter, -apple-system, sans-serif';
ctx.fillStyle=CYAN_GLOW+textOpacity*0.12+')';
ctx.fillText('MFX-OS',cx,txtY);

// Main text — clean weight
ctx.shadowBlur=25;
ctx.fillStyle=CYAN_GLOW+textOpacity*0.8+')';
ctx.fillText('MFX-OS',cx,txtY);

// Bright core
ctx.shadowColor='rgba(180,255,255,'+neonGlow*textOpacity*0.4+')';
ctx.shadowBlur=8;
ctx.fillStyle=CYAN_GLOW+textOpacity+')';
ctx.fillText('MFX-OS',cx,txtY);
}else{
ctx.font='300 '+fontSize+'px Inter, -apple-system, sans-serif';
ctx.fillStyle=CYAN_GLOW+textOpacity+')';
ctx.fillText('MFX-OS',cx,txtY);
}
ctx.shadowBlur=0;
}

// Subtitle — ultra light weight
if(textOpacity>0.5){
subTextOpacity=Math.min(1,subTextOpacity+0.015*dt);
ctx.font='200 '+(W<500?8:10)+'px Inter, -apple-system, sans-serif';
var subAlpha=subTextOpacity*0.5;
ctx.fillStyle=bgWhite>0.5?'rgba(120,130,145,'+subAlpha+')':'rgba(140,160,180,'+subAlpha+')';
// Manual letter spacing
var sub='MICROFLEX OPERATING SYSTEM';
var sp=W<500?2.5:3.5;
var tw=0;
for(var si=0;si<sub.length;si++)tw+=ctx.measureText(sub[si]).width+sp;
var sx=cx-tw/2;
for(var si2=0;si2<sub.length;si2++){
ctx.fillText(sub[si2],sx,txtY+36);
sx+=ctx.measureText(sub[si2]).width+sp;
}
}

// Thin divider
if(subTextOpacity>0.5){
var la=Math.min(0.12,(subTextOpacity-0.5)*0.24);
var lw=W<500?60:100;
ctx.strokeStyle=CYAN_GLOW+la+')';
ctx.lineWidth=0.4;
ctx.beginPath();ctx.moveTo(cx-lw,txtY+50);ctx.lineTo(cx+lw,txtY+50);ctx.stroke();
}

// Date/time — appears with voice
if(voicePhase>=4){
dateOpacity=Math.min(1,dateOpacity+0.018*dt);
ctx.font='200 '+(W<500?8:10)+'px Inter, -apple-system, sans-serif';
ctx.fillStyle=CYAN_GLOW+dateOpacity*0.4+')';
ctx.fillText(currentDay,cx,txtY+72);
}

ctx.restore();
}

// ── SUBTLE GRAIN — Warmth texture ──
if(darkP>0.4&&W*H<1500000){ // skip on very large screens for perf
var gAlpha=darkP*0.018;
var imgD=ctx.getImageData(0,0,W,H);
var px=imgD.data;
for(var gi=0;gi<px.length;gi+=48){
var n=(Math.random()-0.5)*10*gAlpha;
px[gi]+=n;px[gi+1]+=n;px[gi+2]+=n;
}
ctx.putImageData(imgD,0,0);
}

// ── FADE OUT ──
if(voiceComplete){
fadeOut+=0.008*dt;
if(fadeOut>=1){finishIntro();return}
ctx.fillStyle='rgba(3,6,12,'+fadeOut+')';
ctx.fillRect(0,0,W,H);
}

requestAnimationFrame(animate);
}

function finishIntro(){
intro.style.display='none';
if(audioCtx){try{audioCtx.close()}catch(e){}audioCtx=null}
// Only show login if user is NOT already authenticated
// (Firebase auth may have already hidden login and shown app)
var app=document.getElementById('app');
var alreadyLoggedIn=app&&app.style.display==='block';
if(!alreadyLoggedIn){
var login=document.getElementById('loginScreen');
if(login){
login.style.display='flex';
login.style.opacity='0';
login.style.transition='opacity 1.2s cubic-bezier(0.4,0,0.2,1)';
setTimeout(function(){login.style.opacity='1'},100);
}
}
}

// ── SKIP ──
var skipCount=0;
function handleSkip(){
skipCount++;
if(skipCount>=1&&elapsed>2.5){
voiceComplete=true;
if(window.speechSynthesis)speechSynthesis.cancel();
}
}
intro.addEventListener('click',handleSkip);
intro.addEventListener('touchstart',handleSkip);

setTimeout(function(){
var skip=document.createElement('div');
skip.style.cssText='position:absolute;bottom:30px;left:50%;transform:translateX(-50%);font-size:8px;font-family:Inter,-apple-system,sans-serif;font-weight:200;letter-spacing:4px;color:rgba(140,160,180,0.18);z-index:10001;cursor:pointer;text-transform:uppercase;transition:color .5s,letter-spacing .5s';
skip.textContent='TAP TO SKIP';
skip.onmouseenter=function(){skip.style.color='rgba(140,160,180,0.4)';skip.style.letterSpacing='5px'};
skip.onmouseleave=function(){skip.style.color='rgba(140,160,180,0.18)';skip.style.letterSpacing='4px'};
intro.appendChild(skip);
},4000);

// ── INIT ──
var login=document.getElementById('loginScreen');
if(login)login.style.display='none';

var audioInit=false;
function initAudio(){if(audioInit)return;audioInit=true;getAudio()}
document.addEventListener('click',initAudio,{once:true});
document.addEventListener('touchstart',initAudio,{once:true});
setTimeout(function(){try{getAudio()}catch(e){}},300);

animate();

})();
