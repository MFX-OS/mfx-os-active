// ═══════════════════════════════════════════════
// MFX OS GAMIFICATION ENGINE v2.1
// XP, Levels, Streaks, Achievements, Celebrations
// ═══════════════════════════════════════════════

(function(){
'use strict';

// ── LEVEL SYSTEM ──
var LEVELS=[
{level:1,title:'Rookie',xp:0,icon:'🌱'},
{level:2,title:'Operator',xp:5,icon:'⚙️'},
{level:3,title:'Specialist',xp:15,icon:'🔧'},
{level:4,title:'Pro',xp:30,icon:'⭐'},
{level:5,title:'Expert',xp:50,icon:'💎'},
{level:6,title:'Master',xp:80,icon:'🔥'},
{level:7,title:'Legend',xp:120,icon:'👑'},
{level:8,title:'MFX Elite',xp:175,icon:'🏆'},
{level:9,title:'Untouchable',xp:250,icon:'⚡'},
{level:10,title:'CEO Mode',xp:500,icon:'🚀'}
];

// ── ACHIEVEMENT DEFINITIONS ──
var ACHIEVEMENTS=[
{id:'first_quote',title:'First Quote',desc:'Create your first quote',icon:'📝',check:function(s){return s.quotesCreated>=1}},
{id:'five_quotes',title:'Grinder',desc:'Create 5 quotes',icon:'📊',check:function(s){return s.quotesCreated>=5}},
{id:'first_win',title:'Closer',desc:'Win your first quote',icon:'🏆',check:function(s){return s.quotesWon>=1}},
{id:'ten_wins',title:'Sales Machine',desc:'Win 10 quotes',icon:'💰',check:function(s){return s.quotesWon>=10}},
{id:'streak_3',title:'On Fire',desc:'3-day login streak',icon:'🔥',check:function(s){return s.streak>=3}},
{id:'streak_7',title:'Unstoppable',desc:'7-day streak',icon:'⚡',check:function(s){return s.streak>=7}},
{id:'streak_30',title:'Iron Will',desc:'30-day streak',icon:'🛡️',check:function(s){return s.streak>=30}},
{id:'speed_demon',title:'Speed Demon',desc:'Create & send a quote in one session',icon:'💨',check:function(s){return s.speedQuote}},
{id:'team_player',title:'Team Player',desc:'Post 10 mood updates',icon:'💜',check:function(s){return s.moodPosts>=10}},
{id:'mentor',title:'Mentor',desc:'Comment on 20 posts',icon:'🎓',check:function(s){return s.comments>=20}},
{id:'early_bird',title:'Early Bird',desc:'Log in before 7 AM',icon:'🌅',check:function(s){return s.earlyLogin}},
{id:'night_owl',title:'Night Owl',desc:'Log in after 9 PM',icon:'🌙',check:function(s){return s.lateLogin}},
{id:'perfectionist',title:'Perfectionist',desc:'Revise a quote 3+ times',icon:'✨',check:function(s){return s.maxRevisions>=3}},
{id:'multitasker',title:'Multitasker',desc:'Complete 5 tasks in one day',icon:'🎯',check:function(s){return s.tasksToday>=5}},
{id:'client_whisperer',title:'Client Whisperer',desc:'Add 10 customers',icon:'🤝',check:function(s){return s.customersAdded>=10}}
];

// ── XP REWARDS ──
var XP_ACTIONS={
'quote.create':0.5,
'quote.submit':1.0,
'quote.approve':0.5,
'quote.send':1.5,
'quote.won':3.0,
'quote.revise':0.25,
'task.complete':0.5,
'task.create':0.25,
'mood.post':0.1,
'comment.post':0.1,
'request.submit':0.5,
'request.complete':1.0,
'login.daily':0.5,
'streak.bonus':0.25
};

// ── STORAGE ──
function getGamData(){
var uid=typeof getUserId==='function'?getUserId():'default';
var key='mfx_gam_'+uid;
var d=JSON.parse(localStorage.getItem(key)||'null');
if(!d){
d={xp:0,level:1,streak:0,lastLogin:'',achievements:[],xpLog:[],
quotesCreated:0,quotesWon:0,quotesSent:0,moodPosts:0,comments:0,
tasksCompleted:0,customersAdded:0,maxRevisions:0,speedQuote:false,
earlyLogin:false,lateLogin:false,tasksToday:0,lastTaskDay:'',
totalLogins:0};
}
return d;
}
function saveGamData(d){
var uid=typeof getUserId==='function'?getUserId():'default';
localStorage.setItem('mfx_gam_'+uid,JSON.stringify(d));
}

// ── CORE: AWARD XP ──
function awardXP(action,detail){
var d=getGamData();
var pts=XP_ACTIONS[action]||0;
if(!pts)return;
d.xp+=pts;
d.xpLog.push({action:action,pts:pts,detail:detail||'',at:new Date().toISOString()});
if(d.xpLog.length>200)d.xpLog=d.xpLog.slice(-100);

// Track stats for achievements
if(action==='quote.create')d.quotesCreated++;
if(action==='quote.won')d.quotesWon++;
if(action==='quote.send')d.quotesSent++;
if(action==='mood.post')d.moodPosts++;
if(action==='comment.post')d.comments++;
if(action==='task.complete'){
d.tasksCompleted++;
var today=new Date().toISOString().split('T')[0];
if(d.lastTaskDay===today)d.tasksToday++;
else{d.tasksToday=1;d.lastTaskDay=today}
}

// Check level up
var oldLevel=d.level;
for(var i=LEVELS.length-1;i>=0;i--){
if(d.xp>=LEVELS[i].xp){d.level=LEVELS[i].level;break}
}
var leveled=d.level>oldLevel;

saveGamData(d);

// Show XP popup
showXPToast('+'+pts.toFixed(1)+' XP',action.split('.')[1]);

// Level up celebration
if(leveled){
var lv=LEVELS.find(function(l){return l.level===d.level});
setTimeout(function(){showLevelUp(lv)},800);
}

// Check achievements
setTimeout(function(){checkAchievements(d)},1200);
}

// ── STREAK SYSTEM ──
function updateStreak(){
var d=getGamData();
var today=new Date().toISOString().split('T')[0];
if(d.lastLogin===today)return d.streak;

var yesterday=new Date(Date.now()-86400000).toISOString().split('T')[0];
if(d.lastLogin===yesterday){
d.streak++;
awardXP('streak.bonus','Day '+d.streak);
}else if(d.lastLogin!==today){
if(d.streak>0)showXPToast('Streak reset!','😢');
d.streak=d.lastLogin?0:1;
}
d.lastLogin=today;
d.totalLogins++;

// Time-based achievements
var hour=new Date().getHours();
if(hour<7)d.earlyLogin=true;
if(hour>=21)d.lateLogin=true;

awardXP('login.daily','Daily login');
saveGamData(d);

if(d.streak>=3)showStreakBanner(d.streak);
return d.streak;
}

// ── ACHIEVEMENTS ──
function checkAchievements(d){
if(!d)d=getGamData();
var newBadges=[];
ACHIEVEMENTS.forEach(function(a){
if(d.achievements.indexOf(a.id)===-1&&a.check(d)){
d.achievements.push(a.id);
newBadges.push(a);
}
});
if(newBadges.length){
saveGamData(d);
newBadges.forEach(function(b,i){
setTimeout(function(){showAchievement(b)},i*1500);
});
}
}

// ── UI: XP TOAST ──
function showXPToast(text,subtext){
var el=document.getElementById('xpToast');
if(!el)return;
el.innerHTML='<div style="font-size:14px;font-weight:800">'+text+'</div>'+(subtext?'<div style="font-size:9px;opacity:.8;text-transform:capitalize">'+subtext+'</div>':'');
el.style.display='block';
el.className='xp-pop';
setTimeout(function(){el.className='xp-fade'},1500);
setTimeout(function(){el.style.display='none'},2000);
}

// ── UI: STREAK BANNER ──
function showStreakBanner(days){
var el=document.getElementById('streakBanner');
if(!el)return;
el.innerHTML='🔥 '+days+'-Day Streak! Keep it going!';
el.style.display='block';
setTimeout(function(){el.style.display='none'},4000);
}

// ── UI: LEVEL UP ──
function showLevelUp(lv){
if(!lv)return;
var html='<div style="text-align:center;padding:30px">';
html+='<div class="level-up" style="font-size:64px;margin-bottom:12px">'+lv.icon+'</div>';
html+='<div style="font-size:22px;font-weight:800;color:var(--ac);margin-bottom:4px">LEVEL UP!</div>';
html+='<div style="font-size:16px;font-weight:700;color:var(--tx);margin-bottom:8px">Level '+lv.level+' — '+lv.title+'</div>';
html+='<div class="xp-bar" style="width:200px;margin:12px auto"><div class="xp-bar-fill" style="width:100%"></div></div>';
html+='<button class="btn btn-pr" onclick="closeModal()" style="margin-top:16px;padding:12px 40px">Let\'s Go!</button>';
html+='</div>';
if(typeof openModal==='function')openModal(html);
spawnConfetti();
}

// ── UI: ACHIEVEMENT POPUP ──
function showAchievement(badge){
var html='<div style="text-align:center;padding:24px">';
html+='<div class="badge-bounce" style="font-size:56px;margin-bottom:10px">'+badge.icon+'</div>';
html+='<div style="font-size:11px;color:var(--tx3);text-transform:uppercase;letter-spacing:2px;margin-bottom:4px">Achievement Unlocked</div>';
html+='<div style="font-size:18px;font-weight:800;color:var(--ac);margin-bottom:4px">'+badge.title+'</div>';
html+='<div style="font-size:12px;color:var(--tx2)">'+badge.desc+'</div>';
html+='<button class="btn btn-pr" onclick="closeModal()" style="margin-top:16px;padding:10px 32px">Nice!</button>';
html+='</div>';
if(typeof openModal==='function')openModal(html);
}

// ── CONFETTI ──
function spawnConfetti(){
var colors=['#00e5ff','#38bdf8','#a78bfa','#f472b6','#fbbf24','#fb7185'];
var container=document.createElement('div');
container.style.cssText='position:fixed;inset:0;z-index:9999;pointer-events:none;overflow:hidden';
document.body.appendChild(container);
for(var i=0;i<50;i++){
var c=document.createElement('div');
var color=colors[Math.floor(Math.random()*colors.length)];
var size=Math.random()*8+4;
var left=Math.random()*100;
var delay=Math.random()*0.5;
var dur=Math.random()*2+1.5;
c.style.cssText='position:absolute;top:-10px;left:'+left+'%;width:'+size+'px;height:'+size+'px;background:'+color+';border-radius:'+(Math.random()>.5?'50%':'2px')+';animation:confettiFall '+dur+'s '+delay+'s ease-in forwards;opacity:0.8';
container.appendChild(c);
}
setTimeout(function(){container.remove()},4000);
}

// ── PROFILE BADGE RENDERER ──
function renderGamProfile(){
var d=getGamData();
var lv=LEVELS.find(function(l){return l.level===d.level})||LEVELS[0];
var next=LEVELS.find(function(l){return l.level===d.level+1});
var pct=next?Math.min(100,Math.round((d.xp-lv.xp)/(next.xp-lv.xp)*100)):100;

var h='<div style="text-align:center;padding:16px">';
h+='<div style="font-size:48px;margin-bottom:8px">'+lv.icon+'</div>';
h+='<div style="font-size:18px;font-weight:800;color:var(--ac)">Level '+lv.level+' — '+lv.title+'</div>';
h+='<div style="font-size:12px;color:var(--tx2);margin:4px 0">'+d.xp.toFixed(1)+' XP'+(next?' / '+next.xp+' XP':'')+'</div>';
h+='<div class="xp-bar" style="width:80%;margin:8px auto"><div class="xp-bar-fill" style="width:'+pct+'%"></div></div>';
h+='<div style="display:flex;justify-content:center;gap:16px;margin-top:12px;font-size:11px;color:var(--tx3)">';
h+='<div>🔥 '+d.streak+' day streak</div>';
h+='<div>🏆 '+d.achievements.length+'/'+ACHIEVEMENTS.length+' badges</div>';
h+='<div>📊 '+d.quotesCreated+' quotes</div>';
h+='</div>';

// Achievement grid
h+='<div style="margin-top:16px;text-align:left"><div style="font-size:11px;font-weight:700;color:var(--tx);margin-bottom:6px">Achievements</div>';
h+='<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px">';
ACHIEVEMENTS.forEach(function(a){
var unlocked=d.achievements.indexOf(a.id)!==-1;
h+='<div style="text-align:center;padding:8px 4px;background:'+(unlocked?'var(--bg3)':'var(--bg)')+';border:1px solid '+(unlocked?'var(--ac)':'var(--bdr)')+';border-radius:8px;opacity:'+(unlocked?'1':'.3')+'" title="'+a.title+': '+a.desc+'">';
h+='<div style="font-size:20px">'+a.icon+'</div>';
h+='<div style="font-size:7px;color:'+(unlocked?'var(--ac)':'var(--tx3)')+';margin-top:2px">'+a.title+'</div></div>';
});
h+='</div></div>';
h+='<button class="btn btn-ghost" onclick="closeModal()" style="margin-top:16px;width:100%">Close</button></div>';
return h;
}

// ── HOOK INTO EXISTING FUNCTIONS ──
function hookGamification(){
// Hook quote creation
var _origNewQuote=window.newQuote;
if(_origNewQuote){
window.newQuote=function(tplId){
_origNewQuote(tplId);
awardXP('quote.create','New quote');
};
}

// Hook quote status changes
var _origSetQStatus=window.setQStatus;
if(_origSetQStatus){
window.setQStatus=function(qid,st,ex){
_origSetQStatus(qid,st,ex);
if(st==='sent')awardXP('quote.send','Quote sent');
if(st==='won')awardXP('quote.won','Quote won!');
if(st==='approval')awardXP('quote.submit','Submitted for approval');
};
}

// Hook mood posting
var _origPostMood=window.postMood;
if(_origPostMood){
window.postMood=function(){
_origPostMood();
awardXP('mood.post','Mood update');
};
}

// Hook task completion
var _origCompleteTask=window.completeTask;
if(_origCompleteTask){
window.completeTask=function(tid){
_origCompleteTask(tid);
awardXP('task.complete','Task done');
};
}

// Hook customer save
var _origSaveCust=window.saveCust;
if(_origSaveCust){
window.saveCust=function(c){
var isNew=!window.DB||!window.DB.customers().find(function(x){return x.id===c.id});
_origSaveCust(c);
if(isNew){
var d=getGamData();d.customersAdded=(d.customersAdded||0)+1;saveGamData(d);
awardXP('quote.create','New customer');
}
};
}

// Hook submit for approval
var _origSubmitForApproval=window.submitForApproval;
if(_origSubmitForApproval){
window.submitForApproval=function(qid){
_origSubmitForApproval(qid);
awardXP('quote.submit','Submitted');
};
}

// Add Flex Games button to openFlexZone
var _origOpenFlexGames=window.openFlexGames;
if(_origOpenFlexGames){
window.openFlexGames=function(){
_origOpenFlexGames();
// Inject gamification data into the modal
setTimeout(function(){
var mc=document.getElementById('modalContent');
if(mc){
var d=getGamData();
var lv=LEVELS.find(function(l){return l.level===d.level})||LEVELS[0];
var badge=mc.querySelector('.gam-inject');
if(!badge){
var div=document.createElement('div');
div.className='gam-inject';
div.style.cssText='background:var(--bg3);border:1px solid var(--ac);border-radius:8px;padding:10px;margin:8px 0;text-align:center';
div.innerHTML='<div style="font-size:20px">'+lv.icon+'</div><div style="font-size:10px;color:var(--ac);font-weight:700">Level '+lv.level+' — '+lv.title+'</div><div class="xp-bar"><div class="xp-bar-fill" style="width:60%"></div></div>';
mc.insertBefore(div,mc.firstChild.nextSibling);
}
}
},200);
};
}
}

// ── INIT ──
window.initGamification=function(){
hookGamification();
updateStreak();

// Rebuild calcPoints to include XP
var _origCalcPoints=window.calcPoints;
if(_origCalcPoints){
window.calcPoints=function(user,qs){
var r=_origCalcPoints(user,qs);
// If it's the current user, add gamification XP
if(typeof getUserName==='function'&&user===getUserName()){
var d=getGamData();
if(typeof r==='object')r.pts+=d.xp;
else r+=d.xp;
}
return r;
};
}
};

// Expose for Flex Zone profile
window.renderGamProfile=renderGamProfile;
window.awardXP=awardXP;
window.getGamData=getGamData;
window.GAM_LEVELS=LEVELS;
window.GAM_ACHIEVEMENTS=ACHIEVEMENTS;

})();
