// ═══════════════════════════════════════════════
// MFX OS SOUND ENGINE v1.0
// Pure Web Audio API — zero external files
// Synth-generated sounds for every action
// ═══════════════════════════════════════════════

(function(){
'use strict';

var ctx=null;
var enabled=true;
var volume=0.3;

function getCtx(){
if(!ctx){try{ctx=new(window.AudioContext||window.webkitAudioContext)()}catch(e){enabled=false}}
return ctx;
}

// Resume on first user interaction (browser autoplay policy)
function resumeAudio(){
var c=getCtx();
if(c&&c.state==='suspended')c.resume();
}
document.addEventListener('click',resumeAudio,{once:false});
document.addEventListener('touchstart',resumeAudio,{once:false});

// ── CORE OSCILLATOR ──
function playTone(freq,type,dur,vol,delay){
if(!enabled)return;
var c=getCtx();if(!c)return;
var osc=c.createOscillator();
var gain=c.createGain();
osc.connect(gain);gain.connect(c.destination);
osc.type=type||'sine';
osc.frequency.value=freq;
var v=(vol||volume)*0.4;
var t=c.currentTime+(delay||0);
gain.gain.setValueAtTime(0,t);
gain.gain.linearRampToValueAtTime(v,t+0.01);
gain.gain.exponentialRampToValueAtTime(0.001,t+(dur||0.15));
osc.start(t);osc.stop(t+(dur||0.15)+0.01);
}

// ── NOISE GENERATOR ──
function playNoise(dur,vol){
if(!enabled)return;
var c=getCtx();if(!c)return;
var bufSize=c.sampleRate*(dur||0.05);
var buf=c.createBuffer(1,bufSize,c.sampleRate);
var data=buf.getChannelData(0);
for(var i=0;i<bufSize;i++)data[i]=(Math.random()*2-1)*0.3;
var src=c.createBufferSource();
var gain=c.createGain();
var filter=c.createBiquadFilter();
src.buffer=buf;
filter.type='highpass';filter.frequency.value=3000;
src.connect(filter);filter.connect(gain);gain.connect(c.destination);
gain.gain.setValueAtTime((vol||volume)*0.2,c.currentTime);
gain.gain.exponentialRampToValueAtTime(0.001,c.currentTime+(dur||0.05));
src.start();
}

// ══════════════════════════════
// SOUND LIBRARY — Named Effects
// ══════════════════════════════

var SFX={

// ── UI INTERACTIONS ──
tap:function(){
playTone(800,'sine',0.04,0.15);
},

click:function(){
playTone(600,'triangle',0.05,0.2);
playTone(900,'triangle',0.03,0.1,0.02);
},

toggle:function(){
playTone(500,'sine',0.06,0.15);
playTone(750,'sine',0.06,0.12,0.06);
},

back:function(){
playTone(600,'sine',0.06,0.15);
playTone(400,'sine',0.08,0.12,0.05);
},

open:function(){
playTone(400,'sine',0.08,0.15);
playTone(600,'sine',0.08,0.12,0.06);
playTone(800,'sine',0.1,0.1,0.12);
},

close:function(){
playTone(800,'sine',0.06,0.12);
playTone(500,'sine',0.08,0.1,0.05);
},

// ── SUCCESS / POSITIVE ──
success:function(){
playTone(523,'sine',0.12,0.2);
playTone(659,'sine',0.12,0.2,0.1);
playTone(784,'sine',0.18,0.25,0.2);
},

win:function(){
playTone(523,'sine',0.1,0.2);
playTone(659,'sine',0.1,0.2,0.08);
playTone(784,'sine',0.1,0.2,0.16);
playTone(1047,'sine',0.25,0.3,0.24);
},

complete:function(){
playTone(880,'triangle',0.08,0.2);
playTone(1100,'triangle',0.12,0.15,0.08);
},

points:function(){
playTone(1200,'sine',0.06,0.15);
playTone(1600,'sine',0.06,0.12,0.06);
playTone(2000,'sine',0.08,0.1,0.12);
},

// ── XP & GAMIFICATION ──
xp:function(){
playTone(800,'sine',0.05,0.12);
playTone(1200,'sine',0.05,0.1,0.04);
playTone(1600,'sine',0.06,0.08,0.08);
},

levelUp:function(){
var notes=[523,659,784,1047,784,1047,1319];
notes.forEach(function(n,i){
playTone(n,'sine',0.12,0.2,i*0.1);
});
setTimeout(function(){playNoise(0.08,0.3)},notes.length*100);
},

achievement:function(){
playTone(784,'sine',0.15,0.2);
playTone(988,'sine',0.15,0.2,0.12);
playTone(1175,'sine',0.2,0.25,0.24);
playTone(1568,'sine',0.3,0.3,0.4);
},

streak:function(){
[600,750,900,1050,1200].forEach(function(f,i){
playTone(f,'sine',0.06,0.15,i*0.05);
});
},

// ── NEGATIVE / WARNING ──
error:function(){
playTone(200,'sawtooth',0.15,0.15);
playTone(150,'sawtooth',0.2,0.12,0.12);
},

warning:function(){
playTone(440,'triangle',0.1,0.15);
playTone(440,'triangle',0.1,0.12,0.15);
playTone(440,'triangle',0.1,0.1,0.3);
},

denied:function(){
playTone(300,'square',0.12,0.1);
playTone(200,'square',0.2,0.1,0.12);
},

// ── NOTIFICATIONS ──
notify:function(){
playTone(880,'sine',0.08,0.15);
playTone(1100,'sine',0.1,0.12,0.1);
},

message:function(){
playTone(660,'sine',0.06,0.12);
playTone(880,'sine',0.08,0.15,0.08);
},

mention:function(){
playTone(1000,'sine',0.05,0.15);
playTone(1200,'sine',0.05,0.12,0.04);
playTone(1500,'sine',0.05,0.1,0.08);
playTone(1200,'sine',0.08,0.12,0.12);
},

// ── ACTIONS ──
send:function(){
[400,500,650,850,1100].forEach(function(f,i){
playTone(f,'sine',0.06,0.12+i*0.02,i*0.04);
});
},

save:function(){
playTone(600,'triangle',0.06,0.12);
playTone(800,'triangle',0.08,0.1,0.06);
},

create:function(){
playTone(440,'sine',0.08,0.15);
playTone(554,'sine',0.08,0.15,0.06);
playTone(659,'sine',0.12,0.2,0.12);
},

del:function(){
playTone(400,'sawtooth',0.08,0.1);
playTone(300,'sawtooth',0.1,0.08,0.06);
playTone(200,'sawtooth',0.15,0.08,0.12);
},

// ── MOOD / FUN ──
mood:function(){
playTone(523,'sine',0.1,0.15);
playTone(659,'sine',0.08,0.12,0.08);
},

confetti:function(){
for(var i=0;i<8;i++){
var f=800+Math.random()*1200;
playTone(f,'sine',0.04,0.06,i*0.04);
}
playNoise(0.06,0.2);
},

whoosh:function(){
if(!enabled)return;
var c=getCtx();if(!c)return;
var osc=c.createOscillator();
var gain=c.createGain();
osc.connect(gain);gain.connect(c.destination);
osc.type='sine';
osc.frequency.setValueAtTime(300,c.currentTime);
osc.frequency.exponentialRampToValueAtTime(1200,c.currentTime+0.15);
gain.gain.setValueAtTime(volume*0.2,c.currentTime);
gain.gain.exponentialRampToValueAtTime(0.001,c.currentTime+0.2);
osc.start();osc.stop(c.currentTime+0.21);
},

powerUp:function(){
[262,330,392,523,659,784,1047].forEach(function(f,i){
playTone(f,'sine',0.08,0.1+i*0.02,i*0.06);
});
},

coin:function(){
playTone(988,'square',0.06,0.08);
playTone(1319,'square',0.12,0.1,0.06);
}
};

// ══════════════════════════════
// HOOK INTO EXISTING APP
// ══════════════════════════════

function hookSounds(){
// Toast sounds
var _origToast=window.toast;
if(_origToast){
window.toast=function(msg,type){
_origToast(msg,type);
if(type==='ok')SFX.success();
else if(type==='err')SFX.error();
else SFX.notify();
};
}

// Modal sounds
var _origOpenModal=window.openModal;
if(_origOpenModal){
window.openModal=function(html){
SFX.open();
_origOpenModal(html);
};
}
var _origCloseModal=window.closeModal;
if(_origCloseModal){
window.closeModal=function(){
SFX.close();
_origCloseModal();
};
}

// Navigation sounds
var _origGoView=window.goView;
if(_origGoView){
window.goView=function(v){
SFX.whoosh();
_origGoView(v);
};
}

// Quote creation
var _origNewQuote2=window.newQuote;
if(_origNewQuote2){
window.newQuote=function(tplId){
SFX.create();
_origNewQuote2(tplId);
};
}

// Status changes with contextual sounds
var _origSetQStatus2=window.setQStatus;
if(_origSetQStatus2){
window.setQStatus=function(qid,st,ex){
if(st==='won')setTimeout(function(){SFX.win()},200);
else if(st==='sent')SFX.send();
else if(st==='lost')SFX.denied();
else if(st==='approval')SFX.send();
_origSetQStatus2(qid,st,ex);
};
}

// Task complete
var _origCompleteTask2=window.completeTask;
if(_origCompleteTask2){
window.completeTask=function(tid){
SFX.complete();
_origCompleteTask2(tid);
};
}

// Mood post
var _origPostMood2=window.postMood;
if(_origPostMood2){
window.postMood=function(){
SFX.mood();
_origPostMood2();
};
}

// Hamburger
var _origToggleHam=window.toggleHamburger;
if(_origToggleHam){
window.toggleHamburger=function(){
SFX.toggle();
_origToggleHam();
};
}

// XP award sounds
var _origAwardXP=window.awardXP;
if(_origAwardXP){
window.awardXP=function(action,detail){
SFX.xp();
_origAwardXP(action,detail);
};
}

// Delete sounds
var _origDelQuote=window.delQuote;
if(_origDelQuote){
window.delQuote=function(qid){
SFX.del();
_origDelQuote(qid);
};
}

// Save customer
var _origSaveCust2=window.saveCust;
if(_origSaveCust2){
window.saveCust=function(c){
SFX.save();
_origSaveCust2(c);
};
}

// Like sounds
var _origLikeMood=window.likeMoodPost;
if(_origLikeMood){
window.likeMoodPost=function(id){
SFX.coin();
_origLikeMood(id);
};
}
}

// ── SETTINGS ──
window.MFX_SFX=SFX;
window.toggleSound=function(){
enabled=!enabled;
localStorage.setItem('mfx_sound',enabled?'1':'0');
if(enabled)SFX.success();
window.toast(enabled?'Sound ON':'Sound OFF','ok');
};
window.setSoundVolume=function(v){
volume=Math.max(0,Math.min(1,v));
localStorage.setItem('mfx_volume',volume);
};

// ── INIT ──
window.initSounds=function(){
var saved=localStorage.getItem('mfx_sound');
if(saved==='0')enabled=false;
var savedVol=localStorage.getItem('mfx_volume');
if(savedVol)volume=parseFloat(savedVol);
hookSounds();
};

})();
