function renderDash(){
var el=$('v-dashboard');if(!el)return;
var me=getUserName();var p=getMFXProfile();
var qs=DB.quotes();var now=new Date();
var today=now.toISOString().split('T')[0];

// Update topbar
updateTopBar();

var h='';

// ═══ OVERDUE ALERT BANNER ═══
if(fbDb){fbDb.collection('requests').where('assignedTo','==',me).get().then(function(snap){
var overdue=snap.docs.filter(function(d){var r=d.data();return r.targetDate&&new Date(r.targetDate)<now&&r.status!=='closed'&&r.status!=='completed'});
var reel=$('alertReel');
if(overdue.length>=5&&reel){reel.style.display='block';reel.innerHTML='⚠ '+overdue.length+' OVERDUE — Complete before write-up!';document.body.classList.add('overdue-border')}
else if(overdue.length>0&&reel){reel.style.display='block';reel.innerHTML='⚠ '+overdue.length+' request'+(overdue.length>1?'s':'')+' overdue';reel.style.background='linear-gradient(90deg,#78350f,#92400e,#78350f)';reel.style.color='#fbbf24'}
else if(reel){reel.style.display='none';document.body.classList.remove('overdue-border')}
}).catch(function(){})}

// ═══ MOOD FEED SUBMISSION ═══
h+='<div class="card" style="border:1px solid var(--ac);background:linear-gradient(135deg,var(--bg3),var(--bg2))">';
h+='<div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">';
['😊','🔥','💪','🎯','😤','☕','🚀','💜','⚡','🧠'].forEach(function(m){
h+='<span style="font-size:20px;cursor:pointer;transition:transform .1s" onclick="selectMood(\''+m+'\')" id="mood_'+m+'">'+m+'</span>'});
h+='</div>';
h+='<div style="display:flex;gap:6px"><textarea id="moodInput" placeholder="What\'s on your mind? Share a vibe, shoutout, update..." style="flex:1;min-height:36px;padding:8px;background:var(--inp);border:1px solid var(--bdr);border-radius:10px;color:var(--tx);font-size:11px;resize:none"></textarea>';
h+='<button class="btn btn-pr btn-sm" onclick="postMood()" style="align-self:flex-end;padding:8px 14px">Post</button></div></div>';

// ═══ MOOD FEED REEL ═══
h+='<div id="moodFeed" style="margin-bottom:10px"><div style="color:var(--tx3);font-size:10px;text-align:center;padding:10px">Loading feed...</div></div>';

// ═══ TODAY'S TO-DO ═══
h+='<div style="font-size:12px;font-weight:700;color:var(--ac);margin-bottom:6px;display:flex;justify-content:space-between;align-items:center">📋 Today\'s To-Do<button class="btn btn-ghost btn-xs" onclick="openMeetings()">View All →</button></div>';
h+='<div id="dashTodoList" style="margin-bottom:10px"><div style="color:var(--tx3);font-size:10px;padding:6px">Loading...</div></div>';

// ═══ ALERTS ═══
h+='<div id="dashAlerts" style="margin-bottom:10px"></div>';

// ═══ QUICK LINKS ═══
h+='<div style="font-size:12px;font-weight:700;color:var(--ac);margin-bottom:6px">⚡ Quick Actions</div>';
h+='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px">';
var links=[
{icon:'📊',name:'New Quote',fn:'newQuote()'},
{icon:'📋',name:'Request',fn:'openRFQInbox()'},
{icon:'📅',name:'Calendar',fn:'openMeetings()'},
{icon:'📌',name:'Board',fn:'openTeamChat()'},
{icon:'👥',name:'Clients',fn:"goView('customers')"},
{icon:'⚡',name:'Flex Zone',fn:'openFlexZone()'},
{icon:'🔒',name:'Approvals',fn:'openCEOPortal()'},
{icon:'📬',name:'Inbox',fn:'openSupportInbox()'}
];
links.forEach(function(l){
h+='<div style="background:var(--bg3);border:1px solid var(--bdr);border-radius:10px;padding:10px 6px;text-align:center;cursor:pointer;transition:all .15s" onclick="'+l.fn+'" onmousedown="this.style.transform=\'scale(.95)\'" onmouseup="this.style.transform=\'\'">';
h+='<div style="font-size:20px;margin-bottom:3px">'+l.icon+'</div>';
h+='<div style="font-size:8px;color:var(--tx2);font-weight:600">'+l.name+'</div></div>'});
h+='</div>';

// ═══ MY QUOTES SNAPSHOT ═══
var myQ=qs.filter(function(q){return q.createdBy===me});
var qDraft=myQ.filter(function(q){return q.status==='draft'}).length;
var qReady=myQ.filter(function(q){return q.status==='ready'}).length;
var qSent=myQ.filter(function(q){return q.status==='sent'}).length;
var qWon=myQ.filter(function(q){return q.status==='won'}).length;
h+='<div style="font-size:12px;font-weight:700;color:var(--ac);margin-bottom:6px">📊 My Quotes</div>';
h+='<div style="display:flex;gap:4px;margin-bottom:10px">';
h+='<div style="flex:1;background:var(--bg3);border-radius:8px;padding:8px;text-align:center;cursor:pointer" onclick="goView(\'quotes\')"><div style="font-size:16px;font-weight:800;color:var(--neon-purple)">'+qDraft+'</div><div style="font-size:8px;color:var(--tx3)">Drafts</div></div>';
h+='<div style="flex:1;background:var(--bg3);border-radius:8px;padding:8px;text-align:center;cursor:pointer" onclick="goView(\'quotes\')"><div style="font-size:16px;font-weight:800;color:var(--neon-blue)">'+qReady+'</div><div style="font-size:8px;color:var(--tx3)">Ready</div></div>';
h+='<div style="flex:1;background:var(--bg3);border-radius:8px;padding:8px;text-align:center;cursor:pointer" onclick="goView(\'quotes\')"><div style="font-size:16px;font-weight:800;color:var(--neon-cyan)">'+qSent+'</div><div style="font-size:8px;color:var(--tx3)">Sent</div></div>';
h+='<div style="flex:1;background:var(--bg3);border-radius:8px;padding:8px;text-align:center;cursor:pointer" onclick="goView(\'quotes\')"><div style="font-size:16px;font-weight:800;color:var(--gn)">'+qWon+'</div><div style="font-size:8px;color:var(--tx3)">Won</div></div></div>';

el.innerHTML=h;

// Load mood feed
loadMoodFeed();
// Load today's tasks
loadDashTodo(me,today);
// Load alerts
loadDashAlerts(me,qs);
}

function updateTopBar(){
var me=getUserName();var p=getMFXProfile();
var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
var now=new Date();
var dayEl=$('topDayOfWeek');if(dayEl)dayEl.textContent=days[now.getDay()]+' '+now.toLocaleDateString('en-US',{month:'short',day:'numeric'});
var nameEl=$('topUserName');if(nameEl)nameEl.textContent=me;
var roleEl=$('topUserRole');if(roleEl)roleEl.textContent=p.role||'Team Member';
var deptEl=$('topDeptBadge');
if(deptEl){
var dept=p.dept||'Operations';
var deptColors={Operations:'var(--dept-ops)',Estimation:'var(--dept-est)','Pre-Press':'var(--dept-pp)',Production:'var(--dept-prod)',Quality:'var(--dept-qa)',Accounting:'var(--dept-acct)',Sales:'var(--dept-sales)',Administration:'var(--dept-admin)'};
var deptShort={Operations:'OPS',Estimation:'EST','Pre-Press':'PP',Production:'PROD',Quality:'QA',Accounting:'ACCT',Sales:'SALES',Administration:'ADMIN'};
deptEl.textContent=deptShort[dept]||dept.substring(0,4).toUpperCase();
deptEl.style.background=deptColors[dept]||'var(--ac)';
deptEl.style.color='#000'}}

function selectMood(emoji){
window._selectedMood=emoji;
document.querySelectorAll('[id^="mood_"]').forEach(function(el){el.style.transform=''});
var el=$('mood_'+emoji);if(el)el.style.transform='scale(1.4)'}

function postMood(){
var msg=($('moodInput')||{}).value;var mood=window._selectedMood||'';
if(!msg&&!mood)return toast('Choose an emoji or write something','err');
if(!msg)msg=mood;
fbDb.collection('microfeed').add({
text:msg,mood:mood,user:getUserName(),
timestamp:firebase.firestore.FieldValue.serverTimestamp(),
likes:0,comments:[],edited:false
}).then(function(){
$('moodInput').value='';window._selectedMood='';
document.querySelectorAll('[id^="mood_"]').forEach(function(el){el.style.transform=''});
toast('Posted!','ok');loadMoodFeed()}).catch(function(e){toast(e.message,'err')})}

function loadMoodFeed(){
var el=$('moodFeed');if(!el||!fbDb)return;
var cutoff=new Date(Date.now()-7*24*60*60*1000);
fbDb.collection('microfeed').orderBy('timestamp','desc').limit(30).get().then(function(snap){
var posts=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())}).filter(function(p){
if(!p.timestamp)return true;
return new Date(p.timestamp.seconds*1000)>cutoff});
var h='';
posts.forEach(function(p){
var ts=p.timestamp?new Date(p.timestamp.seconds*1000):new Date();
var ago=getTimeAgo(ts);
h+='<div class="mood-card fade-in">';
h+='<div style="display:flex;justify-content:space-between;align-items:center">';
h+='<div style="display:flex;align-items:center;gap:6px"><span style="font-size:16px">'+(p.mood||'💭')+'</span><strong style="color:var(--ac);font-size:11px">'+p.user+'</strong></div>';
h+='<span style="font-size:8px;color:var(--tx3)">'+ago+'</span></div>';
h+='<div style="font-size:12px;color:var(--tx);margin:4px 0;line-height:1.4">'+p.text.replace(/@(\w+)/g,'<span style="color:var(--ac)">@$1</span>')+'</div>';
// Comments
if(p.comments&&p.comments.length){p.comments.forEach(function(c){
h+='<div style="margin:2px 0 2px 20px;padding:2px 8px;background:var(--bg3);border-left:2px solid var(--ac);border-radius:0 4px 4px 0;font-size:9px"><strong style="color:var(--ac)">'+c.by+'</strong> '+c.text+'</div>'})}
h+='<div style="display:flex;gap:10px;font-size:9px;margin-top:4px">';
h+='<span style="cursor:pointer" onclick="likeMoodPost(\''+p.id+'\')">👍 '+(p.likes||0)+'</span>';
h+='<span style="cursor:pointer" onclick="commentMoodPost(\''+p.id+'\')">💬 '+(p.comments?p.comments.length:0)+'</span>';
if(p.user===getUserName())h+='<span style="cursor:pointer" onclick="editMoodPost(\''+p.id+'\')">✏ Edit</span>';
h+='</div></div>'});
if(!posts.length)h='<div style="color:var(--tx3);font-size:10px;text-align:center;padding:12px">No posts yet — drop a vibe!</div>';
el.innerHTML=h}).catch(function(e){el.innerHTML=e.message})}

function getTimeAgo(date){
var s=Math.floor((new Date()-date)/1000);
if(s<60)return'just now';if(s<3600)return Math.floor(s/60)+'m ago';
if(s<86400)return Math.floor(s/3600)+'h ago';return Math.floor(s/86400)+'d ago'}

function likeMoodPost(id){fbDb.collection('microfeed').doc(id).update({likes:firebase.firestore.FieldValue.increment(1)}).then(function(){loadMoodFeed()})}

function commentMoodPost(id){var text=prompt('Comment:');if(!text)return;
fbDb.collection('microfeed').doc(id).get().then(function(doc){var d=doc.data();var c=d.comments||[];
c.push({by:getUserName(),text:text.trim(),at:fD(new Date().toISOString())});
fbDb.collection('microfeed').doc(id).update({comments:c}).then(function(){loadMoodFeed()})})}

function editMoodPost(id){fbDb.collection('microfeed').doc(id).get().then(function(doc){var d=doc.data();
if(d.user!==getUserName())return toast('Not yours','err');
var newText=prompt('Edit:',d.text);if(!newText)return;
fbDb.collection('microfeed').doc(id).update({text:newText,edited:true}).then(function(){loadMoodFeed();toast('Updated','ok')})})}

function loadDashTodo(me,today){
var el=$('dashTodoList');if(!el||!fbDb)return;
fbDb.collection('tasks').where('assignedTo','==',me).where('completed','==',false).limit(10).get().then(function(snap){
var tasks=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())}).filter(function(t){return!t.completed});
var todayTasks=tasks.filter(function(t){return t.date===today});
var overdue=tasks.filter(function(t){return t.date&&t.date<today});
var h='';
if(overdue.length){overdue.forEach(function(t){
h+='<div class="card blink-danger" style="padding:6px 10px;cursor:pointer" onclick="openTaskDetail(\''+t.id+'\')"><div style="display:flex;justify-content:space-between"><span style="font-size:11px;color:var(--rd)">'+(t.type==='task'?'📋':'📅')+' '+t.title+'</span><span style="font-size:8px;color:var(--rd)">OVERDUE</span></div></div>'})}
if(todayTasks.length){todayTasks.forEach(function(t){
h+='<div class="card" style="padding:6px 10px;border-left:3px solid var(--ac);cursor:pointer" onclick="openTaskDetail(\''+t.id+'\')"><span style="font-size:11px">'+(t.type==='task'?'📋':'📅')+' '+t.title+'</span></div>'})}
if(!overdue.length&&!todayTasks.length)h='<div style="color:var(--tx3);font-size:10px;padding:6px">All clear — nothing due today 🎉</div>';
el.innerHTML=h}).catch(function(){el.innerHTML=''})}

function loadDashAlerts(me,qs){
var el=$('dashAlerts');if(!el)return;
var h='';
var stale=qs.filter(function(q){return q.status==='draft'&&q.createdBy===me&&q.updatedAt&&(new Date()-new Date(q.updatedAt))>3*86400000});
if(stale.length){h+='<div class="card blink-warn" style="padding:8px;border-left:3px solid var(--or)"><div style="font-size:10px;color:var(--or);font-weight:600">⚠ '+stale.length+' stale draft'+(stale.length>1?'s':'')+' — update or submit</div></div>'}
var unanswered=qs.filter(function(q){return q.status==='sent'&&q.createdBy===me&&q.sentAt&&(new Date()-new Date(q.sentAt))>7*86400000});
if(unanswered.length){h+='<div class="card" style="padding:8px;border-left:3px solid var(--neon-blue)"><div style="font-size:10px;color:var(--neon-blue);font-weight:600">📨 '+unanswered.length+' quote'+(unanswered.length>1?'s':'')+' sent 7+ days ago — follow up</div></div>'}
el.innerHTML=h}


function renderQuotes(){
var qs=DB.quotes();var alerts=getQuoteAlerts(qs);var an=getQuoteAnalytics(qs);
var qtop='<div style="display:flex;gap:8px;margin-bottom:10px"><button onclick="newQuote()" style="flex:1;background:var(--ac);color:#fff;padding:12px;font-size:13px;font-weight:700;border:none;border-radius:8px;cursor:pointer">➕ New Quote</button><button onclick="openRFQRequest()" style="flex:1;background:var(--bg3);color:var(--ac);padding:12px;font-size:13px;font-weight:700;border:1px solid var(--ac);border-radius:8px;cursor:pointer">📋 Request</button></div>';
qtop+='<div style="display:flex;gap:6px;margin-bottom:8px;overflow-x:auto">';
qtop+='<div style="background:var(--bg3);border-radius:6px;padding:6px 10px;text-align:center;min-width:60px"><div style="font-size:14px;font-weight:700">'+an.weekTotal+'</div><div style="font-size:8px;color:var(--tx3)">This Week</div></div>';
qtop+='<div style="background:var(--bg3);border-radius:6px;padding:6px 10px;text-align:center;min-width:60px"><div style="font-size:14px;font-weight:700;color:var(--gn)">'+an.winRate+'%</div><div style="font-size:8px;color:var(--tx3)">Win Rate</div></div>';
qtop+='<div style="background:var(--bg3);border-radius:6px;padding:6px 10px;text-align:center;min-width:60px"><div style="font-size:14px;font-weight:700">'+an.avgDaysToWin+'d</div><div style="font-size:8px;color:var(--tx3)">Avg to Win</div></div>';
qtop+='<div style="background:var(--bg3);border-radius:6px;padding:6px 10px;text-align:center;min-width:60px"><div style="font-size:14px;font-weight:700;color:var(--rd)">'+an.weekLost+'</div><div style="font-size:8px;color:var(--tx3)">Lost</div></div></div>';
if(alerts.length){qtop+='<div style="margin-bottom:8px">';alerts.slice(0,5).forEach(function(a){qtop+='<div style="background:var(--bg3);border-left:3px solid '+a.color+';padding:6px 10px;margin-bottom:4px;border-radius:0 6px 6px 0;font-size:10px">'+a.icon+' '+a.text+'</div>'});qtop+='</div>'}
var qFilterEl=$('v-quotes');if(qFilterEl)qFilterEl.insertAdjacentHTML('afterbegin','');
window._quoteTopHTML=qtop;
_origRenderQuotes();}
function _origRenderQuotes(){const qs=DB.quotes();const filt=S.qFilter==='all'?qs:qs.filter(q=>q.status===S.qFilter);const sr=S.qSearch?filt.filter(q=>(q.quoteNum+' '+q.fields.custCo+' '+q.fields.jobDesc).toLowerCase().includes(S.qSearch.toLowerCase())):filt;
const ct=st=>qs.filter(q=>q.status===st).length;
$('v-quotes').innerHTML=(window._quoteTopHTML||'')+`<div class="search-bar"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="Search..." value="${S.qSearch}" oninput="S.qSearch=this.value;renderQuotes()"></div>
<div class="filters">${['all','draft','approval','ready','sent','won','lost','rejected','archived'].map(f=>`<div class="fbtn ${S.qFilter===f?'active':''}" onclick="S.qFilter='${f}';renderQuotes()">${f[0].toUpperCase()+f.slice(1)} (${f==='all'?qs.length:ct(f)})</div>`).join('')}</div>
${sr.length?sr.map(q=>`<div class="qcard" onclick="openEditor('${q.id}')"><div class="qcard-top"><div><span class="qcard-num">${q.quoteNum}</span><span class="qcard-rev">Rev ${q.rev}</span></div><span class="pill pill-${q.status}">${q.status}</span></div><div class="qcard-co">${q.fields.custCo||'—'}</div><div class="qcard-desc">${q.fields.jobDesc||'—'}</div><div style="font-size:10px;color:var(--tx3);margin:2px 0;display:flex;gap:6px;flex-wrap:wrap">${q.fields.shapeType?'<span>'+q.fields.shapeType+'</span>':''}${q.fields.sA?'<span>'+q.fields.sA+'×'+q.fields.sar+'"</span>':''}${q.fields.colors?'<span>'+q.fields.colors+'c</span>':''}${q.qtys?'<span>'+q.qtys.length+' qty</span>':''}</div><div class="qcard-bot"><span class="qcard-date">${fD(q.updatedAt)}${q.createdBy?' · '+q.createdBy:''}</span><button class="btn btn-ghost btn-xs" onclick="event.stopPropagation();showQA('${q.id}')">⋯</button></div></div>`).join(''):'<div class="empty-state"><div class="ico">📁</div><p>No quotes</p><button class="btn btn-pr" onclick="newQuote()">+ New</button></div>'}`}

function showQA(qid){const q=getQ(qid);if(!q)return;
openModal(`<div class="modal-title">${q.quoteNum} Rev ${q.rev}</div>
<button class="btn btn-pr" onclick="closeModal();openEditor('${qid}')">✏️ Edit</button>
<button class="btn btn-ghost" onclick="closeModal();dupQuote('${qid}',true)">📋 New Revision</button>
<button class="btn btn-ghost" onclick="closeModal();dupQuote('${qid}',false)">📄 Duplicate</button>
${q.status==='draft'?`<button class="btn btn-ghost" onclick="closeModal();submitForApproval('${qid}')">🔒 Submit for Approval</button>`:''}
${q.status==='ready'?`<button class="btn btn-pr" onclick="closeModal();S.editId='${qid}';emailQuoteWithPDF()">✉ Email Quote</button>`:``}${q.status==='approval'?`<button class="btn btn-pr" onclick="closeModal();ceoApprove('${qid}')">🔑 CEO Approve</button>`:''}
${q.status==='sent'?`<button class="btn btn-gn" onclick="closeModal();showWon('${qid}')">🏆 Won</button><button class="btn btn-rd" onclick="closeModal();showLost('${qid}')">❌ Lost</button>`:''}
${q.status!=='archived'?`<button class="btn btn-ghost" onclick="closeModal();setQStatus('${qid}','archived')">📦 Archive</button>`:`<button class="btn btn-ghost" onclick="closeModal();setQStatus('${qid}','draft')">↩ Unarchive</button>`}
<button class="btn btn-rd" onclick="closeModal();delQuote('${qid}')">🗑 Delete</button>
<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`)}

function showWon(qid){var q=DB.quotes().find(function(x){return x.id===qid});var qtys=q?(q.qtys||[]):[];openModal(`<div class="modal-title">🏆 Mark Won</div><div class="fg" style="margin-bottom:8px"><label>Order Amount ($) <span class="req">*</span></label><input id="wonAmt" type="number" placeholder="Total order value" style="width:100%;padding:6px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx)"></div><div class="fg" style="margin-bottom:8px"><label>PO Number <span class="req">*</span></label><input id="wonPO" placeholder="Purchase order #" style="width:100%;padding:6px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx)"></div><div class="fg" style="margin-bottom:8px"><label>Number of SKUs</label><input id="wonSKUs" type="number" placeholder="e.g. 1, 3, 5" value="1" style="width:100%;padding:6px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx)"></div><div class="fg" style="margin-bottom:8px"><label>Quantity Chosen</label><select id="wonQty" style="width:100%;padding:6px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx)">${qtys.map(function(q2){return'<option value="'+q2+'">'+Number(q2).toLocaleString()+'</option>'}).join('')}<option value="custom">Custom...</option></select></div><div class="fg" style="margin-bottom:8px"><label>Date Received <span class="req">*</span></label><input id="wonDate" type="date" value="${new Date().toISOString().split('T')[0]}" style="width:100%;padding:6px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx)"></div><div class="fg" style="margin-bottom:8px"><label>Expected Delivery Date</label><input id="wonDelivery" type="date" style="width:100%;padding:6px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx)"></div><button class="btn btn-gn" onclick="confirmWon('${qid}')" style="width:100%">✅ Confirm Won</button><button class="btn btn-ghost" onclick="closeModal()" style="width:100%;margin-top:4px">Cancel</button>`)}
function confirmWon(qid){const amt=parseFloat($('wonAmt').value);const po=$('wonPO').value.trim();const dt=$('wonDate').value;if(!amt||amt<=0)return toast('Enter order amount','err');if(!po)return toast('Enter PO number','err');if(!dt)return toast('Enter date received','err');var qtyVal=$('wonQty').value;if(qtyVal==='custom')qtyVal=prompt('Enter quantity:')||'';var skus=parseInt(($('wonSKUs')||{}).value)||1;var delivery=($('wonDelivery')||{}).value||'';setQStatus(qid,'won',{wonAmount:amt,poNumber:po,wonDate:dt,wonSKUs:skus,wonQty:qtyVal,expectedDelivery:delivery});closeModal()}
function showLost(qid){openModal(`<div class="modal-title">❌ Mark Lost</div><div class="fg"><label>Reason</label><input id="lostR" placeholder="Price, lead time..."></div><button class="btn btn-rd" onclick="setQStatus('${qid}','lost',{lostReason:$('lostR').value});closeModal()">Confirm</button><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`)}

// CUSTOMERS
function renderCust(){const cs=DB.customers();const sr=S.cSearch?cs.filter(c=>(c.company+' '+c.contact+' '+(c.industry||'')+' '+(c.email||'')).toLowerCase().includes(S.cSearch.toLowerCase())):cs;
const aq=DB.quotes();const withQ=cs.filter(c=>aq.some(q=>q.customerId===c.id||q.fields.custCo===c.company)).length;
$('v-customers').innerHTML=`<div style="display:flex;gap:6px;margin-bottom:8px;font-size:11px"><div style="flex:1;background:var(--srf);border:1px solid var(--bdr);border-radius:6px;padding:6px 8px;text-align:center"><div style="font-size:16px;font-weight:700;color:var(--ac)">${cs.length}</div>Total</div><div style="flex:1;background:var(--srf);border:1px solid var(--bdr);border-radius:6px;padding:6px 8px;text-align:center"><div style="font-size:16px;font-weight:700;color:var(--gn)">${withQ}</div>With Quotes</div><div style="flex:1;background:var(--srf);border:1px solid var(--bdr);border-radius:6px;padding:6px 8px;text-align:center"><div style="font-size:16px;font-weight:700">${sr.length}</div>Showing</div></div>
<div style="display:flex;gap:8px;margin-bottom:10px"><div class="search-bar" style="flex:1;margin:0"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input placeholder="Search..." value="${S.cSearch}" oninput="S.cSearch=this.value;renderCust()"></div><button class="btn btn-pr btn-sm" onclick="showCustForm()">+ Add</button></div>
${sr.length?sr.map(c=>{const cq=DB.quotes().filter(q=>q.customerId===c.id||q.fields.custCo===c.company);const dr=cq.filter(q=>q.status==='draft').length;const ap2=cq.filter(q=>q.status==='approval').length;const se=cq.filter(q=>q.status==='sent').length;const wn=cq.filter(q=>q.status==='won').length;const lo=cq.filter(q=>q.status==='lost').length;const tw2=wn?cq.filter(q=>q.status==='won').reduce((a,q)=>a+(q.wonAmount||0),0):0;return`<div class="qcard" onclick="openProfile('${c.id}')"><div style="display:flex;justify-content:space-between;align-items:center"><div class="qcard-co">${c.company}</div><button class="btn btn-ghost btn-xs" onclick="event.stopPropagation();showCustForm('${c.id}')">✏️</button></div><div class="qcard-desc">${c.contact||''} ${c.phone?'· '+c.phone:''} ${c.industry?'· <em>'+c.industry+'</em>':''}</div><div style="font-size:10px;color:var(--tx2);margin:2px 0">${cq.length} quotes${wn?' · <span style=color:var(--gn)>'+wn+' won</span>':''}${tw2?' · <span style=color:var(--gn)>'+f$(tw2)+'</span>':''}${ap2?' · <span style=color:#c4b5fd>'+ap2+' pending</span>':''}</div>${cq.length?'<div style="display:flex;gap:3px;margin-top:4px;flex-wrap:wrap">'+(dr?'<span class="pill pill-draft" style="font-size:8px;padding:1px 5px">'+dr+' draft</span>':'')+(ap2?'<span class="pill pill-approval" style="font-size:8px;padding:1px 5px">'+ap2+' pending</span>':'')+(se?'<span class="pill pill-sent" style="font-size:8px;padding:1px 5px">'+se+' sent</span>':'')+(wn?'<span class="pill pill-won" style="font-size:8px;padding:1px 5px">'+wn+' won</span>':'')+(lo?'<span class="pill pill-lost" style="font-size:8px;padding:1px 5px">'+lo+' lost</span>':'')+'</div>':''}</div>`}).join(''):'<div class="empty-state"><div class="ico">👥</div><p>No customers</p><button class="btn btn-pr" onclick="showCustForm()">+ Add</button></div>'}`}

// TEMPLATES
function renderTpl(){
const dies=getSpecList('dies');const films=getSpecList('films');const labels=getSpecList('labels');const varnishes=getSpecList('varnishes');
const baseDies=SPEC_DIES.length;const baseFilms=SPEC_FILMS.length;const baseLabels=SPEC_LABELS.length;const baseVarn=SPEC_VARNISHES.length;
$('v-templates').innerHTML=`
<div style="padding:2px 0 8px"><input id="specGlobalSearch" type="text" placeholder="Search all specs..." oninput="specGlobalFilter()" style="width:100%;padding:8px 12px;border:1px solid var(--bdr);border-radius:8px;background:var(--inp);color:var(--tx);font-size:13px"></div>

<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">🔧</span><span class="ttl">Die List (${dies.length})</span><span class="arr">▾</span></div><div class="scard-b open">
<div id="specDiesList" style="max-height:400px;overflow-y:auto">
${dies.map((d,i)=>`<div class="spec-item spec-global-row" data-gsearch="${(d.id+' '+d.shape+' '+d.sA+' '+d.sAr+' '+d.notes).toLowerCase()}" onclick="inspectDie('${d.id}')" style="padding:8px 6px;border-bottom:1px solid var(--bdr);cursor:pointer;display:flex;justify-content:space-between;align-items:center">
<div><strong style="color:var(--ac)">${d.id}</strong> <span style="color:var(--tx2);font-size:11px">${d.shape} ${d.sA}×${d.sAr}</span>${d.notes?'<div style="font-size:10px;color:var(--tx3);margin-top:2px">'+d.notes+'</div>':''}</div>
${i>=baseDies?'<button class="btn btn-ghost btn-xs" onclick="event.stopPropagation();removeUserSpecItem(\'dies\','+i+');renderTpl()">✕</button>':''}
</div>`).join('')}
</div>
<button class="btn btn-pr btn-sm" onclick="addNewDie();renderTpl()" style="margin-top:8px;width:100%">+ Add New Die</button>
</div></div>

<div class="scard"><div class="scard-h" onclick="togCard(this)"><span class="ico">🎞️</span><span class="ttl">Flexible Film List (${films.length})</span><span class="arr">▾</span></div><div class="scard-b">
<div id="specFilmsList" style="max-height:400px;overflow-y:auto">
${films.map((d,i)=>`<div class="spec-item spec-global-row" data-gsearch="${(d.id+' '+d.desc).toLowerCase()}" style="padding:8px 6px;border-bottom:1px solid var(--bdr);display:flex;justify-content:space-between;align-items:center">
<div><strong style="color:var(--ac)">${d.id}</strong> <span style="font-size:11px;color:var(--tx2)">— ${d.desc}</span></div>
${i>=baseFilms?'<button class="btn btn-ghost btn-xs" onclick="removeUserSpecItem(\'films\','+i+');renderTpl()">✕</button>':''}
</div>`).join('')}
</div>
<button class="btn btn-pr btn-sm" onclick="addNewSpec('films');renderTpl()" style="margin-top:8px;width:100%">+ Add New Film</button>
</div></div>

<div class="scard"><div class="scard-h" onclick="togCard(this)"><span class="ico">🏷️</span><span class="ttl">Label Stock List (${labels.length})</span><span class="arr">▾</span></div><div class="scard-b">
<div id="specLabelsList" style="max-height:400px;overflow-y:auto">
${labels.map((d,i)=>`<div class="spec-item spec-global-row" data-gsearch="${(d.id+' '+d.desc).toLowerCase()}" style="padding:8px 6px;border-bottom:1px solid var(--bdr);display:flex;justify-content:space-between;align-items:center">
<div><strong style="color:var(--ac)">${d.id}</strong> <span style="font-size:11px;color:var(--tx2)">— ${d.desc}</span></div>
${i>=baseLabels?'<button class="btn btn-ghost btn-xs" onclick="removeUserSpecItem(\'labels\','+i+');renderTpl()">✕</button>':''}
</div>`).join('')}
</div>
<button class="btn btn-pr btn-sm" onclick="addNewSpec('labels');renderTpl()" style="margin-top:8px;width:100%">+ Add New Label Stock</button>
</div></div>

<div class="scard"><div class="scard-h" onclick="togCard(this)"><span class="ico">✨</span><span class="ttl">Varnish List (${varnishes.length})</span><span class="arr">▾</span></div><div class="scard-b">
<div id="specVarnishList" style="max-height:400px;overflow-y:auto">
${varnishes.map((v,i)=>`<div class="spec-item spec-global-row" data-gsearch="${v.toLowerCase()}" style="padding:8px 6px;border-bottom:1px solid var(--bdr);display:flex;justify-content:space-between;align-items:center">
<div><strong>${v}</strong></div>
${i>=baseVarn?'<button class="btn btn-ghost btn-xs" onclick="removeUserSpecItem(\'varnishes\','+i+');renderTpl()">✕</button>':''}
</div>`).join('')}
</div>
<button class="btn btn-pr btn-sm" onclick="addNewVarnish();renderTpl()" style="margin-top:8px;width:100%">+ Add New Varnish</button>
</div></div>
<div style="height:80px"></div>`}


function appendRFQToLibrary(){
var tpl=$('v-templates');if(!tpl)return;
var rDiv=document.createElement('div');
rDiv.className='scard';rDiv.style.marginTop='10px';
rDiv.innerHTML='<div class="scard-h" onclick="togCard(this)"><span class="ico">📋</span><span class="ttl">RFQ Requests</span><span class="arr">▾</span></div><div class="scard-b"><div id="libRfqList">Loading...</div></div>';
tpl.appendChild(rDiv);
if(fbDb){fbDb.collection('requests').orderBy('submittedAt','desc').limit(20).get().then(function(snap){
var reqs=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())});
var h='';reqs.forEach(function(r){
var sc={pending:'or',approved:'gn',in_progress:'#60a5fa',completed:'var(--gn)'};
h+='<div style="padding:6px;border-bottom:1px solid var(--bdr);cursor:pointer;font-size:11px" onclick="openRFQDetail(\''+r.id+'\')">';
h+='<div style="display:flex;justify-content:space-between"><strong style="color:var(--ac)">'+(r.company||'—')+'</strong><span class="pill pill-'+(r.status==='pending'?'proposal':r.status==='approved'?'qualified':'won')+'">'+(r.status||'pending')+'</span></div>';
h+='<div style="color:var(--tx3);margin-top:2px">'+(r.requestType||'Quote')+' · '+(r.submittedBy||'')+' · '+(r.submittedAt?new Date(r.submittedAt.seconds*1000).toLocaleDateString('en-US',{month:'short',day:'numeric'})+' '+new Date(r.submittedAt.seconds*1000).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}):'')+'</div></div>'});
if(!reqs.length)h='<div style="color:var(--tx3);padding:8px;text-align:center">No requests yet</div>';
var el=document.getElementById('libRfqList');if(el)el.innerHTML=h}).catch(function(e){var el=document.getElementById('libRfqList');if(el)el.innerHTML=e.message})}}

function specGlobalFilter(){const q=($('specGlobalSearch')||{}).value||'';const ql=q.toLowerCase();document.querySelectorAll('.spec-global-row').forEach(r=>{const s=r.getAttribute('data-gsearch')||'';r.style.display=ql===''||s.includes(ql)?'flex':'none'})}

function inspectDie(dieId){const dies=getSpecList('dies');const d=dies.find(x=>x.id===dieId);if(!d)return;
openModal('<div class="modal-title">'+d.id+' — '+d.shape+'</div>'+
'<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 16px;font-size:12px;margin-bottom:12px">'+
[['Shape',d.shape],['Size Across',d.sA||'—'],['Size Around',d.sAr||'—'],['Repeat',d.repeat||'—'],['# Across',d.nA||'—'],['# Around',d.nAr||'—'],['Gap Across',d.gapA||'—'],['Gap Around',d.gapAr||'—'],['Corner Radius',d.cRad||'—']].map(([l,v])=>'<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--tx2)">'+l+'</span><strong>'+v+'</strong></div>').join('')+
'</div>'+(d.notes?'<div style="font-size:11px;color:var(--tx3);font-style:italic;margin-bottom:12px">'+d.notes+'</div>':'')+
'<button class="btn btn-pr btn-sm" onclick="closeModal()">Close</button>')}

// EDITOR
function renderEditor(){const q=getQ(S.editId);if(!q)return goView('quotes');
$('hdrTitle').textContent=q.quoteNum+' Rev '+q.rev;
$('hdrActions').innerHTML=`<span class="pill pill-${q.status}">${q.status}</span>${q.collaborators&&q.collaborators.length?'<span style="font-size:9px;color:var(--ac)">👥 '+q.collaborators.length+'</span>':''}<button class="btn btn-pr btn-sm" onclick="edActions()">⋯</button>`;
const f=q.fields;
const mkOpts=(opts,cur)=>opts.map(o=>`<option ${cur===o?'selected':''}>${o}</option>`).join('');
const mkOptV=(opts,cur)=>opts.map(([v,l])=>`<option value="${v}" ${cur===v?'selected':''}>${l||v}</option>`).join('');

$('v-editor').innerHTML=`<div class="etabs">${['Info','Specs','Materials','Pricing','Matrix','Preview',(function(){var qq=getQ(S.editId);if(!qq)return'Send';if(qq.status==='draft')return'📤 Submit';if(qq.status==='approval')return'⏳ Pending';if(qq.status==='rejected')return'❌ Rejected';if(qq.status==='ready')return'✉ Send';if(qq.status==='sent')return'✅ Sent';return'Send'})(),'Notes','Activity'].map((t,i)=>`<div class="etab ${i===S.etab?'active':''}" onclick="switchET(${i})">${t}</div>`).join('')}</div>

<div class="epane ${S.etab===0?'active':''}" id="ep-info">
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">📋</span><span class="ttl">Quote</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="row2"><div class="fg"><label>Quote #</label><input data-field="quoteNum" value="${q.quoteNum}" readonly style="color:var(--ac);font-family:'JetBrains Mono',monospace"></div><div class="fg"><label>Date</label><input data-field="quoteDate" type="date" value="${f.quoteDate||''}" oninput="asave()"></div></div>
<div class="row2"><div class="fg"><label>Estimator <span class="req">*</span></label><input data-field="estimator" value="${f.estimator}" oninput="asave()"></div><div class="fg"><label>Job Type</label><select data-field="jobType" oninput="asave()">${mkOpts(['Flexographic','Digital','Offset'],f.jobType)}</select></div></div>
<div class="row2"><div class="fg"><label>Sales Rep</label><input data-field="salesRep" value="${f.salesRep}" oninput="asave()"></div><div class="fg"><label>Payment Terms <button class="btn btn-ghost btn-xs" onclick="addPaymentTerm()" style="float:right;font-size:9px">+ Add</button></label><select data-field="payTerms" oninput="asave()">${mkOpts(getPayTerms(),f.payTerms)}</select></div></div>
</div></div>
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">🏢</span><span class="ttl">Customer</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="fg"><label>Load Saved Customer</label><input id="custSearch" placeholder="Type to search 400+ clients..." oninput="filterCustDD(this.value)" onfocus="$('custDD').style.display='block'" autocomplete="off"><div id="custDD" style="display:none;max-height:180px;overflow-y:auto;background:var(--inp);border:1px solid var(--ac3);border-radius:0 0 8px 8px;margin-top:-4px"></div></div>
<div class="fg"><label>Company</label><input data-field="custCo" value="${f.custCo}" oninput="asave()"></div>
<div class="fg"><label>Attention</label><input data-field="custAttn" value="${f.custAttn}" oninput="asave()"></div>
<div class="fg"><label>Phone/Email</label><input data-field="custPhone" value="${f.custPhone}" oninput="asave()"></div>
<div class="fg"><label>Email</label><input data-field="custEmail" value="${f.custEmail||''}" oninput="asave()"></div>
<div style="display:flex;gap:6px"><button class="btn btn-ghost btn-sm" onclick="saveCustFromQ()" style="flex:1">💾 Save Customer</button><button class="btn btn-ghost btn-sm" onclick="viewCustFromQ()" style="flex:1">👤 View Profile</button></div>
</div></div></div>

<div class="epane ${S.etab===1?'active':''}" id="ep-specs">
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">🏷️</span><span class="ttl">Product</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="row2"><div class="fg"><label>Shape</label><select data-field="shapeType" oninput="asave()">${mkOpts(['Rectangle Label','Circle Label','Oval Label','Square Label','Special Shape','Flexible Film','Flexible Film Pouch','Stick Pack','Sheets'],f.shapeType)}</select></div></div>
</div></div>
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">📐</span><span class="ttl">Dimensions</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="fg"><label>Die # <button class="btn btn-ghost btn-xs" onclick="showSpecManager('dies')" style="float:right;font-size:9px">⚙ Manage</button></label><select id="ed-die" onchange="selectDie()"><option value="">— Select Die —</option></select></div>
<div id="dieSpecPanel" style="display:none;background:var(--srf);border:1px solid var(--bdr);border-radius:6px;padding:8px 10px;margin-bottom:10px">
<div style="font-weight:600;font-size:12px;margin-bottom:6px;color:var(--pr)">Selected Die Specs</div>
<div id="dieSpecGrid" style="display:grid;grid-template-columns:1fr 1fr;gap:4px 12px;font-size:11px"></div>
<div id="dieSpecNotes" style="margin-top:6px;font-size:10px;color:var(--tx3);font-style:italic"></div>
</div>
<div class="row2"><div class="fg"><label>Size Across</label><input data-field="sA" type="number" value="${f.sA}" step=".125" oninput="asave()"></div><div class="fg"><label>Size Around</label><input data-field="sar" type="number" value="${f.sar}" step=".125" oninput="asave()"></div></div>
<div class="row3"><div class="fg"><label># Across</label><input data-field="nAcross" type="number" value="${f.nAcross}" min="1" oninput="asave()"></div><div class="fg"><label># Around</label><input data-field="nAround" type="number" value="${f.nAround}" min="1" oninput="asave()"></div><div class="fg"><label>Colors</label><input data-field="colors" type="number" value="${f.colors}" oninput="asave()"></div></div>
<div class="row3"><div class="fg"><label>Gap Across</label><input data-field="gA" type="number" value="${f.gA}" step=".0625" oninput="asave()"></div><div class="fg"><label>Gap Around</label><input data-field="gar" type="number" value="${f.gar}" step=".0625" oninput="asave()"></div><div class="fg"><label>Off Cuts</label><input data-field="offCuts" type="number" value="${f.offCuts}" step=".0625" oninput="asave()"></div></div>
<div class="row3"><div class="fg"><label># Copies</label><input data-field="nCopies" type="number" value="${f.nCopies}" oninput="asave()"></div><div class="fg"><label># Plates</label><input data-field="nPlates" type="number" value="${f.nPlates}" oninput="asave()"></div><div class="fg"><label>Radius</label><input data-field="cRad" type="number" value="${f.cRad}" step=".0625" oninput="asave()"></div></div>
</div></div>
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">🔄</span><span class="ttl">Roll</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="row2"><div class="fg"><label>Labels/Roll</label><input data-field="labRoll" value="${f.labRoll}" oninput="asave()"></div><div class="fg"><label>Max OD</label><input data-field="maxOD" value="${f.maxOD}" oninput="asave()"></div></div>
<div class="row2"><div class="fg"><label>Wind Dir/Copy Pos</label><select data-field="windDir" oninput="asave()">${mkOpts(['TBD','1','2','3','4','5','6','7','8','3BOE','4BOE','5BOE','6BOE','7BOE','8BOE','1Color','2Color','Blank'],f.windDir)}</select></div><div class="fg"><label>Core Dia</label><input data-field="coreDia" value="${f.coreDia}" oninput="asave()"></div></div>
</div></div><div class="cbox" id="specBox"></div></div>

<div class="epane ${S.etab===2?'active':''}" id="ep-mats">
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">🧱</span><span class="ttl">Materials</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="fg"><label>Face Stock <button class="btn btn-ghost btn-xs" onclick="showSpecManager('labels')" style="float:right;font-size:9px">⚙ Manage</button><button class="btn btn-ghost btn-xs" onclick="openMatProfile(document.querySelector('[data-field=faceStock]').value)" style="float:right;font-size:9px;margin-right:4px">📊</button></label><div class="mat-wrap"><select data-field="faceStock" id="ed-fs" onchange="edMat('faceStock',true)"></select><span class="mat-msi" id="msi-faceStock"></span></div></div>
<div class="fg"><label>Lamination <button class="btn btn-ghost btn-xs" onclick="showSpecManager('films')" style="float:right;font-size:9px">⚙ Manage</button><button class="btn btn-ghost btn-xs" onclick="openMatProfile(document.querySelector('[data-field=lamination]').value)" style="float:right;font-size:9px;margin-right:4px">📊</button></label><div class="mat-wrap"><select data-field="lamination" id="ed-lam" onchange="edMat('lamination')"></select><span class="mat-msi" id="msi-lamination"></span></div></div>
<div class="row2"><div class="fg"><label>Liner</label><select data-field="liner" oninput="asave()">${mkOpts(['NA','40# Liner','40# CK Liner','50# Liner','Kraft Liner','CUSTOM'],f.liner)}</select></div><div class="fg"><label>Adhesive</label><select data-field="adhesive" oninput="asave()">${mkOpts(['NA','C2500','S100R Permanent','AT20 All-Temp','751 Permanent','531 Removable','CUSTOM'],f.adhesive)}</select></div></div>
<div class="row2"><div class="fg"><label>Coating / Varnish <button class="btn btn-ghost btn-xs" onclick="showSpecManager('varnishes')" style="float:right;font-size:9px">⚙ Manage</button></label><select data-field="coating" id="ed-coat" oninput="asave()"></select></div><div class="fg"><label>Other</label><select data-field="otherMat" oninput="asave()">${mkOpts(['NA','CUSTOM'],f.otherMat)}</select></div></div>
<div class="fg"><label>Notes <span style="font-weight:400;color:var(--tx3)">(custom per quote)</span></label><textarea data-field="notes" placeholder="Add any job-specific notes here..." oninput="asave()">${f.notes}</textarea></div>
</div></div></div>

<div class="epane ${S.etab===3?'active':''}" id="ep-pricing">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;padding:6px 8px;background:var(--bg3);border-radius:6px;border:1px solid var(--bdr)">
<span style="font-size:11px;color:var(--tx2)">Pricing fields ${q.pricingLocked?'🔒 LOCKED — values saved':'🔓 Unlocked — edit to adjust'}</span>
<button class="btn btn-ghost btn-xs" onclick="togglePriceLock()" style="font-size:10px">${q.pricingLocked?'🔓 Unlock':'🔒 Lock Prices'}</button>
</div>
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">💰</span><span class="ttl">Pricing</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="vsec">Material Cost <span style="font-size:8px;color:var(--tx3)">Formula: MatCost = MatWW × TotalFt × 0.012 × MSI × Margin</span></div>
<div class="var-row"><span class="var-lbl">MSI Cost <span style="font-size:8px;color:var(--tx3)">(auto from material, editable)</span></span><input class="var-inp hi" data-field="msiCost" type="number" value="${f.msiCost}" step="0.001" oninput="asave()"><span class="var-unit">$/MSI</span></div>
<div class="var-row"><span class="var-lbl">Stock Margin</span><input class="var-inp" data-field="stockMgn" type="number" value="${f.stockMgn}" step="0.1" oninput="asave()"><span class="var-unit">×</span></div>
<div class="var-row"><span class="var-lbl">Setup/Waste</span><input class="var-inp" data-field="matSetup" type="number" value="${f.matSetup}" step="100" oninput="asave()"><span class="var-unit">ft</span></div>
<div class="vsec">Markup <span style="font-size:8px;color:var(--tx3)">Applied after material + setup costs</span></div>
<div class="var-row"><span class="var-lbl">MFX Markup</span><input class="var-inp hi" data-field="mkupPct" type="number" value="${f.mkupPct}" step="0.5" oninput="asave()"><span class="var-unit">%</span></div>
<div class="vsec">Plate & Setup <span style="font-size:8px;color:var(--tx3)">Fixed per SKU: plates + color changes + MR + CU</span></div>
<div class="var-row"><span class="var-lbl">$/Plate</span><input class="var-inp hi" data-field="cppPlate" type="number" value="${f.cppPlate}" oninput="asave()"><span class="var-unit">$</span></div>
<div class="var-row"><span class="var-lbl">Plates/SKU</span><input class="var-inp" data-field="plPerSku" type="number" value="${f.plPerSku}" oninput="asave()"><span class="var-unit">#</span></div>
<div class="var-row"><span class="var-lbl">CC Cost</span><input class="var-inp" data-field="ccCost" type="number" value="${f.ccCost}" oninput="asave()"><span class="var-unit">$</span></div>
<div class="var-row"><span class="var-lbl"># CC</span><input class="var-inp" data-field="nCC" type="number" value="${f.nCC}" oninput="asave()"><span class="var-unit">#</span></div>
<div class="vsec">MR & Clean-Up <span style="font-size:8px;color:var(--tx3)">Labor: hours × rate per job</span></div>
<div class="var-row"><span class="var-lbl">MR Hours</span><input class="var-inp" data-field="mrHrs" type="number" value="${f.mrHrs}" step=".5" oninput="asave()"><span class="var-unit">hrs</span></div>
<div class="var-row"><span class="var-lbl">MR Rate</span><input class="var-inp hi" data-field="mrRate" type="number" value="${f.mrRate}" oninput="asave()"><span class="var-unit">$</span></div>
<div class="var-row"><span class="var-lbl">CU Hours</span><input class="var-inp" data-field="cuHrs" type="number" value="${f.cuHrs}" step=".5" oninput="asave()"><span class="var-unit">hrs</span></div>
<div class="var-row"><span class="var-lbl">CU Rate</span><input class="var-inp" data-field="cuRate" type="number" value="${f.cuRate}" oninput="asave()"><span class="var-unit">$</span></div>
<div class="vsec">Charges <span style="font-size:8px;color:var(--tx3)">One-time costs per job</span></div>
<div class="var-row"><span class="var-lbl">Die Charge</span><input class="var-inp" data-field="dieChg" type="number" value="${f.dieChg}" oninput="asave()"><span class="var-unit">$</span></div>
<div class="var-row"><span class="var-lbl">Plate Cost</span><input class="var-inp" data-field="plCost" type="number" value="${f.plCost}" oninput="asave()"><span class="var-unit">$</span></div>
<div class="vsec">Sales Commission</div>
<div class="var-row"><span class="var-lbl">Rep %</span><input class="var-inp hi" data-field="repPct" type="number" value="${f.repPct||0}" step="0.5" oninput="asave()"><span class="var-unit">%</span></div>
<div class="cbox" id="priceBox"></div></div></div>
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">📜</span><span class="ttl">Terms & Conditions</span><span class="arr">▾</span></div><div class="scard-b open">
<div id="termsEditor"></div>
<div style="display:flex;gap:6px;margin-top:8px"><button class="btn btn-ghost btn-sm" onclick="addCustomTerm()" style="flex:1">+ Add Custom Term</button><button class="btn btn-ghost btn-sm" onclick="resetTerms()">↺ Reset</button></div>
</div></div></div>

<div class="epane ${S.etab===4?'active':''}" id="ep-matrix">
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">📊</span><span class="ttl">Quantities</span><span class="arr">▾</span></div><div class="scard-b open">
<div class="qty-list" id="edQL"></div>
<div class="qty-actions"><button class="qty-btn qty-add" onclick="edAddQ()" style="flex:1">+ Add Quantity</button></div>
</div></div>
<div class="row2"><div class="fg"><label>SKU Cols</label><input data-field="skuCols" type="number" value="${f.skuCols}" min="1" max="10" oninput="asave()"></div><div class="fg"><label>Show</label><select data-field="showMode" oninput="asave()">${mkOptV([['both','Unit & Total'],['unit','Unit Only'],['total','Total Only']],f.showMode)}</select></div></div>
<div class="scard" style="margin-top:8px"><div class="scard-h" onclick="togCard(this)"><span class="ico">⟳</span><span class="ttl">Quick Seed</span><span class="arr">▾</span></div><div class="scard-b">
<div class="row3"><div class="fg"><label>Start</label><input data-field="qStart" type="number" value="${f.qStart}" step="1000"></div><div class="fg"><label>Step</label><input data-field="qStep" type="number" value="${f.qStep}" step="500"></div><div class="fg"><label>Rows</label><input data-field="qRows" type="number" value="${f.qRows}" min="1" max="20"></div></div>
<div class="qty-actions"><button class="qty-btn qty-seed" onclick="edSeedQ()" style="flex:1">⟳ Generate</button></div>
</div></div>
</div>

<div class="epane ${S.etab===5?'active':''}" id="ep-preview">
<div class="qp" id="quotePage"></div>
<div style="text-align:center;margin-top:12px;display:flex;gap:6px;justify-content:center" class="no-print">
<select id="printOrientation" style="padding:4px 8px;border:1px solid var(--bdr);border-radius:6px;background:var(--inp);color:var(--tx);font-size:11px"><option value="landscape">Landscape</option><option value="portrait">Portrait</option></select>
</div></div>

<div class="epane ${S.etab===6?'active':''}" id="ep-send">
<div id="sendPaneContent"></div>
</div>

<div class="epane ${S.etab===7?'active':''}" id="ep-notes">
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">💬</span><span class="ttl">Internal Notes</span><span class="arr">▾</span></div><div class="scard-b open">
<div style="font-size:11px;color:var(--tx3);margin-bottom:8px">Team notes — not shown on quotes</div>
<div id="internalNotes" style="max-height:300px;overflow-y:auto;margin-bottom:8px"></div>
<div style="position:relative">
<textarea id="noteInput" placeholder="Type @ to mention a team member..." oninput="checkAtMention(this)" style="width:100%;min-height:60px;padding:8px;border:1px solid var(--bdr);border-radius:6px;background:var(--inp);color:var(--tx);font-size:12px"></textarea>
<div id="mentionDropdown" style="display:none;position:absolute;bottom:100%;left:0;width:100%;max-height:150px;overflow-y:auto;background:var(--card);border:1px solid var(--ac);border-radius:6px;z-index:100"></div>
</div>
<button class="btn btn-pr btn-sm" onclick="addInternalNote()" style="margin-top:6px;width:100%">+ Add Note</button>
</div></div></div>

<div class="epane ${S.etab===8?'active':''}" id="ep-activity">
<div class="scard"><div class="scard-h open" onclick="togCard(this)"><span class="ico">📜</span><span class="ttl">Quote Activity Log</span><span class="arr">▾</span></div><div class="scard-b open">
<div style="font-size:11px;color:var(--tx3);margin-bottom:8px">All edits, collaborations, and actions on this quote</div>
<div id="activityLog" style="max-height:400px;overflow-y:auto"></div>
</div></div></div>`;

buildMS('ed-fs',f.faceStock);buildMS('ed-lam',f.lamination);buildDieSelect(f);buildVarnishSelect(f.coating);edMat('faceStock');edMat('lamination');edRQ();renderTermsEditor();edCalcAll();renderInternalNotes();renderActivityLog();if(S.etab===6)setTimeout(renderSendPane,100)}

function buildDieSelect(f){const sel=$('ed-die');if(!sel)return;const dies=getSpecList('dies');sel.innerHTML='<option value="">— Select Die —</option>';
dies.forEach(d=>{const o=document.createElement('option');o.value=d.id;o.textContent=d.id+' — '+d.shape+' '+d.sA+'×'+d.sAr;sel.appendChild(o)});
sel.value=''}

function selectDie(){const sel=$('ed-die');const panel=$('dieSpecPanel');const grid=$('dieSpecGrid');const notesEl=$('dieSpecNotes');
if(!sel||!sel.value){if(panel)panel.style.display='none';return}
const dies=getSpecList('dies');const d=dies.find(x=>x.id===sel.value);if(!d){if(panel)panel.style.display='none';return}
const fields={sA:'sA',sar:'sAr',nAcross:'nA',nAround:'nAr',gA:'gapA',gar:'gapAr',cRad:'cRad',shapeType:'shape'};
for(const[field,key]of Object.entries(fields)){const v=d[key];if(!v||v==='-')continue;
const inp=document.querySelector('[data-field="'+field+'"]');if(inp){if(field==='shapeType'){const found=[...inp.options].find(o=>o.value.toLowerCase().includes(v.toLowerCase()));if(found)inp.value=found.value}else{const n=parseFloat(v);if(!isNaN(n))inp.value=n}}}
if(panel&&grid){panel.style.display='block';
const specs=[['Die #',d.id],['Shape',d.shape],['Size Across',d.sA||'—'],['Size Around',d.sAr||'—'],['Repeat',d.repeat||'—'],['# Across',d.nA||'—'],['# Around',d.nAr||'—'],['Gap Across',d.gapA||'—'],['Gap Around',d.gapAr||'—'],['Corner Radius',d.cRad||'—']];
grid.innerHTML=specs.map(([l,v])=>`<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--tx2)">${l}</span><strong>${v}</strong></div>`).join('');
notesEl.textContent=d.notes?'Notes: '+d.notes:''}
if(d.notes){toast(d.id+': '+d.notes,'info')}
asave()}

function buildVarnishSelect(def){const sel=$('ed-coat');if(!sel)return;const list=getSpecList('varnishes');sel.innerHTML='<option value="NA">NA</option>';
list.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;if(v===def)o.selected=true;sel.appendChild(o)});
const oC=document.createElement('option');oC.value='CUSTOM';oC.textContent='— Custom —';sel.appendChild(oC);
if(def&&def!=='NA'&&!list.includes(def)){const oD=document.createElement('option');oD.value=def;oD.textContent=def;oD.selected=true;sel.appendChild(oD)}}

function renderTermsEditor(){const q=getQ(S.editId);if(!q)return;
if(!q.terms)q.terms=[...DEFAULT_TERMS];
const el=$('termsEditor');if(!el)return;
const allTerms=[...new Set([...DEFAULT_TERMS,...q.terms])];
el.innerHTML=allTerms.map((t,i)=>{const checked=q.terms.includes(t);const isCustom=!DEFAULT_TERMS.includes(t);
return`<div class="term-item"><input type="checkbox" class="term-cb" ${checked?'checked':''} onchange="toggleTerm('${btoa(unescape(encodeURIComponent(t)))}',this.checked)"><div class="term-txt">${t}</div>${isCustom?`<button class="term-del" onclick="removeTerm('${btoa(unescape(encodeURIComponent(t)))}')">✕</button>`:''}</div>`}).join('')}

function toggleTerm(b64,on){const t=decodeURIComponent(escape(atob(b64)));const all=DB.quotes();const q=all.find(x=>x.id===S.editId);if(!q)return;
if(!q.terms)q.terms=[...DEFAULT_TERMS];
if(on&&!q.terms.includes(t))q.terms.push(t);
if(!on)q.terms=q.terms.filter(x=>x!==t);
DB.saveQ(all);edCalcAll()}

function addCustomTerm(){const t=prompt('Enter custom term:');if(!t||!t.trim())return;
const all=DB.quotes();const q=all.find(x=>x.id===S.editId);if(!q)return;
if(!q.terms)q.terms=[...DEFAULT_TERMS];
q.terms.push(t.trim());DB.saveQ(all);renderTermsEditor();edCalcAll()}

function removeTerm(b64){const t=decodeURIComponent(escape(atob(b64)));
const all=DB.quotes();const q=all.find(x=>x.id===S.editId);if(!q)return;
q.terms=q.terms.filter(x=>x!==t);DB.saveQ(all);renderTermsEditor();edCalcAll()}

function resetTerms(){if(!confirm('Reset to default terms?'))return;
const all=DB.quotes();const q=all.find(x=>x.id===S.editId);if(!q)return;
q.terms=[...DEFAULT_TERMS];DB.saveQ(all);renderTermsEditor();edCalcAll()}

function switchET(n){S.etab=n;saveQ();renderEditor();if(n===6)setTimeout(renderSendPane,100);$('vc').scrollTop=0}
function submitForApproval(qid){const all=DB.quotes();const q=all.find(x=>x.id===qid);if(!q)return;q.status='approval';q.updatedAt=new Date().toISOString();logQuoteEvent(q,'status','Submitted for CEO approval');DB.saveQ(all);DB.logActivity('quote.approval',q.quoteNum+' submitted for CEO approval');toast('Submitted for approval!','ok');notifyTeam('🔒 '+q.quoteNum+' submitted for approval by '+getUserName());S.etab=6;renderEditor();setTimeout(renderSendPane,100)}
function ceoApprove(qid){const code=prompt('Enter CEO 4-digit approval code:');if(!code)return;if(code==='2057'){const all=DB.quotes();const q=all.find(x=>x.id===qid);if(!q)return;q.status='ready';q.approvedBy='CEO';q.approvedAt=new Date().toISOString();q.updatedAt=new Date().toISOString();if(!q.internalNotes)q.internalNotes=[];q.internalNotes.push({id:'n'+Date.now(),text:'✅ CEO APPROVED — Quote is READY to send',by:'CEO',at:new Date().toISOString(),mentions:[],replies:[]});DB.saveQ(all);DB.logActivity('quote.approved',q.quoteNum+' CEO approved → Ready');toast('Approved → Ready!','ok');logClientActivity(q.fields.custCo,'✅ '+q.quoteNum+' CEO approved');
// Auto-save to Drive + Registry
S.editId=qid;setTimeout(function(){autoSaveApproved(qid)},500);
if(S.view==='editor')renderEditor();else renderQuotes()}else{toast('Invalid code','err')}}

function autoSaveApproved(qid){
var q=getQ(qid);if(!q)return;
// Save to Drive
if(typeof saveQuoteToDrive==='function'&&typeof getGoogleToken==='function'){
toast('Saving to Drive...','ok');
saveQuoteToDrive();}
// Add to Registry
setTimeout(function(){
if(typeof addToRegistry==='function'){
toast('Adding to Registry...','ok');
addToRegistry();}
},2000);
notifyTeam('✅ Quote '+q.quoteNum+' approved by CEO — saved to Drive + Registry')}
function edActions(){const q=getQ(S.editId);openModal(`<div class="modal-title">Actions</div>${q.status==='ready'?`<div style="background:#052e16;border:1px solid #16a34a;border-radius:8px;padding:10px;margin-bottom:10px;font-size:11px;color:#4ade80;text-align:center">✅ CEO Approved — Ready to Send</div><button class="btn btn-pr" onclick="closeModal();emailQuoteWithPDF()">✉ Email Quote to Client</button><button class="btn btn-ghost" onclick="closeModal();openQuoteSendMenu()">📤 All Send Options</button>`:``}${q.status==='approval'?`<button class="btn btn-pr" onclick="closeModal();ceoApprove('${q.id}')">🔑 CEO Approve</button>`:``}${q.status==='draft'?`<button class="btn btn-ghost" onclick="closeModal();submitForApproval('${q.id}')">🔒 Submit for Approval</button>`:''}<button class="btn btn-ghost" onclick="closeModal();dupQuote('${q.id}',true)">📋 New Revision</button><button class="btn btn-ghost" onclick="closeModal();dupQuote('${q.id}',false)">📄 Duplicate</button><button class="btn btn-ghost" onclick="closeModal();inviteCollaborator()">👥 Invite Collaborator</button><button class="btn btn-ghost" onclick="closeModal();scheduleMeeting(S.editId)">📅 Schedule Meeting</button><button class="btn btn-or" onclick="closeModal();saveTpl()">📋 Save Template</button><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`)}
function loadCust(cid){if(!cid)return;const c=DB.customers().find(x=>x.id===cid);if(!c)return;const s=(f,v)=>{const e=document.querySelector('[data-field="'+f+'"]');if(e)e.value=v||''};s('custCo',c.company);s('custAttn',c.contact);s('custPhone',c.phone||c.email);const si=$('custSearch');if(si)si.value=c.company;const dd=$('custDD');if(dd)dd.style.display='none';asave()}
function filterCustDD(q){const dd=$('custDD');if(!dd)return;const cs=DB.customers();const f=q?cs.filter(c=>(c.company+' '+c.contact+' '+(c.industry||'')).toLowerCase().includes(q.toLowerCase())).slice(0,20):cs.slice(0,20);dd.innerHTML=f.map(c=>`<div style="padding:8px 12px;cursor:pointer;border-bottom:1px solid var(--bdr);font-size:12px" onmousedown="loadCust('${c.id}')"><strong>${c.company}</strong><br><span style="color:var(--tx3);font-size:10px">${c.contact||''} ${c.industry?'· '+c.industry:''}</span></div>`).join('')+(f.length>=20?'<div style="padding:6px 12px;color:var(--tx3);font-size:10px;text-align:center">Type more to narrow results...</div>':'');dd.style.display='block'}
document.addEventListener('click',e=>{const dd=$('custDD');const si=$('custSearch');if(dd&&si&&!dd.contains(e.target)&&e.target!==si)dd.style.display='none'})
function saveCustFromQ(){saveQ();const q=getQ(S.editId);if(!q||!q.fields.custCo){toast('Enter company first','err');return}saveCust({id:'c'+Date.now(),company:q.fields.custCo,contact:q.fields.custAttn,phone:q.fields.custPhone,email:'',industry:'',address:'',notes:[],zohoId:''})}
function viewCustFromQ(){saveQ();const q=getQ(S.editId);if(!q||!q.fields.custCo)return toast('No customer','err');const c=DB.customers().find(x=>x.company.toLowerCase()===q.fields.custCo.toLowerCase());if(c){S.profileId=c.id;openProfile(c.id)}else{toast('Customer not saved yet','err')}}
// MATERIALS
function buildMS(id,def){const sel=$(id);if(!sel)return;sel.innerHTML='';const oC=document.createElement('option');oC.value='CUSTOM';oC.textContent='— Custom —';sel.appendChild(oC);const oN=document.createElement('option');oN.value='NA';oN.textContent='NA';sel.appendChild(oN);
const vs=[...new Set(MATS.map(m=>m.v))];for(const v of vs){const og=document.createElement('optgroup');og.label=v;MATS.filter(m=>m.v===v).forEach(m=>{const o=document.createElement('option');o.value=m.s;o.textContent=m.s+' — '+m.d;if(m.m!=null)o.dataset.m=m.m;if(m.mk!=null)o.dataset.mk=m.mk;if(m.s===def)o.selected=true;og.appendChild(o)});sel.appendChild(og)}}
function edMat(field,fromChange){const selId=field==='faceStock'?'ed-fs':'ed-lam';const sel=$(selId);if(!sel)return;const opt=sel.options[sel.selectedIndex];const badge=$('msi-'+field);
const q=getQ(S.editId);
if(opt&&opt.dataset.m){const msi=parseFloat(opt.dataset.m);badge.textContent='MSI $'+msi.toFixed(3);badge.style.display='inline';if(field==='faceStock'&&fromChange&&!(q&&q.pricingLocked)){const mf=document.querySelector('[data-field="msiCost"]');if(mf)mf.value=msi.toFixed(4);if(opt.dataset.mk){const mk=document.querySelector('[data-field="mkupPct"]');if(mk)mk.value=(parseFloat(opt.dataset.mk)*100).toFixed(1)}}}else{badge.style.display='none'}asave()}


function emailQuote(){var q=getQ(S.editId);if(!q)return;
var tpls=[
{name:'Send Quote',subject:'Your Microflex Quote: {quoteNum} REV {rev} is ready!',body:'Dear {contact},\n\nPlease find your quote details below:\n\nQuote: {quoteNum} Rev {rev}\nJob: {jobDesc}\nType: {jobType}\nEstimator: {estimator}\n\nPlease review and let us know if you have any questions or would like to proceed.\n\nBest regards,\n{estimator}\nMicroflex Film Corporation\n909-360-9066 · Quotes@MicroflexFilm.com'},
{name:'Follow Up (7 Day)',subject:'Following up on your Microflex Quote: {quoteNum} REV {rev}',body:'Dear {contact},\n\nI wanted to follow up on Quote {quoteNum} sent for {company}.\n\nPlease let us know if you have any questions or need any revisions.\n\nBest regards,\n{estimator}\nMicroflex Film Corporation\n909-360-9066'},
{name:'Request Info',subject:'Additional info needed for Microflex Quote: {quoteNum} REV {rev}',body:'Dear {contact},\n\nThank you for your quote request. To proceed with {quoteNum}, we need some additional information:\n\n- [specify what you need]\n\nPlease send this at your earliest convenience.\n\nBest regards,\n{estimator}\nMicroflex Film Corporation'}
];
var vars={'{quoteNum}':q.quoteNum,'{rev}':q.rev,'{contact}':q.fields.custAttn||'Customer','{company}':q.fields.custCo||'','{jobDesc}':q.fields.jobDesc||'','{jobType}':q.fields.jobType||'','{estimator}':q.fields.estimator||getUserName(),'{email}':q.fields.custEmail||'','{date}':new Date().toLocaleDateString()};
function fillTpl(s){Object.keys(vars).forEach(function(k){s=s.split(k).join(vars[k])});return s}
var h='<div class="modal-title">Email Quote</div>';
h+='<div class="fg"><label>To</label><input id="em-to" value="'+(q.fields.custEmail||'')+'"></div>';
h+='<div class="fg"><label>Template</label><select id="em-tpl" onchange="fillEmailTpl()">';
tpls.forEach(function(t,i){h+='<option value="'+i+'">'+t.name+'</option>'});
h+='</select></div>';
h+='<div class="fg"><label>Subject</label><input id="em-subj" value="'+fillTpl(tpls[0].subject)+'"></div>';
h+='<div class="fg"><label>Message</label><textarea id="em-body" style="min-height:120px">'+fillTpl(tpls[0].body)+'</textarea></div>';
h+='<button class="btn btn-pr" onclick="sendQuoteEmail()" style="width:100%;margin-top:8px">Send via Gmail</button>';
h+='<button class="btn btn-ghost" onclick="closeModal()" style="width:100%;margin-top:6px">Cancel</button>';
window._emailTpls=tpls;window._emailVars=vars;window._emailFill=fillTpl;
openModal(h);return}
function fillEmailTpl(){var i=parseInt(($('em-tpl')||{}).value||0);var t=window._emailTpls[i];if(!t)return;$('em-subj').value=window._emailFill(t.subject);$('em-body').value=window._emailFill(t.body)}
// _oldSendQuoteEmail removed — dead code
function sendQuoteEmail(){
var to=($('em-to')||{}).value;var subj=($('em-subj')||{}).value;var body=($('em-body')||{}).value;
if(!to)return toast('Email required','err');
var q=getQ(S.editId);
toast('Generating PDF for attachment...','ok');
generateQuotePDF(q).then(function(pdf){
// Build MIME multipart message with PDF attachment
var boundary='mfx_boundary_'+Date.now();
var htmlBody='<div style="font-family:Arial,sans-serif;max-width:700px;margin:0 auto"><div style="background:#0a0714;color:#b44dff;padding:16px 20px;text-align:center;font-size:18px;font-weight:700">Microflex Film Corporation</div><div style="padding:20px;background:#f8fafc;white-space:pre-wrap;font-size:13px;line-height:1.6;color:#333">'+body.replace(/\n/g,'<br>')+'</div><div style="background:#0a0714;color:#888;padding:10px 20px;text-align:center;font-size:10px">4130 Garner Road, Riverside, CA 92501 · 909-360-9066 · MicroflexFilm.com</div></div>';
var raw='Content-Type: multipart/mixed; boundary="'+boundary+'"\r\n';
raw+='To: '+to+'\r\nSubject: '+subj+'\r\nMIME-Version: 1.0\r\n\r\n';
raw+='--'+boundary+'\r\n';
raw+='Content-Type: text/html; charset=utf-8\r\n\r\n';
raw+=htmlBody+'\r\n\r\n';
raw+='--'+boundary+'\r\n';
raw+='Content-Type: application/pdf; name="'+pdf.filename+'"\r\n';
raw+='Content-Disposition: attachment; filename="'+pdf.filename+'"\r\n';
raw+='Content-Transfer-Encoding: base64\r\n\r\n';
raw+=pdf.base64+'\r\n';
raw+='--'+boundary+'--';
var encoded=btoa(unescape(encodeURIComponent(raw))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
getGoogleToken().then(function(token){if(!token)return toast('Gmail not connected','err');
fetch('https://www.googleapis.com/gmail/v1/users/me/messages/send',{
method:'POST',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},
body:JSON.stringify({raw:encoded})
}).then(function(r){return r.json()}).then(function(data){
if(data.id){toast('Email sent with PDF!','ok');closeModal();updateRegistry(S.editId,'Emailed');
if(q){if(!q.internalNotes)q.internalNotes=[];q.internalNotes.push({id:'n'+Date.now(),text:'📧 Emailed to '+to+' with PDF attached — '+subj,by:getUserName(),at:new Date().toISOString(),mentions:[],replies:[]});var all=DB.quotes();DB.saveQ(all)}}
else{toast('Email error','err')}
}).catch(function(e){toast('Error: '+e.message,'err')})}
)}).catch(function(e){toast('PDF error: '+e,'err')})}

function sendAndSaveToDrive(){
sendQuoteEmail();
setTimeout(function(){saveQuoteToDrive()},1000)}

function saveAndEmail(){
saveQuoteToDrive();
setTimeout(function(){emailQuoteWithPDF()},1500)}

function addToRegistry(){
upsertRegistryRow(S.editId,'Manual add/update')}

function upsertRegistryRow(qid,action){
var q=getQ(qid);if(!q)return;var f=q.fields;
getGoogleToken().then(function(token){if(!token)return toast('Sign out and back in','err');
findOrCreateRegistry(token).then(function(sheetId){
if(!sheetId)return toast('Could not access registry','err');
// ALWAYS search for existing row by quote number first
fetch('https://sheets.googleapis.com/v4/spreadsheets/'+sheetId+'/values/Sheet1!A:A',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(data){
var rowIdx=-1;
if(data.values){data.values.forEach(function(r,i){if(r[0]===q.quoteNum)rowIdx=i})}
var pricing=getQuotePricingForRegistry(q);
var row=[
q.quoteNum,q.rev,q.status,f.quoteDate||'',f.estimator||'',f.salesRep||'',f.jobType||'',
f.custCo||'',f.custAttn||'',f.custPhone||'',f.custEmail||'',f.jobDesc||'',
f.copyPos||'',f.shapeType||'',f.sA||'',f.sar||'',f.nAcross||'',f.nAround||'',f.colors||'',
f.gA||'',f.gar||'',f.cRad||'',f.nCopies||'',f.nPlates||'',f.offCuts||'',
f.labRoll||'',f.maxOD||'',f.windDir||'',f.coreDia||'',
f.faceStock||'',f.lamination||'',f.liner||'',f.adhesive||'',f.coating||'',f.otherMat||'',
f.msiCost||'',f.stockMgn||'',f.matSetup||'',f.mkupPct||'',f.cppPlate||'',f.plPerSku||'',
f.ccCost||'',f.nCC||'',f.mrHrs||'',f.mrRate||'',f.cuHrs||'',f.cuRate||'',
f.dieChg||'',f.plCost||'',f.repPct||'',f.payTerms||'',f.notes||'',
(q.qtys||[]).join(', '),q.wonAmount||'',q.lostReason||'',
q.createdBy||'',q.createdAt||'',q.updatedAt||'',q.sentAt||'',
q.approvedBy||'',q.approvedAt||'',new Date().toISOString(),action||'',
q.poNumber||'',q.wonSKUs||'',q.wonQty||'',q.expectedDelivery||'',
pricing.qtyBreakdown,pricing.totalPerQty,pricing.ppuPerQty,pricing.setupTotal,pricing.materialWW];

if(rowIdx>0){
// UPDATE existing row — same quote number
var range='Sheet1!A'+(rowIdx+1);
fetch('https://sheets.googleapis.com/v4/spreadsheets/'+sheetId+'/values/'+range+'?valueInputOption=USER_ENTERED',{
method:'PUT',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},
body:JSON.stringify({values:[row]})
}).then(function(r){return r.json()}).then(function(res){
console.log('Registry row UPDATED at row '+(rowIdx+1));
toast('Registry updated (row '+(rowIdx+1)+')','ok');
logRegistryActivity(q,'Updated',action)
}).catch(function(e){console.log('Registry update err:',e)})}
else{
// APPEND new row — first time for this quote number
fetch('https://sheets.googleapis.com/v4/spreadsheets/'+sheetId+'/values/Sheet1:append?valueInputOption=USER_ENTERED',{
method:'POST',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},
body:JSON.stringify({values:[row]})
}).then(function(r){return r.json()}).then(function(res){
console.log('Registry row APPENDED');
toast('Added to registry','ok');
logRegistryActivity(q,'Created',action)
}).catch(function(e){console.log('Registry append err:',e)})}
}).catch(function(e){console.log('Registry search err:',e)})})}).catch(function(){toast('Token error','err')})}

function logRegistryActivity(q,type,action){
if(!q)return;if(!q.internalNotes)q.internalNotes=[];
q.internalNotes.push({id:'n'+Date.now(),text:'📊 Registry '+type+': '+(action||'updated')+' — '+q.quoteNum+' Rev '+q.rev,by:getUserName(),at:new Date().toISOString(),mentions:[],replies:[]});
logQuoteEvent(q,'registry',type+': '+action);
var all=DB.quotes();DB.saveQ(all)}

function findOrCreateRegistry(token){
console.log('Finding registry in MFX-CORE/Quotes...');
return findQuotesFolder(token).then(function(quotesFolder){
// Search for MFX Quote Registry inside Quotes folder
var q='name=\'MFX Quote Registry\' and mimeType=\'application/vnd.google-apps.spreadsheet\' and trashed=false';
if(quotesFolder)q+=' and \''+quotesFolder+'\' in parents';
return fetch('https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent(q)+'&supportsAllDrives=true&includeItemsFromAllDrives=true&corpora=allDrives&fields=files(id)',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(data){
if(data.files&&data.files.length>0){console.log('Found registry:',data.files[0].id);return data.files[0].id}
// Create new sheet with headers inside Quotes folder
var sheetMeta={properties:{title:'MFX Quote Registry'},sheets:[{data:[{rowData:[{values:['Quote #','Rev','Status','Quote Date','Estimator','Sales Rep','Job Type','Company','Contact','Phone','Email','Job Description','Copy Position','Shape','Size Across','Size Around','# Across','# Around','Colors','Gap Across','Gap Around','Corner Radius','# Copies','# Plates','Off Cuts','Labels/Roll','Max OD','Wind Dir','Core Dia','Face Stock','Lamination','Liner','Adhesive','Coating','Other Material','MSI Cost','Stock Margin','Material Setup','Markup %','CPP Plate','Plates/SKU','CC Cost','# Color Changes','Makeready Hrs','Makeready Rate','CU Hrs','CU Rate','Die Charge','Plate Cost','Reprint %','Pay Terms','Notes','Quantities','Won Amount','Lost Reason','Created By','Created At','Updated At','Sent At','Approved By','Approved At','Registry Date','Last Action','PO Number','# SKUs','Qty Chosen','Expected Delivery','Qty Breakdown','Total per Qty (1 SKU)','Price per Unit','Setup Total','Material WW'].map(function(h){return{userEnteredValue:{stringValue:h}}})}]}]}]};
return fetch('https://sheets.googleapis.com/v4/spreadsheets',{
method:'POST',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},
body:JSON.stringify(sheetMeta)
}).then(function(r){return r.json()}).then(function(s){
if(s.spreadsheetId&&quotesFolder){
// Move sheet into Quotes folder
fetch('https://www.googleapis.com/drive/v3/files/'+s.spreadsheetId+'?addParents='+quotesFolder+'&supportsAllDrives=true',{
method:'PATCH',headers:{'Authorization':'Bearer '+token}}).catch(function(){})}
console.log('Created registry:',s.spreadsheetId);return s.spreadsheetId||null})
})}).catch(function(e){console.log('Registry err:',e);return null})}

function getQuoteFileName(q){var n=new Date();var mm=(n.getMonth()+1<10?'0':'')+(n.getMonth()+1);var dd=(n.getDate()<10?'0':'')+n.getDate();var co=(q.fields.custCo||'Quote').replace(/[^a-zA-Z0-9 ]/g,'').replace(/\s+/g,' ').trim().replace(/\s/g,'-');return q.quoteNum+'-'+co+'-'+mm+'-'+dd}

function generateQuotePDF(q){
return new Promise(function(resolve,reject){
var pg=document.getElementById('quotePage');if(!pg){reject('No quote page');return}
var container=document.createElement('div');
container.style.cssText='position:fixed;top:-9999px;left:-9999px;width:800px;background:#fff;padding:20px;color:#000;font-family:Arial,sans-serif';
container.innerHTML=pg.innerHTML.replace(/color:var\(--[^)]+\)/g,'color:#333').replace(/background:var\(--[^)]+\)/g,'background:#fff').replace(/class="qsig"[^<]*<[^>]*>.*?<\/div><\/div>/g,'');
document.body.appendChild(container);
html2canvas(container,{scale:2,useCORS:true,backgroundColor:'#ffffff'}).then(function(canvas){
document.body.removeChild(container);
var imgData=canvas.toDataURL('image/jpeg',0.95);
var pdf=new jspdf.jsPDF('p','mm','letter');
var pdfW=pdf.internal.pageSize.getWidth();
var imgW=pdfW-20;var imgH=(canvas.height*imgW)/canvas.width;
pdf.addImage(imgData,'JPEG',10,10,imgW,imgH);
var pdfBlob=pdf.output('blob');var pdfBase64=pdf.output('datauristring').split(',')[1];
resolve({blob:pdfBlob,base64:pdfBase64,filename:getQuoteFileName(q)+'.pdf'})
}).catch(function(e){document.body.removeChild(container);reject(e)})})}

function findOrCreateSharedFolder(token,folderName){
// Search for MFX-CORE shared drive first
return fetch('https://www.googleapis.com/drive/v3/drives?pageSize=50',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(drives){
var mfxDrive=null;
if(drives.drives){drives.drives.forEach(function(d){if(d.name==='MFX-CORE')mfxDrive=d.id})}
console.log('MFX-CORE drive:',mfxDrive);
// Search for Quotes folder
var q='name=\'Quotes\' and mimeType=\'application/vnd.google-apps.folder\' and trashed=false';
if(mfxDrive)q+=' and \''+mfxDrive+'\' in parents';
return fetch('https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent(q)+'&supportsAllDrives=true&includeItemsFromAllDrives=true&corpora=allDrives&fields=files(id,name)',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(qData){
var quotesFolder=(qData.files&&qData.files.length)?qData.files[0].id:null;
console.log('Quotes folder:',quotesFolder);
if(!quotesFolder)return null;
// Search for MFX Master Quotes inside Quotes folder
return fetch('https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent('name=\''+folderName+'\' and mimeType=\'application/vnd.google-apps.folder\' and \''+quotesFolder+'\' in parents and trashed=false')+'&supportsAllDrives=true&includeItemsFromAllDrives=true&corpora=allDrives&fields=files(id,name)',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(mData){
if(mData.files&&mData.files.length)return mData.files[0].id;
// Create MFX Master Quotes inside Quotes
return fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true',{
method:'POST',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json'},
body:JSON.stringify({name:folderName,mimeType:'application/vnd.google-apps.folder',parents:[quotesFolder]})
}).then(function(r){return r.json()}).then(function(f){console.log('Created MFX Master Quotes:',f.id);return f.id||null})
})})}).catch(function(e){console.log('Folder search err:',e);return null})}

function findQuotesFolder(token){
return fetch('https://www.googleapis.com/drive/v3/drives?pageSize=50',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(drives){
var mfxDrive=null;
if(drives.drives){drives.drives.forEach(function(d){if(d.name==='MFX-CORE')mfxDrive=d.id})}
var q='name=\'Quotes\' and mimeType=\'application/vnd.google-apps.folder\' and trashed=false';
if(mfxDrive)q+=' and \''+mfxDrive+'\' in parents';
return fetch('https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent(q)+'&supportsAllDrives=true&includeItemsFromAllDrives=true&corpora=allDrives&fields=files(id,name)',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(data){
return(data.files&&data.files.length)?data.files[0].id:null})
}).catch(function(){return null})}

function saveQuoteToDrive(){
var q=getQ(S.editId);if(!q)return;
toast('Generating PDF...','ok');
generateQuotePDF(q).then(function(pdf){
getGoogleToken().then(function(token){if(!token)return toast('Sign out and back in','err');
findOrCreateSharedFolder(token,'MFX Master Quotes').then(function(folderId){
// Search for existing file with same quote number to replace
var searchQ='name contains \''+q.quoteNum+'\' and trashed=false';
if(folderId)searchQ+=' and \''+folderId+'\' in parents';
fetch('https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent(searchQ)+'&supportsAllDrives=true&includeItemsFromAllDrives=true&corpora=allDrives&fields=files(id,name)',{
headers:{'Authorization':'Bearer '+token}
}).then(function(r){return r.json()}).then(function(searchData){
var existingId=(searchData.files&&searchData.files.length>0)?searchData.files[0].id:null;

if(existingId){
// UPDATE existing file
var form=new FormData();
form.append('metadata',new Blob([JSON.stringify({name:pdf.filename,mimeType:'application/pdf'})],{type:'application/json'}));
form.append('file',pdf.blob,'application/pdf');
fetch('https://www.googleapis.com/upload/drive/v3/files/'+existingId+'?uploadType=multipart&supportsAllDrives=true',{
method:'PATCH',headers:{'Authorization':'Bearer '+token},body:form
}).then(function(r){return r.json()}).then(function(data){
if(data.id){toast('PDF updated in MFX Master Quotes!','ok');
upsertRegistryRow(S.editId,'PDF updated on Drive');
logDriveActivity(q,pdf.filename,'Updated');logClientActivity(q.fields.custCo,'☁ PDF saved: '+pdf.filename)}
else{toast('Drive update error','err')}}).catch(function(e){toast(e.message,'err')})}

else{
// CREATE new file
var metadata={name:pdf.filename,mimeType:'application/pdf'};
if(folderId)metadata.parents=[folderId];
var form=new FormData();
form.append('metadata',new Blob([JSON.stringify(metadata)],{type:'application/json'}));
form.append('file',pdf.blob,'application/pdf');
fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true',{
method:'POST',headers:{'Authorization':'Bearer '+token},body:form
}).then(function(r){return r.json()}).then(function(data){
if(data.id){toast('PDF saved to MFX Master Quotes!','ok');
upsertRegistryRow(S.editId,'PDF saved to Drive');
logDriveActivity(q,pdf.filename,'Created');logClientActivity(q.fields.custCo,'☁ PDF saved: '+pdf.filename)}
else{toast('Drive error','err')}}).catch(function(e){toast(e.message,'err')})}
}).catch(function(e){toast(e.message,'err')})})})
}).catch(function(e){toast('PDF error: '+e,'err')})}

function logDriveActivity(q,filename,type){
if(!q)return;if(!q.internalNotes)q.internalNotes=[];
q.internalNotes.push({id:'n'+Date.now(),text:'☁ Drive '+type+': '+filename,by:getUserName(),at:new Date().toISOString(),mentions:[],replies:[]});
logQuoteEvent(q,'drive',type+': '+filename);
var all=DB.quotes();DB.saveQ(all)}

function updateRegistry(qid,action){
upsertRegistryRow(qid,action)}

// ═══════ RESTORED FUNCTIONS ═══════

function openRFQRequest(){
var cs=DB.customers();
var h='<div class="modal-title">New Request</div>';
h+='<div style="font-size:10px;color:var(--tx3);margin-bottom:10px">Submit a quote request to the Estimation team</div>';
h+='<div class="fg"><label>Client *</label><select id="rfq-co" onchange="rfqFillClient()"><option value="">— Select Client —</option>';
cs.forEach(function(c){h+='<option value="'+c.company+'">'+c.company+'</option>'});
h+='</select></div>';
h+='<div class="fg"><label>Or New Client</label><input id="rfq-newco" placeholder="New client name"></div>';
h+='<div class="fg"><label>Contact</label><input id="rfq-ct"></div>';
h+='<div class="fg"><label>Email</label><input id="rfq-em"></div>';
h+='<div class="fg"><label>Phone</label><input id="rfq-ph"></div>';
h+='<div id="rfq-client-info" style="font-size:10px;color:var(--tx3);margin-bottom:6px"><span id="rfq-industry"></span> <span id="rfq-addr"></span></div>';
h+='<div class="fg"><label>Request Type</label><select id="rfq-type"><option>Quote</option><option>Sample</option><option>Proof</option><option>R&D</option><option>Reorder</option></select></div>';
h+='<div class="fg"><label>Job Type</label><select id="rfq-job"><option>Flexographic</option><option>Digital</option><option>Stock</option></select></div>';
h+='<div class="fg"><label>Description *</label><textarea id="rfq-desc"></textarea></div>';
h+='<div class="fg"><label>Quantity</label><input id="rfq-qty" placeholder="e.g. 10000"></div>';
h+='<div class="fg"><label>Target Date</label><input id="rfq-date" type="date"></div>';
h+='<div class="fg"><label>Owner</label><input id="rfq-owner" value="'+getUserName()+'"></div>';
h+='<div class="fg"><label>Collaborators</label><div id="rfq-collabs-list"></div><select id="rfq-collab-add" onchange="addRFQCollab()"><option value="">+ Add collaborator</option>';
var users2=typeof getTeamUsers==='function'?getTeamUsers():['Randy','Marco R.','Alex M.','Chris W.'];
users2.forEach(function(u){h+='<option value="'+u+'">'+u+'</option>'});
h+='</select></div>';
window._rfqCollabs=[];
h+='<div class="fg"><label>Notes</label><textarea id="rfq-notes"></textarea></div>';
h+='<button class="btn btn-pr" onclick="submitRFQRequest()" style="width:100%;margin-top:8px">Submit Request</button>';
h+='<button class="btn btn-ghost" onclick="closeModal()" style="width:100%;margin-top:6px">Cancel</button>';
openModal(h)}

function rfqFillClient(){var sel=$('rfq-co');if(!sel)return;var co=sel.value;if(!co)return;var cs=DB.customers();var c=cs.find(function(x){return x.company===co});if(c){if($('rfq-ct'))$('rfq-ct').value=c.contact||'';if($('rfq-em'))$('rfq-em').value=c.email||'';if($('rfq-ph'))$('rfq-ph').value=c.phone||'';if($('rfq-industry'))$('rfq-industry').textContent=c.industry||'';if($('rfq-addr'))$('rfq-addr').textContent=c.address||''}}

function submitRFQRequest(){var co=($('rfq-co')||{}).value||($('rfq-newco')||{}).value||'';if(!co)return toast('Client required','err');var desc=($('rfq-desc')||{}).value||'';if(!desc)return toast('Description required','err');var owner=($('rfq-owner')||{}).value||getUserName();var collabs=window._rfqCollabs||[];var rfq={company:co,contact:($('rfq-ct')||{}).value||'',email:($('rfq-em')||{}).value||'',phone:($('rfq-ph')||{}).value||'',requestType:($('rfq-type')||{}).value||'Quote',jobType:($('rfq-job')||{}).value||'Flexographic',description:desc,quantity:($('rfq-qty')||{}).value||'',targetDate:($('rfq-date')||{}).value||'',notes:($('rfq-notes')||{}).value||'',owner:owner,collaborators:collabs,submittedBy:getUserName(),status:'pending'};if(fbDb){fbDb.collection('requests').add(Object.assign(rfq,{submittedAt:firebase.firestore.FieldValue.serverTimestamp()})).then(function(){closeModal();toast('Request submitted!','ok');notifyTeam('📋 New request from '+getUserName()+': '+co);if(collabs.length)notifyTeam('👥 '+collabs.join(', ')+' added as collaborators on: '+co);if(rfq.targetDate&&typeof createCalendarEvent==='function')createCalendarEvent('📋 Request: '+co+' ('+rfq.requestType+')',desc,rfq.targetDate,'09:00',60)}).catch(function(e){toast(e.message,'err')})}}

function openRFQInbox(){
S.view='supportinbox';document.querySelectorAll('.view').forEach(function(el){el.classList.remove('active')});$('v-supportinbox').classList.add('active');$('mainTabs').style.display='none';$('hdrBack').style.display='block';$('hdrBack').onclick=function(){goView('dashboard')};$('hdrTitle').textContent='Request Hub';$('hdrActions').innerHTML='';renderRequestHub()}

function renderRequestHub(){
var el=$('v-supportinbox');if(!el)return;
var h='<div style="text-align:center;margin-bottom:12px"><div style="font-size:22px;font-weight:800;color:var(--ac)">Request Hub</div><div style="font-size:10px;color:var(--tx3)">Tap a department to see available requests</div></div>';

var cats=[
{id:'client',icon:'🤝',name:'Client Relations',color:'#7c3aed',desc:'Quoting, sampling & new business',forms:[
{icon:'📋',name:'RFQ',desc:'Request for Quote',use:'Client needs pricing on a label or packaging job'},
{icon:'🧪',name:'Sampling',desc:'Sample Request',use:'Client wants printed samples before committing to an order'},
{icon:'🔍',name:'Discovery',desc:'Pre-Quote Discovery',use:'Product doesn\'t exist yet — exploratory conversation with client'}]},

{id:'prepress',icon:'🎨',name:'Pre-Press',color:'#ec4899',desc:'Design, dielines, artwork & proofing',forms:[
{icon:'📐',name:'Dieline',desc:'Structural Design',use:'Need a new dieline, die layout, or structural design for a label'},
{icon:'⚙️',name:'Engineering',desc:'Technical / Product',use:'Material testing, adhesive compatibility, print feasibility study'},
{icon:'🖌',name:'Artwork',desc:'Creative Request',use:'Need artwork designed, revised, color separated, or preflighted'},
{icon:'🖨',name:'Proof',desc:'Proofing Request',use:'Need a digital, hard copy, or press proof sent to client'}]},

{id:'logistics',icon:'📦',name:'Logistics',color:'#f59e0b',desc:'Inventory & purchasing',forms:[
{icon:'📊',name:'Inventory',desc:'Stock Check',use:'Check material availability, stock levels, or reorder status'},
{icon:'🛒',name:'Purchasing',desc:'Purchase Request',use:'Need to order materials, supplies, or equipment from a vendor'}]},

{id:'production',icon:'🏭',name:'Production',color:'#10b981',desc:'Status, quality & compliance',forms:[
{icon:'📋',name:'Status Report',desc:'Job Status',use:'Need an update on where a job is in the production process'},
{icon:'✅',name:'Quality',desc:'Quality Report',use:'Print defect, material issue, or quality inspection needed'},
{icon:'⚠️',name:'CAPA',desc:'Corrective Action',use:'Root cause analysis and corrective or preventive action needed'},
{icon:'🔒',name:'SQF',desc:'Food Safety / Compliance',use:'SQF audit finding, HACCP issue, or GMP compliance concern'}]},

{id:'finance',icon:'💰',name:'Finance',color:'#6366f1',desc:'A/R, POs & invoices',forms:[
{icon:'📑',name:'AR Report',desc:'Accounts Receivable',use:'Need aging report, payment status, or credit check on a client'},
{icon:'📄',name:'PO Check',desc:'Purchase Order',use:'Verify PO status, delivery date, or vendor confirmation'},
{icon:'🧾',name:'Invoice',desc:'Invoice Issue',use:'Amount discrepancy, missing invoice, or payment question'}]},

{id:'hr',icon:'👥',name:'HR / Attendance',color:'#ef4444',desc:'Time off, sick days & corrections',forms:[
{icon:'🤒',name:'Sick Day',desc:'Call In Sick',use:'Reporting a sick day — notifies your supervisor immediately'},
{icon:'🏖',name:'Time Off',desc:'PTO / Vacation',use:'Requesting paid time off, personal day, bereavement, or jury duty'},
{icon:'⏰',name:'Late Notice',desc:'Late / Absent',use:'Running late, leaving early, or absent — notify your team'},
{icon:'🔧',name:'Clock Correction',desc:'Time Edit',use:'Missed punch, wrong time, or system error on your time clock'}]},

{id:'general',icon:'📝',name:'General',color:'#8b5cf6',desc:'Questions, training & access',forms:[
{icon:'❓',name:'Leadership Q',desc:'Ask Leadership',use:'Private or public question for CEO, Director, or a Lead'},
{icon:'📚',name:'Training',desc:'Request Training',use:'Need training on a machine, process, software, or procedure'},
{icon:'📅',name:'Meeting Request',desc:'Schedule Meeting',use:'Book time with someone — sets up calendar event automatically'},
{icon:'🔑',name:'Access Request',desc:'System Access',use:'Need login, permissions, or content access to a tool or drive'},
{icon:'💡',name:'Suggestion',desc:'Ideas & Feedback',use:'Share a question, concern, suggestion, or compliment (can be anonymous)'}]}
];

cats.forEach(function(cat){
h+='<div style="margin-bottom:6px">';
h+='<div style="background:linear-gradient(135deg,'+cat.color+'15,'+cat.color+'08);border:1px solid '+cat.color+'40;border-radius:12px;padding:14px 16px;cursor:pointer;transition:all .2s" onclick="toggleReqCat(\'rq-'+cat.id+'\')">';
h+='<div style="display:flex;align-items:center;gap:12px"><div style="width:44px;height:44px;border-radius:12px;background:'+cat.color+'25;display:flex;align-items:center;justify-content:center;font-size:22px">'+cat.icon+'</div>';
h+='<div style="flex:1"><div style="font-size:13px;font-weight:700;color:var(--tx)">'+cat.name+'</div><div style="font-size:10px;color:var(--tx3);margin-top:1px">'+cat.desc+'</div></div>';
h+='<div style="font-size:12px;color:var(--tx3);background:'+cat.color+'20;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center" id="rq-'+cat.id+'-arr">'+cat.forms.length+'</div></div></div>';

// Sub-forms
h+='<div id="rq-'+cat.id+'" style="display:none;padding:4px 0 0 56px">';
cat.forms.forEach(function(f){
h+='<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;margin:4px 0;background:var(--bg3);border-radius:10px;border-left:3px solid '+cat.color+';cursor:pointer;transition:all .15s" onclick="openTypedRequest(\''+f.name+'\')" onmousedown="this.style.transform=\'scale(0.98)\'" onmouseup="this.style.transform=\'scale(1)\'">';
h+='<div style="width:32px;height:32px;border-radius:8px;background:'+cat.color+'20;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">'+f.icon+'</div>';
h+='<div style="flex:1;min-width:0"><div style="font-size:12px;font-weight:700;color:var(--tx)">'+f.name+'</div>';
h+='<div style="font-size:10px;color:var(--ac);margin-top:1px">'+f.desc+'</div>';
h+='<div style="font-size:9px;color:var(--tx3);margin-top:3px;line-height:1.3">'+f.use+'</div></div>';
h+='<div style="color:'+cat.color+';font-size:14px;flex-shrink:0;margin-top:4px">›</div></div>'});
h+='</div></div>'});

h+='<div style="margin-top:14px"><button class="btn btn-ghost" onclick="openSubmittedRequests()" style="width:100%;padding:12px;border:1px dashed var(--bdr);border-radius:10px"><span style="font-size:14px">📬</span> View My Submitted Requests</button></div>';
el.innerHTML=h}

function reqBtn(icon,title,desc,type){
return'<div style="display:flex;align-items:center;gap:10px;padding:10px 8px;border-bottom:1px solid var(--bdr);cursor:pointer" onclick="openTypedRequest(\''+type+'\')">'
+'<span style="font-size:18px">'+icon+'</span>'
+'<div style="flex:1"><div style="font-size:12px;font-weight:600;color:var(--tx)">'+title+'</div>'
+'<div style="font-size:9px;color:var(--tx3)">'+desc+'</div></div>'
+'<span style="color:var(--tx3)">›</span></div>'}

function toggleReqCat(id){
var el=$(id);if(!el)return;
if(el.style.display==='none'){el.style.display='block';el.style.animation='fadeIn .2s'}
else{el.style.display='none'}}

function openTypedRequest(reqType){
var cs=DB.customers();
var users=typeof getTeamUsers==='function'?getTeamUsers():['Randy','Marco R.','Alex M.','Chris W.'];
var h='<div class="modal-title">'+reqType+' Request</div>';

// ═══ CLIENT RELATIONS ═══
if(reqType==='Quote'){
h+=clientFields(cs);
h+=fg('Job Type','<select id="rfq-job"><option>Flexographic</option><option>Digital</option><option>Stock</option><option>Lamination</option></select>');
h+=fg('Label Shape','<select id="rfq-shape"><option>Rectangle</option><option>Oval</option><option>Circle</option><option>Die-Cut</option><option>Custom</option></select>');
h+=fg('Estimated Size','<input id="rfq-size" placeholder="e.g. 4x6 inches">');
h+=fg('Number of Colors','<input id="rfq-colors" type="number" placeholder="e.g. 4">');
h+=fg('Substrate / Material','<input id="rfq-material" placeholder="e.g. White BOPP, Clear PE">');
h+=fg('Quantity Needed','<input id="rfq-qty" placeholder="e.g. 10000, 25000, 50000">');
h+=fg('Artwork Ready?','<select id="rfq-artready"><option>Yes</option><option>No — needs design</option><option>Partial</option></select>');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:50px" placeholder="Job details, special finishes, coatings..."></textarea>');
h+=dateAssignFields(users)}

else if(reqType==='Sample'){
h+=clientFields(cs);
h+=fg('Sample Type','<select id="rfq-stype"><option>Printed Sample</option><option>Blank Material</option><option>Finished Product</option><option>Color Match</option></select>');
h+=fg('Reference Quote #','<input id="rfq-refq" placeholder="If reprint or revision">');
h+=fg('Quantity of Samples','<input id="rfq-qty" placeholder="e.g. 50, 100">');
h+=fg('Ship To','<textarea id="rfq-shipto" placeholder="Address to ship samples"></textarea>');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:50px" placeholder="What samples are needed and why..."></textarea>');
h+=dateAssignFields(users)}

else if(reqType==='Discovery'){
h+=clientFields(cs);
h+=fg('Product Category','<select id="rfq-pcat"><option>Labels</option><option>Shrink Sleeves</option><option>Flexible Packaging</option><option>Pouches</option><option>Other</option></select>');
h+=fg('Target Market','<input id="rfq-market" placeholder="e.g. Food & Bev, Cannabis, Health">');
h+=fg('Estimated Volume','<input id="rfq-qty" placeholder="Annual or per-run estimate">');
h+=fg('Budget Range','<input id="rfq-budget" placeholder="e.g. $5K-$10K per run">');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:60px" placeholder="What product is this for? What doesn\'t exist yet? What are they trying to achieve?"></textarea>');
h+=dateAssignFields(users)}

// ═══ PRE-PRESS ═══
else if(reqType==='Dieline'){
h+=fg('Client / Job','<input id="rfq-co" placeholder="Client or internal project">');
h+=fg('Label Dimensions','<input id="rfq-size" placeholder="Width x Height (e.g. 4 x 6)">');
h+=fg('Shape','<select id="rfq-shape"><option>Rectangle</option><option>Oval</option><option>Circle</option><option>Custom Die-Cut</option><option>Wrap-Around</option></select>');
h+=fg('Corner Radius','<input id="rfq-corners" placeholder="e.g. 0.125 inches">');
h+=fg('Application Surface','<input id="rfq-surface" placeholder="e.g. Bottle, Jar, Box, Pouch">');
h+=fg('Reference Files','<input id="rfq-files" placeholder="Link to Drive folder or files">');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:50px" placeholder="Structural requirements, bleed, perforation, tabs..."></textarea>');
h+=dateAssignFields(users)}

else if(reqType==='Engineering'){
h+=fg('Client / Job','<input id="rfq-co" placeholder="Client or internal">');
h+=fg('Engineering Type','<select id="rfq-engtype"><option>Material Testing</option><option>Adhesive Compatibility</option><option>Print Feasibility</option><option>Die Design</option><option>Substrate R&D</option></select>');
h+=fg('Current Material','<input id="rfq-material" placeholder="What\'s being used now">');
h+=fg('Problem / Goal','<textarea id="rfq-desc" style="min-height:60px" placeholder="What technical challenge needs solving?"></textarea>');
h+=fg('Reference Files','<input id="rfq-files" placeholder="Link to specs, test results">');
h+=dateAssignFields(users)}

else if(reqType==='Artwork'){
h+=fg('Client / Job','<input id="rfq-co" placeholder="Client name">');
h+=fg('Artwork Type','<select id="rfq-arttype"><option>New Design</option><option>Revision / Edit</option><option>File Conversion</option><option>Color Separation</option><option>Trap & Pre-Flight</option></select>');
h+=fg('Dieline Available?','<select id="rfq-dieline"><option>Yes</option><option>No — needs creation</option></select>');
h+=fg('Brand Colors (PMS)','<input id="rfq-pms" placeholder="e.g. PMS 286, PMS 485">');
h+=fg('Reference Files','<input id="rfq-files" placeholder="Link to artwork, logos, brand guide">');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:50px" placeholder="What needs to be designed or changed?"></textarea>');
h+=dateAssignFields(users)}

else if(reqType==='Proof'){
h+=fg('Client','<input id="rfq-co" placeholder="Client name">');
h+=fg('Quote / Job #','<input id="rfq-refq" placeholder="Reference quote number">');
h+=fg('Proof Type','<select id="rfq-prooftype"><option>Digital Proof (PDF)</option><option>Printed Hard Proof</option><option>Press Proof</option><option>Color Match Proof</option></select>');
h+=fg('Ship Proof To','<textarea id="rfq-shipto" placeholder="Address if physical proof"></textarea>');
h+=fg('Description *','<textarea id="rfq-desc" placeholder="Special instructions, revisions from last proof..."></textarea>');
h+=dateAssignFields(users)}

// ═══ LOGISTICS ═══
else if(reqType==='Inventory'){
h+=fg('Material / Item','<input id="rfq-material" placeholder="What needs checking?">');
h+=fg('Part # / SKU','<input id="rfq-sku" placeholder="If known">');
h+=fg('Quantity Needed','<input id="rfq-qty" placeholder="How much do you need?">');
h+=fg('Needed By','<input id="rfq-date" type="date">');
h+=fg('Description *','<textarea id="rfq-desc" placeholder="Why is this needed? What job is it for?"></textarea>');
h+=assignField(users)}

else if(reqType==='Purchasing'){
h+=fg('Item / Material','<input id="rfq-material" placeholder="What to purchase">');
h+=fg('Vendor','<input id="rfq-vendor" placeholder="Preferred vendor if known">');
h+=fg('Quantity','<input id="rfq-qty">');
h+=fg('Estimated Cost','<input id="rfq-cost" placeholder="$">');
h+=fg('Needed By','<input id="rfq-date" type="date">');
h+=fg('Reason / Job #','<textarea id="rfq-desc" placeholder="What is this for?"></textarea>');
h+=assignField(users)}

// ═══ PRODUCTION ═══
else if(reqType==='Status Report'){
h+=fg('Job / Quote #','<input id="rfq-refq" placeholder="Which job?">');
h+=fg('Client','<input id="rfq-co">');
h+=fg('What info needed?','<textarea id="rfq-desc" placeholder="e.g. ETA, current stage, issues..."></textarea>');
h+=assignField(users)}

else if(reqType==='Quality'){
h+=fg('Job / Quote #','<input id="rfq-refq">');
h+=fg('Issue Type','<select id="rfq-qtype"><option>Print Defect</option><option>Material Issue</option><option>Color Mismatch</option><option>Die Cut Problem</option><option>Registration</option><option>Other</option></select>');
h+=fg('Severity','<select id="rfq-sev"><option>Minor</option><option>Major</option><option>Critical — Stop Production</option></select>');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:60px" placeholder="Describe the quality issue in detail"></textarea>');
h+=fg('Photos / Evidence','<input id="rfq-files" placeholder="Link to photos">');
h+=dateAssignFields(users)}

else if(reqType==='CAPA'){
h+=fg('Related Job #','<input id="rfq-refq">');
h+=fg('CAPA Type','<select id="rfq-capatype"><option>Corrective Action</option><option>Preventive Action</option></select>');
h+=fg('Root Cause','<textarea id="rfq-rootcause" placeholder="What caused the issue?"></textarea>');
h+=fg('Proposed Action','<textarea id="rfq-desc" style="min-height:60px" placeholder="What corrective/preventive steps are proposed?"></textarea>');
h+=dateAssignFields(users)}

else if(reqType==='SQF'){
h+=fg('SQF Category','<select id="rfq-sqfcat"><option>Food Safety</option><option>HACCP</option><option>GMP</option><option>Pest Control</option><option>Allergen</option><option>Audit Finding</option><option>Other</option></select>');
h+=fg('Urgency','<select id="rfq-sev"><option>Routine</option><option>Urgent</option><option>Critical — Immediate Action</option></select>');
h+=fg('Description *','<textarea id="rfq-desc" style="min-height:60px" placeholder="Describe the compliance issue or requirement"></textarea>');
h+=fg('Evidence / Docs','<input id="rfq-files" placeholder="Link to documents">');
h+=dateAssignFields(users)}

// ═══ FINANCE ═══
else if(reqType==='AR Report'){
h+=fg('Client','<input id="rfq-co" placeholder="Which client?">');
h+=fg('Report Type','<select id="rfq-artype"><option>Aging Report</option><option>Payment Status</option><option>Credit Check</option><option>Collection Follow-Up</option></select>');
h+=fg('Invoice #','<input id="rfq-refq" placeholder="If specific invoice">');
h+=fg('Description','<textarea id="rfq-desc" placeholder="What do you need to know?"></textarea>');
h+=assignField(users)}

else if(reqType==='PO Check'){
h+=fg('PO Number','<input id="rfq-refq" placeholder="Purchase order #">');
h+=fg('Vendor','<input id="rfq-vendor">');
h+=fg('Question','<textarea id="rfq-desc" placeholder="What about this PO?"></textarea>');
h+=assignField(users)}

else if(reqType==='Invoice'){
h+=fg('Invoice #','<input id="rfq-refq">');
h+=fg('Client / Vendor','<input id="rfq-co">');
h+=fg('Issue Type','<select id="rfq-invtype"><option>Amount Discrepancy</option><option>Missing Invoice</option><option>Duplicate Charge</option><option>Payment Status</option></select>');
h+=fg('Description','<textarea id="rfq-desc" placeholder="Describe the issue"></textarea>');
h+=assignField(users)}

// ═══ HR ═══
else if(reqType==='Sick Day'){
h+=fg('Date','<input id="rfq-date" type="date" value="'+new Date().toISOString().split('T')[0]+'">');
h+=fg('Expected Return','<input id="rfq-date2" type="date">');
h+=fg('Notes','<textarea id="rfq-desc" placeholder="Optional — any context for your supervisor"></textarea>')}

else if(reqType==='Time Off'){
h+=fg('Start Date','<input id="rfq-date" type="date">');
h+=fg('End Date','<input id="rfq-date2" type="date">');
h+=fg('Type','<select id="rfq-ptoType"><option>PTO / Vacation</option><option>Personal Day</option><option>Bereavement</option><option>Jury Duty</option><option>Other</option></select>');
h+=fg('Notes','<textarea id="rfq-desc" placeholder="Reason or context"></textarea>')}

else if(reqType==='Late Notice'){
h+=fg('Date','<input id="rfq-date" type="date" value="'+new Date().toISOString().split('T')[0]+'">');
h+=fg('Expected Arrival','<input id="rfq-time" type="time">');
h+=fg('Type','<select id="rfq-lateType"><option>Running Late</option><option>Absent Today</option><option>Leaving Early</option></select>');
h+=fg('Reason','<textarea id="rfq-desc" placeholder="Brief explanation"></textarea>')}

else if(reqType==='Clock Correction'){
h+=fg('Date of Error','<input id="rfq-date" type="date">');
h+=fg('Incorrect Time','<input id="rfq-time" type="time">');
h+=fg('Correct Time','<input id="rfq-time2" type="time">');
h+=fg('Type','<select id="rfq-clockType"><option>Missed Clock-In</option><option>Missed Clock-Out</option><option>Wrong Time</option><option>System Error</option></select>');
h+=fg('Explanation *','<textarea id="rfq-desc" placeholder="What happened?"></textarea>')}

// ═══ GENERAL ═══
else if(reqType==='Leadership Q'){
var toOpts='<select id="rfq-assign"><option>CEO</option><option>Director</option><option>Lead</option>';users.forEach(function(u){toOpts+='<option>'+u+'</option>'});toOpts+='</select>';h+=fg('To',toOpts);
h+=fg('Subject','<input id="rfq-subject" placeholder="Brief subject line">');
h+=fg('Question *','<textarea id="rfq-desc" style="min-height:80px" placeholder="Your question..."></textarea>');
h+=fg('Confidential?','<select id="rfq-conf"><option>No</option><option>Yes</option></select>')}

else if(reqType==='Training'){
h+=fg('Training Topic','<input id="rfq-subject" placeholder="What do you need training on?">');
h+=fg('Department','<select id="rfq-dept"><option>Operations</option><option>Pre-Press</option><option>Production</option><option>Quality</option><option>Sales</option><option>All</option></select>');
h+=fg('Preferred Format','<select id="rfq-format"><option>In-Person</option><option>Video Call</option><option>Written Guide</option><option>Shadow / Ride-Along</option></select>');
h+=fg('Details *','<textarea id="rfq-desc" placeholder="What specifically do you need to learn?"></textarea>');
h+=dateAssignFields(users)}

else if(reqType==='Meeting Request'){
var withOpts='<select id="rfq-assign"><option value="">Select person</option>';users.forEach(function(u){withOpts+='<option>'+u+'</option>'});withOpts+='</select>';h+=fg('With',withOpts);
h+=fg('Date','<input id="rfq-date" type="date">');
h+=fg('Time','<input id="rfq-time" type="time" value="10:00">');
h+=fg('Duration','<select id="rfq-dur"><option>15 min</option><option>30 min</option><option selected>60 min</option><option>90 min</option></select>');
h+=fg('Topic *','<textarea id="rfq-desc" placeholder="What is this meeting about?"></textarea>')}

else if(reqType==='Access Request'){
h+=fg('System / Tool','<input id="rfq-subject" placeholder="e.g. Google Drive, Zoho, MFX OS">');
h+=fg('Access Level','<select id="rfq-access"><option>View Only</option><option>Edit</option><option>Admin</option></select>');
h+=fg('Reason *','<textarea id="rfq-desc" placeholder="Why do you need access?"></textarea>');
h+=assignField(users)}

else{
// Suggestion / Generic
h+=fg('Subject','<input id="rfq-subject" placeholder="Brief subject">');
h+=fg('Category','<select id="rfq-sugcat"><option>Question</option><option>Concern</option><option>Suggestion</option><option>Compliment</option><option>Other</option></select>');
h+=fg('Details *','<textarea id="rfq-desc" style="min-height:80px" placeholder="Share your thoughts..."></textarea>');
h+=fg('Anonymous?','<select id="rfq-anon"><option>No</option><option>Yes</option></select>')}

h+='<button class="btn btn-pr" onclick="submitTypedRequest(\''+reqType+'\')" style="width:100%;margin-top:10px">Submit '+reqType+'</button>';
h+='<button class="btn btn-ghost" onclick="closeModal()" style="width:100%;margin-top:6px">Cancel</button>';
openModal(h)}

function fg(label,input){return'<div class="fg"><label>'+label+'</label>'+input+'</div>'}
function clientFields(cs){var h=fg('Client','<select id="rfq-co" onchange="rfqFillClient()"><option value="">— Select —</option>'+cs.map(function(c){return'<option value="'+c.company+'">'+c.company+'</option>'}).join('')+'</select>');h+=fg('Or New Client','<input id="rfq-newco">');h+=fg('Contact','<input id="rfq-ct">');h+=fg('Email','<input id="rfq-em">');h+=fg('Phone','<input id="rfq-ph">');h+='<div id="rfq-client-info" style="font-size:10px;color:var(--tx3);margin-bottom:4px"><span id="rfq-industry"></span></div>';return h}
function assignField(users){return fg('Assign To','<select id="rfq-assign"><option value="">Auto-route</option>'+users.map(function(u){return'<option>'+u+'</option>'}).join('')+'</select>')+fg('Priority','<select id="rfq-pri"><option>Normal</option><option>High</option><option>Urgent</option></select>')}
function dateAssignFields(users){return fg('Target Date','<input id="rfq-date" type="date">')+assignField(users)+fg('Notes','<textarea id="rfq-notes" placeholder="Additional notes..."></textarea>')}

function submitTypedRequest(reqType){
var desc=($('rfq-desc')||{}).value;if(!desc)return toast('Required field missing','err');
var co=($('rfq-co')||{}).value||($('rfq-newco')||{}).value||'';
var rfq={
requestType:reqType,
company:co,contact:($('rfq-ct')||{}).value||'',email:($('rfq-em')||{}).value||'',phone:($('rfq-ph')||{}).value||'',
description:desc,
subject:($('rfq-subject')||{}).value||'',
jobType:($('rfq-job')||{}).value||'',
shape:($('rfq-shape')||{}).value||'',size:($('rfq-size')||{}).value||'',
colors:($('rfq-colors')||{}).value||'',material:($('rfq-material')||{}).value||'',
quantity:($('rfq-qty')||{}).value||'',
artworkReady:($('rfq-artready')||{}).value||'',
sampleType:($('rfq-stype')||{}).value||'',
referenceQuote:($('rfq-refq')||{}).value||'',
shipTo:($('rfq-shipto')||{}).value||'',
productCategory:($('rfq-pcat')||{}).value||'',
targetMarket:($('rfq-market')||{}).value||'',
budget:($('rfq-budget')||{}).value||'',
corners:($('rfq-corners')||{}).value||'',
surface:($('rfq-surface')||{}).value||'',
engineeringType:($('rfq-engtype')||{}).value||'',
artworkType:($('rfq-arttype')||{}).value||'',
dielineReady:($('rfq-dieline')||{}).value||'',
pmsColors:($('rfq-pms')||{}).value||'',
proofType:($('rfq-prooftype')||{}).value||'',
vendor:($('rfq-vendor')||{}).value||'',
estimatedCost:($('rfq-cost')||{}).value||'',
sku:($('rfq-sku')||{}).value||'',
issueType:($('rfq-qtype')||{}).value||($('rfq-invtype')||{}).value||'',
severity:($('rfq-sev')||{}).value||'',
capaType:($('rfq-capatype')||{}).value||'',
rootCause:($('rfq-rootcause')||{}).value||'',
sqfCategory:($('rfq-sqfcat')||{}).value||'',
arType:($('rfq-artype')||{}).value||'',
files:($('rfq-files')||{}).value||'',
department:($('rfq-dept')||{}).value||'',
format:($('rfq-format')||{}).value||'',
accessLevel:($('rfq-access')||{}).value||'',
confidential:($('rfq-conf')||{}).value||'',
anonymous:($('rfq-anon')||{}).value||'',
category:($('rfq-sugcat')||{}).value||'',
ptoType:($('rfq-ptoType')||{}).value||'',
lateType:($('rfq-lateType')||{}).value||'',
clockType:($('rfq-clockType')||{}).value||'',
duration:($('rfq-dur')||{}).value||'',
meetingTime:($('rfq-time')||{}).value||'',
correctTime:($('rfq-time2')||{}).value||'',
targetDate:($('rfq-date')||{}).value||'',
endDate:($('rfq-date2')||{}).value||'',
assignedTo:($('rfq-assign')||{}).value||'',
priority:($('rfq-pri')||{}).value||'Normal',
notes:($('rfq-notes')||{}).value||'',
submittedBy:getUserName(),owner:getUserName(),status:'pending'};
// Clean empty fields
Object.keys(rfq).forEach(function(k){if(rfq[k]==='')delete rfq[k]});
rfq.submittedAt=firebase.firestore.FieldValue.serverTimestamp();
rfq.status='pending';rfq.submittedBy=getUserName();rfq.owner=getUserName();
rfq.requestType=reqType;

fbDb.collection('requests').add(rfq).then(function(){
closeModal();toast(reqType+' submitted!','ok');
notifyTeam('📨 New '+reqType+' from '+getUserName()+(co?' — '+co:''));
if(rfq.targetDate&&typeof createCalendarEvent==='function'){
createCalendarEvent('📨 '+reqType+': '+(co||desc.substring(0,30)),desc,rfq.targetDate,'09:00',60)}
}).catch(function(e){toast(e.message,'err')})}

function openSubmittedRequests(){
$('hdrTitle').textContent='Request Dashboard';$('hdrActions').innerHTML='<button class="btn btn-pr btn-xs" onclick="renderRequestHub()">+ New</button>';
var el=$('v-supportinbox');if(!el)return;
el.innerHTML='<div id="reqDash">Loading...</div>';
var me=getUserName();
fbDb.collection('requests').orderBy('submittedAt','desc').limit(60).get().then(function(snap){
var all=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())});
var filter=window._reqDashFilter||'all';
var h='';

// Overdue alert banner
var now=new Date();var overdue=all.filter(function(r){return r.targetDate&&new Date(r.targetDate)<now&&r.status!=='closed'&&r.status!=='completed'});
if(overdue.length>=5){h+='<div style="background:#7f1d1d;border:2px solid #ef4444;border-radius:8px;padding:10px;margin-bottom:10px;text-align:center;animation:pulse 1s infinite"><div style="font-size:13px;font-weight:700;color:#fca5a5">⚠ '+overdue.length+' OVERDUE REQUESTS</div><div style="font-size:10px;color:#fca5a5">Complete these before write-up</div></div>';
h+='<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.7}}</style>'}
else if(overdue.length>0){h+='<div style="background:#451a03;border:1px solid #f59e0b;border-radius:8px;padding:8px;margin-bottom:10px;font-size:11px;color:#fbbf24;text-align:center">⚠ '+overdue.length+' overdue request'+(overdue.length>1?'s':'')+'</div>'}

// Stats
var pending=all.filter(function(r){return r.status==='pending'}).length;
var active=all.filter(function(r){return r.status==='accepted'||r.status==='in_progress'}).length;
var done=all.filter(function(r){return r.status==='completed'||r.status==='closed'}).length;
h+='<div style="display:flex;gap:4px;margin-bottom:8px">';
h+='<div style="flex:1;background:var(--bg3);border-radius:6px;padding:6px;text-align:center"><div style="font-size:14px;font-weight:700;color:var(--or)">'+pending+'</div><div style="font-size:8px;color:var(--tx3)">Pending</div></div>';
h+='<div style="flex:1;background:var(--bg3);border-radius:6px;padding:6px;text-align:center"><div style="font-size:14px;font-weight:700;color:var(--ac)">'+active+'</div><div style="font-size:8px;color:var(--tx3)">Active</div></div>';
h+='<div style="flex:1;background:var(--bg3);border-radius:6px;padding:6px;text-align:center"><div style="font-size:14px;font-weight:700;color:var(--rd)">'+overdue.length+'</div><div style="font-size:8px;color:var(--tx3)">Overdue</div></div>';
h+='<div style="flex:1;background:var(--bg3);border-radius:6px;padding:6px;text-align:center"><div style="font-size:14px;font-weight:700;color:var(--gn)">'+done+'</div><div style="font-size:8px;color:var(--tx3)">Done</div></div></div>';

// Filters
h+='<div style="display:flex;gap:4px;margin-bottom:8px;flex-wrap:wrap">';
['all','mine','assigned','pending','active','overdue','completed','closed'].forEach(function(f){
var cnt=f==='all'?all.length:f==='mine'?all.filter(function(r){return r.submittedBy===me}).length:f==='assigned'?all.filter(function(r){return r.assignedTo===me}).length:f==='pending'?pending:f==='active'?active:f==='overdue'?overdue.length:f==='completed'?all.filter(function(r){return r.status==='completed'}).length:all.filter(function(r){return r.status==='closed'}).length;
h+='<span style="padding:3px 8px;background:'+(filter===f?'var(--ac)':'var(--bg3)')+';color:'+(filter===f?'#fff':'var(--tx2)')+';border-radius:12px;font-size:9px;cursor:pointer" onclick="window._reqDashFilter=\''+f+'\';openSubmittedRequests()">'+f+' ('+cnt+')</span>'});
h+='</div>';

// Filter items
var filtered=all;
if(filter==='mine')filtered=all.filter(function(r){return r.submittedBy===me||r.owner===me});
if(filter==='assigned')filtered=all.filter(function(r){return r.assignedTo===me});
if(filter==='pending')filtered=all.filter(function(r){return r.status==='pending'});
if(filter==='active')filtered=all.filter(function(r){return r.status==='accepted'||r.status==='in_progress'});
if(filter==='overdue')filtered=overdue;
if(filter==='completed')filtered=all.filter(function(r){return r.status==='completed'});
if(filter==='closed')filtered=all.filter(function(r){return r.status==='closed'});

// Table
filtered.forEach(function(r){
var daysUntil='—';var riskColor='var(--gn)';var riskText='OK';
if(r.targetDate){var due=new Date(r.targetDate);var diff=Math.ceil((due-now)/86400000);daysUntil=diff+'d';
if(diff<0){riskColor='var(--rd)';riskText='OVERDUE';daysUntil=Math.abs(diff)+'d over'}
else if(diff<=1){riskColor='var(--rd)';riskText='DUE TODAY'}
else if(diff<=3){riskColor='var(--or)';riskText='AT RISK'}
else{riskColor='var(--gn)';riskText='OK'}}
var lastNote='—';if(r.comments&&r.comments.length){var ln=r.comments[r.comments.length-1];lastNote=(ln.by||'')+': '+(ln.text||'').substring(0,30)}
var priColor=r.priority==='Urgent'?'var(--rd)':r.priority==='High'?'var(--or)':'var(--tx3)';
var stColor={pending:'var(--or)',accepted:'var(--ac)',in_progress:'var(--ac)',completed:'var(--gn)',closed:'var(--tx3)'}[r.status]||'var(--bdr)';

// Progress bar width
var pct=r.status==='closed'?100:r.status==='completed'?90:r.status==='in_progress'?50:r.status==='accepted'?25:10;
var barColor=riskText==='OVERDUE'?'var(--rd)':riskText==='AT RISK'?'var(--or)':pct>=90?'var(--gn)':'var(--ac)';
var blink=riskText==='OVERDUE'?';animation:pulse 1.5s infinite':'';

h+='<div class="card" style="margin-bottom:4px;padding:0;overflow:hidden;cursor:pointer;position:relative" onclick="openReqProfile(\''+r.id+'\')">';
// Progress bar background
h+='<div style="position:absolute;top:0;left:0;height:100%;width:'+pct+'%;background:'+barColor+'10;z-index:0'+blink+'"></div>';
h+='<div style="position:relative;z-index:1;padding:8px 10px">';
// Row 1: subject + priority + status
h+='<div style="display:flex;justify-content:space-between;align-items:center">';
h+='<strong style="color:var(--ac);font-size:11px">'+(r.subject||r.company||r.requestType)+'</strong>';
h+='<div style="display:flex;gap:3px"><span style="font-size:7px;padding:1px 4px;border-radius:3px;background:'+priColor+'20;color:'+priColor+';border:1px solid '+priColor+'">'+r.priority+'</span>';
h+='<span style="font-size:7px;padding:1px 4px;border-radius:3px;background:'+stColor+'20;color:'+stColor+';border:1px solid '+stColor+'">'+r.status+'</span></div></div>';
// Row 2: meta
h+='<div style="display:flex;justify-content:space-between;font-size:8px;color:var(--tx3);margin-top:3px">';
h+='<span>'+r.requestType+' · '+(r.submittedBy||'')+'→'+(r.assignedTo||'?')+'</span>';
h+='<span style="color:'+riskColor+';font-weight:600">'+daysUntil+' '+riskText+'</span></div>';
// Row 3: last note
h+='<div style="font-size:8px;color:var(--tx3);margin-top:2px">💬 '+lastNote+'</div>';
h+='</div></div>'});

if(!filtered.length)h+='<div style="color:var(--tx3);padding:20px;text-align:center">No requests</div>';
$('reqDash').innerHTML=h}).catch(function(e){$('reqDash').innerHTML=e.message})}

function openReqProfile(rid){
fbDb.collection('requests').doc(rid).get().then(function(doc){
if(!doc.exists)return;var r=Object.assign({id:doc.id},doc.data());
var me=getUserName();var isAssignee=r.assignedTo===me;var isOwner=r.submittedBy===me||r.owner===me;
var now=new Date();var daysUntil='—';var riskText='OK';
if(r.targetDate){var diff=Math.ceil((new Date(r.targetDate)-now)/86400000);daysUntil=diff;riskText=diff<0?'OVERDUE':diff<=1?'DUE TODAY':diff<=3?'AT RISK':'OK'}

var h='<div class="modal-title" style="font-size:13px">'+(r.subject||r.company||r.requestType)+'</div>';

// Status + risk
var stColor={pending:'var(--or)',accepted:'var(--ac)',in_progress:'var(--ac)',completed:'var(--gn)',closed:'var(--tx3)'}[r.status]||'var(--bdr)';
h+='<div style="display:flex;gap:4px;margin-bottom:8px;flex-wrap:wrap">';
h+='<span style="padding:3px 8px;border-radius:6px;font-size:10px;background:'+stColor+'20;color:'+stColor+';border:1px solid '+stColor+'">'+r.status+'</span>';
h+='<span style="padding:3px 8px;border-radius:6px;font-size:10px;background:var(--bg4);color:var(--ac)">'+r.requestType+'</span>';
if(r.priority==='Urgent')h+='<span style="padding:3px 8px;border-radius:6px;font-size:10px;background:#3b1010;color:var(--rd);border:1px solid var(--rd)">URGENT</span>';
if(riskText==='OVERDUE')h+='<span style="padding:3px 8px;border-radius:6px;font-size:10px;background:#7f1d1d;color:#fca5a5;animation:pulse 1s infinite">'+Math.abs(daysUntil)+'d OVERDUE</span>';
h+='</div>';

// Key details
h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:3px;font-size:9px;color:var(--tx3);margin-bottom:6px;line-height:1.8">';
if(r.company)h+='<div><b>Client:</b> '+r.company+'</div>';
if(r.contact)h+='<div><b>Contact:</b> '+r.contact+'</div>';
if(r.dept||r.department)h+='<div><b>Dept:</b> '+(r.dept||r.department)+'</div>';
h+='<div><b>Priority:</b> '+r.priority+'</div>';
h+='<div><b>Submitted:</b> '+(r.submittedAt?fD(new Date(r.submittedAt.seconds*1000).toISOString()):'—')+'</div>';
if(r.targetDate)h+='<div><b>Due:</b> <span style="color:'+(riskText==='OVERDUE'?'var(--rd)':'var(--or)')+'">'+r.targetDate+'</span></div>';
h+='<div><b>By:</b> '+r.submittedBy+'</div>';
h+='<div><b>Assigned:</b> <span style="color:var(--ac)">'+(r.assignedTo||'Unassigned')+'</span></div>';
h+='</div>';

if(r.description)h+='<div style="font-size:10px;color:var(--tx2);background:var(--bg3);padding:6px;border-radius:6px;margin-bottom:6px;line-height:1.4">'+r.description+'</div>';

// Deliverables / links
if(r.files)h+='<div style="margin-bottom:6px"><div style="font-size:9px;font-weight:600;margin-bottom:2px">📎 Deliverables</div><a href="'+r.files+'" target="_blank" style="font-size:10px;color:var(--ac)">View Files →</a></div>';

// Activity + Comments thread
h+='<div style="font-size:9px;font-weight:600;margin-bottom:3px">💬 Activity & Notes ('+(r.comments||[]).length+')</div>';
h+='<div style="max-height:130px;overflow-y:auto">';
(r.comments||[]).forEach(function(c,ci){
h+='<div style="padding:3px 0;border-bottom:1px solid var(--bdr);font-size:9px">';
h+='<div style="display:flex;justify-content:space-between"><strong style="color:var(--ac)">'+c.by+'</strong><div><span style="cursor:pointer;font-size:8px" onclick="event.stopPropagation();likeReqComment(\''+rid+'\','+ci+')">👍'+(c.likes||0)+'</span> <span style="color:var(--tx3)">'+c.at+'</span></div></div>';
h+='<div style="color:var(--tx2)">'+c.text+'</div>';
if(c.replies&&c.replies.length){c.replies.forEach(function(rp){h+='<div style="margin:1px 0 1px 10px;padding:2px 6px;background:var(--bg3);border-left:2px solid var(--ac);border-radius:0 3px 3px 0;font-size:8px"><strong style="color:var(--ac)">'+rp.by+'</strong> '+rp.text+'</div>'})}
h+='<button class="btn btn-ghost" style="font-size:7px;padding:1px 4px" onclick="event.stopPropagation();replyReqComment(\''+rid+'\','+ci+')">↩</button></div>'});
h+='</div>';
h+='<textarea id="req-comment" placeholder="Add note... @name to tag" style="width:100%;min-height:28px;padding:5px;border:1px solid var(--bdr);border-radius:6px;background:var(--inp);color:var(--tx);font-size:10px;margin:4px 0"></textarea>';
h+='<button class="btn btn-ghost btn-xs" onclick="addReqComment(\''+rid+'\')" style="width:100%;margin-bottom:6px">Post Note</button>';

// Action buttons
h+='<div style="display:flex;flex-direction:column;gap:3px">';
if(isAssignee&&r.status==='pending')h+='<button class="btn btn-gn btn-sm" onclick="acceptRequest(\''+rid+'\')">✅ Accept</button><button class="btn btn-ghost btn-sm" style="color:var(--rd)" onclick="declineRequest(\''+rid+'\')">❌ Decline</button>';
if(isAssignee&&r.status==='accepted')h+='<button class="btn btn-pr btn-sm" onclick="startRequest(\''+rid+'\')">🚀 Start</button>';
if(isAssignee&&(r.status==='accepted'||r.status==='in_progress'))h+='<button class="btn btn-gn btn-sm" onclick="completeRequest(\''+rid+'\')">✅ Complete</button>';
if(isOwner&&r.status==='completed')h+='<button class="btn btn-gn btn-sm" onclick="closeRequest(\''+rid+'\')">🔒 Close + Rate</button>';
// Follow up / remind / reassign
h+='<div style="display:flex;gap:3px">';
h+='<button class="btn btn-ghost btn-xs" onclick="pingAssignee(\''+rid+'\')" style="flex:1">🔔 Ping</button>';
h+='<button class="btn btn-ghost btn-xs" onclick="reassignRequest(\''+rid+'\')" style="flex:1">🔄 Reassign</button>';
h+='<button class="btn btn-ghost btn-xs" onclick="closeModal()" style="flex:1">Close</button></div>';
h+='</div>';
openModal(h)})}

function pingAssignee(rid){
fbDb.collection('requests').doc(rid).get().then(function(doc){var r=doc.data();
if(!r.assignedTo)return toast('No assignee','err');
notifyTeam('🔔 REMINDER: '+getUserName()+' pinged '+r.assignedTo+' on: '+r.requestType+' — '+(r.subject||r.company||''));
var c=r.comments||[];c.push({by:'System',text:'🔔 '+getUserName()+' sent a reminder ping to '+r.assignedTo,at:fD(new Date().toISOString()),likes:0,replies:[]});
fbDb.collection('requests').doc(rid).update({comments:c}).then(function(){toast('Pinged '+r.assignedTo,'ok')})})}

function reassignRequest(rid){
var users=typeof getTeamUsers==='function'?getTeamUsers():[];
var to=prompt('Reassign to? ('+users.join(', ')+')');if(!to)return;
fbDb.collection('requests').doc(rid).get().then(function(doc){var r=doc.data();
var c=r.comments||[];c.push({by:getUserName(),text:'🔄 Reassigned from '+(r.assignedTo||'nobody')+' to '+to,at:fD(new Date().toISOString()),likes:0,replies:[]});
fbDb.collection('requests').doc(rid).update({assignedTo:to,comments:c}).then(function(){
closeModal();toast('Reassigned to '+to,'ok');notifyTeam('🔄 '+r.requestType+' reassigned to '+to+' by '+getUserName());openSubmittedRequests()})})}

function openMeetings(){S.view='supportinbox';document.querySelectorAll('.view').forEach(function(el){el.classList.remove('active')});$('v-supportinbox').classList.add('active');$('mainTabs').style.display='none';$('hdrBack').style.display='block';$('hdrBack').onclick=function(){goView('dashboard')};$('hdrTitle').textContent='Calendar';$('hdrActions').innerHTML='<button class="btn btn-pr btn-sm" onclick="newMeetingTask()">+ New</button>';renderMeetingsView()}

function renderMeetingsView(){var el=$('v-supportinbox');if(!el)return;el.innerHTML='<div style="color:var(--tx3);padding:20px;text-align:center">Loading...</div>';loadAllTasks(function(items){var vt=window._calViewTab||0;var h='<div style="display:flex;gap:6px;margin-bottom:10px">';['📅 Calendar','📋 My Tasks','🏢 Dept','📊 Lead'].forEach(function(t,i){h+='<div style="padding:5px 10px;background:'+(vt===i?'var(--ac)':'var(--bg3)')+';color:'+(vt===i?'#fff':'var(--tx2)')+';border-radius:20px;font-size:9px;font-weight:600;cursor:pointer" onclick="window._calViewTab='+i+';renderMeetingsView()">'+t+'</div>'});h+='</div>';if(vt===0)h+=renderCalendarGrid(items);else if(vt===1)h+=renderMyTasks(items);else if(vt===2)h+=renderDeptTasks(items);else h+=renderLeadershipTasks(items);el.innerHTML=h})}

function loadAllTasks(cb){var items=[];if(!fbDb){cb(items);return}fbDb.collection('tasks').orderBy('createdAt','desc').limit(100).get().then(function(snap){items=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())});cb(items)}).catch(function(){cb(items)})}

function renderCalendarGrid(items){var cm=window._calMonth!==undefined?window._calMonth:new Date().getMonth();var cy=window._calYear||new Date().getFullYear();window._calMonth=cm;window._calYear=cy;var today=new Date();var fd=new Date(cy,cm,1).getDay();var dim=new Date(cy,cm+1,0).getDate();var mn=new Date(cy,cm,1).toLocaleDateString('en-US',{month:'long',year:'numeric'});var h='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><button class="btn btn-ghost btn-xs" onclick="calNav(-1)">◀</button><div style="font-size:14px;font-weight:700;color:var(--tx)">'+mn+'</div><button class="btn btn-ghost btn-xs" onclick="calNav(1)">▶</button></div>';h+='<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:12px">';['Su','Mo','Tu','We','Th','Fr','Sa'].forEach(function(d){h+='<div style="text-align:center;font-size:9px;color:var(--tx3);padding:4px">'+d+'</div>'});for(var i=0;i<fd;i++)h+='<div></div>';for(var d=1;d<=dim;d++){var ds=cy+'-'+(cm+1<10?'0':'')+(cm+1)+'-'+(d<10?'0':'')+d;var di=items.filter(function(m){return m.date===ds});var isT=d===today.getDate()&&cm===today.getMonth()&&cy===today.getFullYear();h+='<div style="text-align:center;padding:4px 2px;background:'+(isT?'var(--ac2)':di.length?'var(--bg4)':'var(--bg3)')+';border:1px solid '+(isT?'var(--ac)':'var(--bdr)')+';border-radius:6px;cursor:pointer;min-height:36px" onclick="showDayTasks(\''+ds+'\')"><div style="font-size:12px;font-weight:'+(isT?'700':'400')+';color:'+(isT?'#fff':'var(--tx)')+'">'+d+'</div>'+(di.length?'<div style="font-size:7px;color:var(--ac)">'+di.length+'</div>':'')+'</div>'}h+='</div>';var up=items.filter(function(m){return m.date>=today.toISOString().split('T')[0]&&!m.completed}).sort(function(a,b){return(a.date||'').localeCompare(b.date||'')});h+='<div style="font-size:12px;font-weight:600;margin-bottom:6px">Upcoming ('+up.length+')</div>';up.slice(0,10).forEach(function(m){h+=taskCard(m)});if(!up.length)h+='<div style="color:var(--tx3);padding:12px;text-align:center">Nothing scheduled</div>';return h}

function renderMyTasks(items){var me=getUserName();var mine=items.filter(function(t){return t.assignedTo===me||t.createdBy===me});var active=mine.filter(function(t){return!t.completed});var done=mine.filter(function(t){return t.completed});var h='<div style="font-size:11px;font-weight:600;margin-bottom:4px">Active ('+active.length+')</div>';active.forEach(function(t){h+=taskCard(t)});if(done.length){h+='<div style="font-size:11px;font-weight:600;color:var(--gn);margin:8px 0 4px">Done ('+done.length+')</div>';done.slice(0,8).forEach(function(t){h+=taskCard(t)})}return h}
function renderDeptTasks(items){var depts={};items.forEach(function(t){var d=t.dept||'Other';if(!depts[d])depts[d]={a:0,d:0};if(t.completed)depts[d].d++;else depts[d].a++});var h='';Object.entries(depts).forEach(function(e){h+='<div class="card" style="margin-bottom:6px"><strong>'+e[0]+'</strong><div style="font-size:9px;color:var(--tx3)">'+e[1].a+' active · '+e[1].d+' done</div></div>'});return h}
function renderLeadershipTasks(items){var users={};items.forEach(function(t){var u=t.assignedTo||t.createdBy||'?';if(!users[u])users[u]={a:0,d:0,o:0};if(t.completed)users[u].d++;else{users[u].a++;if(t.date&&new Date(t.date)<new Date())users[u].o++}});var h='';Object.entries(users).sort(function(a,b){return b[1].a-a[1].a}).forEach(function(e){h+='<div style="display:flex;justify-content:space-between;padding:6px 8px;border-bottom:1px solid var(--bdr);font-size:11px"><strong>'+e[0]+'</strong><span>'+e[1].a+' active'+(e[1].o?' · <span style="color:var(--rd)">'+e[1].o+' overdue</span>':'')+'</span></div>'});return h}

function taskCard(m){var ico=m.type==='task'?'📋':'📅';var od=m.date&&new Date(m.date)<new Date()&&!m.completed;return'<div class="card" style="padding:10px;cursor:pointer;border-left:3px solid '+(m.completed?'var(--gn)':od?'var(--rd)':'var(--ac)')+'" onclick="openTaskDetail(\''+m.id+'\')"><div style="display:flex;justify-content:space-between"><strong style="color:'+(m.completed?'var(--tx3)':'var(--ac)')+';font-size:12px">'+ico+' '+m.title+'</strong><span style="font-size:9px;color:var(--tx3)">'+(m.date||'')+'</span></div><div style="font-size:9px;color:var(--tx3)">'+(m.assignedTo?'→'+m.assignedTo:'')+(m.linkedClient?' · 👤'+m.linkedClient:'')+'</div></div>'}

function calNav(dir){window._calMonth=(window._calMonth||new Date().getMonth())+dir;if(window._calMonth>11){window._calMonth=0;window._calYear=(window._calYear||new Date().getFullYear())+1}if(window._calMonth<0){window._calMonth=11;window._calYear=(window._calYear||new Date().getFullYear())-1}renderMeetingsView()}

function newMeetingTask(){var qs=DB.quotes();var cs=DB.customers();var users=['Randy','Marco R.','Alex M.','Chris W.'];var h='<div class="modal-title">New Task / Meeting</div><div class="fg"><label>Type</label><select id="mt-type"><option value="task">📋 Task</option><option value="meeting">📅 Meeting</option></select></div><div class="fg"><label>Title *</label><input id="mt-title"></div><div class="fg"><label>Description</label><textarea id="mt-desc" style="min-height:40px"></textarea></div><div class="fg"><label>Assign To</label><select id="mt-assign"><option value="'+getUserName()+'">Me</option>';users.forEach(function(u){h+='<option>'+u+'</option>'});h+='</select></div><div class="fg"><label>Dept</label><select id="mt-dept"><option>Operations</option><option>Estimation</option><option>Pre-Press</option><option>Production</option><option>Quality</option><option>Sales</option></select></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div class="fg"><label>Date</label><input id="mt-date" type="date" value="'+new Date().toISOString().split('T')[0]+'"></div><div class="fg"><label>Time</label><input id="mt-time" type="time" value="10:00"></div></div><div class="fg"><label>Link Quote</label><select id="mt-lq"><option value="">None</option>';qs.slice(0,20).forEach(function(q){h+='<option value="'+q.quoteNum+'">'+q.quoteNum+'</option>'});h+='</select></div><div class="fg"><label>Link Client</label><select id="mt-lc"><option value="">None</option>';cs.slice(0,20).forEach(function(c){h+='<option value="'+c.company+'">'+c.company+'</option>'});h+='</select></div><div class="fg"><label>Priority</label><select id="mt-pri"><option>Normal</option><option>High</option><option>Urgent</option></select></div><button class="btn btn-pr" onclick="saveTask()" style="width:100%;margin-top:8px">Save</button><button class="btn btn-ghost" onclick="closeModal()" style="width:100%;margin-top:6px">Cancel</button>';openModal(h)}

function saveTask(){var title=($('mt-title')||{}).value;if(!title)return toast('Title required','err');var t={type:($('mt-type')||{}).value||'task',title:title.trim(),description:($('mt-desc')||{}).value||'',assignedTo:($('mt-assign')||{}).value||getUserName(),dept:($('mt-dept')||{}).value||'',date:($('mt-date')||{}).value||'',time:($('mt-time')||{}).value||'',estTime:60,timeSpent:0,linkedQuote:($('mt-lq')||{}).value||'',linkedClient:($('mt-lc')||{}).value||'',priority:($('mt-pri')||{}).value||'Normal',completed:false,pointsEarned:0,notes:[],subtasks:[],links:[],createdBy:getUserName(),createdAt:new Date().toISOString()};fbDb.collection('tasks').add(t).then(function(){closeModal();toast('Saved!','ok');renderMeetingsView();if(t.date&&typeof createCalendarEvent==='function')createCalendarEvent((t.type==='task'?'📋 ':'📅 ')+t.title,t.description,t.date,t.time,60)}).catch(function(e){toast(e.message,'err')})}

function scheduleMeeting(qid){newMeetingTask();var q=qid?getQ(qid):null;if(q)setTimeout(function(){if($('mt-title'))$('mt-title').value=q.quoteNum+' — '+(q.fields.custCo||'');if($('mt-lq'))$('mt-lq').value=q.quoteNum;if($('mt-type'))$('mt-type').value='meeting'},200)}

function openTaskDetail(tid){fbDb.collection('tasks').doc(tid).get().then(function(doc){if(!doc.exists)return;var t=Object.assign({id:doc.id},doc.data());var h='<div class="modal-title">'+(t.type==='task'?'📋':'📅')+' '+t.title+'</div>';if(t.completed)h+='<div style="background:var(--gn2);border:1px solid var(--gn);border-radius:6px;padding:6px;margin-bottom:6px;font-size:10px;color:var(--gn)">✅ Completed</div>';h+='<div style="font-size:10px;color:var(--tx3);margin-bottom:8px;line-height:1.7"><b>Date:</b> '+(t.date||'—')+' · <b>Assigned:</b> '+(t.assignedTo||'—')+' · <b>Priority:</b> '+t.priority+'</div>';if(t.description)h+='<div style="font-size:11px;color:var(--tx2);background:var(--bg3);padding:6px;border-radius:6px;margin-bottom:6px">'+t.description+'</div>';var subs=t.subtasks||[];if(subs.length){h+='<div style="font-size:10px;font-weight:600;margin-bottom:3px">Subtasks</div>';subs.forEach(function(s,i){h+='<div style="font-size:10px;padding:2px 0;cursor:pointer" onclick="toggleSubtask(\''+tid+'\','+i+')">'+(s.done?'✅':'☐')+' '+s.text+'</div>'})}h+='<div style="display:flex;gap:4px;margin:4px 0"><input id="task-sub" placeholder="Add subtask" style="flex:1;padding:3px;border:1px solid var(--bdr);border-radius:4px;background:var(--inp);color:var(--tx);font-size:10px"><button class="btn btn-ghost btn-xs" onclick="addSubtask(\''+tid+'\')">+</button></div>';h+='<div style="font-size:10px;font-weight:600;margin:6px 0 3px">Notes ('+(t.notes||[]).length+')</div>';(t.notes||[]).forEach(function(n){h+='<div style="padding:3px 0;border-bottom:1px solid var(--bdr);font-size:10px"><strong style="color:var(--ac)">'+n.by+'</strong> '+n.text+'</div>'});h+='<textarea id="task-note" placeholder="Add note..." style="width:100%;min-height:30px;padding:4px;border:1px solid var(--bdr);border-radius:6px;background:var(--inp);color:var(--tx);font-size:10px;margin:4px 0"></textarea><button class="btn btn-ghost btn-xs" onclick="addTaskNote(\''+tid+'\')" style="width:100%;margin-bottom:6px">Post</button>';h+='<div style="display:flex;gap:4px">';if(!t.completed)h+='<button class="btn btn-gn btn-sm" onclick="completeTask(\''+tid+'\')" style="flex:1">✅ Done</button>';else h+='<button class="btn btn-ghost btn-sm" onclick="reopenTask(\''+tid+'\')" style="flex:1">↩ Reopen</button>';h+='<button class="btn btn-ghost btn-sm" onclick="deleteTask(\''+tid+'\')" style="flex:1;color:var(--rd)">🗑</button><button class="btn btn-ghost btn-sm" onclick="closeModal()" style="flex:1">Close</button></div>';openModal(h)})}

function addSubtask(tid){var el=$('task-sub');if(!el||!el.value.trim())return;fbDb.collection('tasks').doc(tid).get().then(function(doc){var t=doc.data();var s=t.subtasks||[];s.push({text:el.value.trim(),done:false});fbDb.collection('tasks').doc(tid).update({subtasks:s}).then(function(){closeModal();openTaskDetail(tid)})})}
function toggleSubtask(tid,idx){fbDb.collection('tasks').doc(tid).get().then(function(doc){var t=doc.data();var s=t.subtasks||[];if(s[idx]){s[idx].done=!s[idx].done;s[idx].completedAt=s[idx].done?new Date().toISOString():null}fbDb.collection('tasks').doc(tid).update({subtasks:s}).then(function(){closeModal();openTaskDetail(tid)})})}
function addTaskNote(tid){var el=$('task-note');if(!el||!el.value.trim())return;fbDb.collection('tasks').doc(tid).get().then(function(doc){var t=doc.data();var n=t.notes||[];n.push({by:getUserName(),text:el.value.trim(),at:fD(new Date().toISOString())});fbDb.collection('tasks').doc(tid).update({notes:n}).then(function(){closeModal();openTaskDetail(tid)})})}
function logTaskTime(tid){var m=parseInt(($('task-time')||{}).value);if(!m)return;fbDb.collection('tasks').doc(tid).get().then(function(doc){var t=doc.data();fbDb.collection('tasks').doc(tid).update({timeSpent:(t.timeSpent||0)+m}).then(function(){closeModal();openTaskDetail(tid);toast(m+'m logged','ok')})})}
function completeTask(tid){fbDb.collection('tasks').doc(tid).update({completed:true,completedAt:new Date().toISOString(),pointsEarned:firebase.firestore.FieldValue.increment(0.5)}).then(function(){closeModal();toast('Done! +0.5 pts','ok');renderMeetingsView()})}
function reopenTask(tid){fbDb.collection('tasks').doc(tid).update({completed:false,completedAt:null}).then(function(){closeModal();toast('Reopened','ok');renderMeetingsView()})}
function deleteTask(tid){if(!confirm('Delete?'))return;fbDb.collection('tasks').doc(tid).delete().then(function(){closeModal();toast('Deleted','ok');renderMeetingsView()})}
function showDayTasks(ds){fbDb.collection('tasks').where('date','==',ds).get().then(function(snap){var items=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())});var h='<div class="modal-title">'+new Date(ds+'T12:00:00').toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})+'</div>';items.forEach(function(m){h+='<div class="card" style="padding:8px;margin-bottom:6px;cursor:pointer" onclick="closeModal();openTaskDetail(\''+m.id+'\')"><strong style="color:var(--ac)">'+(m.type==='task'?'📋':'📅')+' '+m.title+'</strong></div>'});if(!items.length)h+='<div style="color:var(--tx3);padding:12px;text-align:center">No items</div>';h+='<button class="btn btn-pr" onclick="closeModal();newMeetingTask()" style="width:100%;margin-top:8px">+ New</button><button class="btn btn-ghost" onclick="closeModal()" style="width:100%;margin-top:6px">Close</button>';openModal(h)})}

