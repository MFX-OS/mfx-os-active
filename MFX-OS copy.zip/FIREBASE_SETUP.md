# MFX OS — Firebase Setup & Deploy Guide

## Prerequisites
- Node.js 18+ installed
- A Google account with access to Firebase Console

## 1. Install Firebase CLI
```bash
npm install -g firebase-tools
```

## 2. Login to Firebase
```bash
firebase login
```
This opens a browser for Google auth.

## 3. Your Firebase Project
MFX OS is already configured to use project **mfx-os**. If you need a different project:
1. Go to https://console.firebase.google.com
2. Create a new project (or use existing)
3. Update `.firebaserc` with your project ID
4. Update the config in `public/js/core.js` (search for `firebase.initializeApp`)

## 4. Enable Firebase Services

### Authentication
1. Firebase Console → Authentication → Sign-in method
2. Enable **Google** provider
3. Enable **Email/Password** provider
4. Add your domain to Authorized domains

### Firestore Database
1. Firebase Console → Firestore Database → Create database
2. Start in **production mode**
3. Choose your preferred region (us-central1 recommended)
4. Deploy the security rules: `firebase deploy --only firestore:rules`

### Hosting
Already configured in `firebase.json`. No extra setup needed.

## 5. Deploy
```bash
# Deploy everything (hosting + firestore rules)
firebase deploy

# Or deploy just hosting
firebase deploy --only hosting

# Or deploy just rules
firebase deploy --only firestore:rules
```

## 6. Custom Domain (Optional)
1. Firebase Console → Hosting → Add custom domain
2. Follow the DNS verification steps
3. SSL is automatic

## 7. Firestore Collections
These are created automatically on first use:
- `users` — User profiles and login tracking
- `customers` — Client records (auto-seeded on first login)
- `quotes` — Quote documents with full line-item details
- `activity` — Activity feed entries
- `support` — Support tickets / inbox items
- `microfeed` — Team mood/social feed
- `chat` — Team board messages
- `requests` — RFQ inbox items
- `discussions` — Discussion threads
- `tasks` — Task items
- `projects` — Project records
- `threads` — Threaded conversations
- `dms` — Direct message threads
- `specDies`, `specFilms`, `specLabels`, `specVarnishes` — Material specs
- `quoteTemplates` — Saved quote templates

## 8. Google API Integration (Optional)
For Gmail send, Calendar, Drive, and Tasks features:
1. Google Cloud Console → Enable APIs:
   - Gmail API
   - Google Calendar API
   - Google Drive API
   - Google Tasks API
2. Create OAuth 2.0 credentials
3. The app uses the Firebase Google auth token for these APIs

## Quick Test
After deploying, visit your hosting URL. You should see the MFX OS login screen. Sign in with Google to load the dashboard.

## Troubleshooting
- **Blank screen after login**: Check browser console for Firestore permission errors. Make sure rules are deployed.
- **Google sign-in fails**: Verify the domain is in Firebase Auth → Authorized domains.
- **No data showing**: First login seeds sample client data. Check Firestore console to verify.
